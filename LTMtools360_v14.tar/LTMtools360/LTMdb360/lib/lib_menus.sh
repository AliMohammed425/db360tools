#!/usr/bin/env bash
# Module version: 3.3.1
# LTMdbMigration360 module: lib_menus.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# menu_pause
# -----------------------------------------------------------------------------
menu_pause() {
  printf '\n'
  read -r -p "Press Enter to continue..." _
}

# -----------------------------------------------------------------------------
# menu_header
# -----------------------------------------------------------------------------
menu_header() {
  clear 2>/dev/null || true
  cat <<EOF
================================================================================
             LTMdbMigration360 Enterprise Database Migration and Lifecycle Utility
                         Version $SCRIPT_VERSION
================================================================================
Mode       : INTERACTIVE
User       : $(id -un)
Host       : $(hostname -s)
CLI Mode   : Fully supported for automation
================================================================================
EOF
}

# -----------------------------------------------------------------------------
# menu_read
# -----------------------------------------------------------------------------
menu_read() {
  local variable_name="$1"
  local prompt_text="$2"
  local default_value="${3:-}"
  local entered_value=""

  if [[ -n "$default_value" ]]; then
    read -r -p "$prompt_text [$default_value]: " entered_value
    entered_value="${entered_value:-$default_value}"
  else
    read -r -p "$prompt_text: " entered_value
  fi

  printf -v "$variable_name" '%s' "$entered_value"
}


# -----------------------------------------------------------------------------
# menu_add_parallel_degree
# -----------------------------------------------------------------------------
menu_add_parallel_degree() {
  local -n cmd_ref="$1"
  local answer=""
  local degree="4"

  printf 'Enable Parallel? [Y/n]: '
  IFS= read -r answer
  if [[ "$answer" =~ ^[Nn] ]]; then
    cmd_ref+=(--no-parallel)
    return 0
  fi

  menu_read degree "Parallel Degree (2-12)" "4"
  [[ "$degree" =~ ^[0-9]+$ ]] &&
    (( degree >= 2 && degree <= 12 )) ||
    die "Parallel Degree must be between 2 and 12."

  cmd_ref+=(--parallel-degree "$degree")
}


# -----------------------------------------------------------------------------
# menu_secret
# -----------------------------------------------------------------------------
menu_secret() {
  local variable_name="$1"
  local prompt_text="$2"
  local entered_value=""

  read -r -s -p "$prompt_text: " entered_value
  printf '\n'
  printf -v "$variable_name" '%s' "$entered_value"
}

# -----------------------------------------------------------------------------
# menu_confirm_run
# -----------------------------------------------------------------------------
menu_confirm_run() {
  local -a command=("$@")
  local answer=""

  printf '\nCommand Preview\n'
  printf '%s\n' '---------------'
  printf '%q ' "${command[@]}"
  printf '\n\n'

  read -r -p "Run this operation? [y/N]: " answer
  case "$answer" in
    y|Y|yes|YES|Yes)
      "${command[@]}"
      ;;
    *)
      printf 'Operation cancelled.\n'
      ;;
  esac
}

# -----------------------------------------------------------------------------
# menu_create_cdb
# -----------------------------------------------------------------------------
menu_create_cdb() {
  local type="" cdb="" unique="" sid="" oh="" data="" fra=""
  local charset="AL32UTF8" ncharset="AL16UTF16"
  local sys_password="" tde_password="" engine="auto" nodes=""
  local -a command

  menu_header
  printf 'Create Local CDB\n\n'
  printf '1) RAC\n2) Single Instance\n'
  read -r -p "Database type [1]: " type
  type="${type:-1}"

  menu_read cdb "CDB name"
  menu_read unique "DB_UNIQUE_NAME" "$cdb"
  menu_read sid "SID prefix" "$cdb"
  menu_read oh "Oracle Home"
  menu_read data "DATA destination" "+DATA"
  menu_read fra "FRA destination" "+RECO"
  menu_read charset "Database character set" "AL32UTF8"
  menu_read ncharset "National character set" "AL16UTF16"

  printf '\nCreation engine\n1) Auto\n2) DBaaSCLI\n3) DBCA\n'
  read -r -p "Engine [1]: " engine
  case "${engine:-1}" in
    1) engine="auto" ;;
    2) engine="dbaascli" ;;
    3) engine="dbca" ;;
    *) printf 'Invalid engine selection.\n'; return ;;
  esac

  menu_secret sys_password "SYS/SYSTEM password"
  menu_secret tde_password "TDE keystore password"

  command=(
    "$SELF_PATH" --engine "$engine" -Y
    -c "$cdb" -Q "$unique" -V "$sid"
    -J "$oh" -W "$data" -Z "$fra"
    --dbCharset "$charset" --dbNCharset "$ncharset"
    -w "$sys_password" -K "$tde_password"
  )

  case "$type" in
    1|"")
      menu_read nodes "RAC node list (blank=auto-detect)" ""
      command=( "$SELF_PATH" --rac "${command[@]:1}" )
      [[ -n "$nodes" ]] && command+=(--nodes "$nodes")
      ;;
    2)
      command=( "$SELF_PATH" --single-instance "${command[@]:1}" )
      ;;
    *)
      printf 'Invalid database type.\n'
      return
      ;;
  esac

  menu_confirm_run "${command[@]}"
}

# -----------------------------------------------------------------------------
# menu_create_pdb
# -----------------------------------------------------------------------------
menu_create_pdb() {
  local cdb="" pdb=""
  menu_header
  printf 'Create New Local PDB\n\n'
  menu_read cdb "CDB name"
  menu_read pdb "New PDB name"
  menu_confirm_run "$SELF_PATH" -z -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_list_cdbs
# -----------------------------------------------------------------------------
menu_list_cdbs() {
  menu_confirm_run "$SELF_PATH" -L
}

# -----------------------------------------------------------------------------
# menu_list_pdbs
# -----------------------------------------------------------------------------
menu_list_pdbs() {
  local cdb=""
  menu_read cdb "CDB name"
  menu_confirm_run "$SELF_PATH" -l -c "$cdb"
}

# -----------------------------------------------------------------------------
# menu_pdb_info
# -----------------------------------------------------------------------------
menu_pdb_info() {
  local cdb="" pdb=""
  menu_read cdb "CDB name"
  menu_read pdb "PDB name"
  menu_confirm_run "$SELF_PATH" -i -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_open_pdb
# -----------------------------------------------------------------------------
menu_open_pdb() {
  local cdb="" pdb=""
  menu_read cdb "CDB name"
  menu_read pdb "PDB name"
  menu_confirm_run "$SELF_PATH" -o -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_close_pdb
# -----------------------------------------------------------------------------
menu_close_pdb() {
  local cdb="" pdb=""
  menu_read cdb "CDB name"
  menu_read pdb "PDB name"
  menu_confirm_run "$SELF_PATH" -x -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_drop_pdb
# -----------------------------------------------------------------------------
menu_drop_pdb() {
  local cdb="" pdb=""
  menu_read cdb "CDB name"
  menu_read pdb "PDB name"
  menu_confirm_run "$SELF_PATH" -d -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_rename_pdb
# -----------------------------------------------------------------------------
menu_rename_pdb() {
  local cdb="" old_pdb="" new_pdb=""
  menu_read cdb "CDB name"
  menu_read old_pdb "Current PDB name"
  menu_read new_pdb "New PDB name"
  menu_confirm_run "$SELF_PATH" -r "$new_pdb" -c "$cdb" -p "$old_pdb"
}

# -----------------------------------------------------------------------------
# menu_local_clone
# -----------------------------------------------------------------------------
menu_local_clone() {
  local cdb="" source="" target=""
  menu_read cdb "CDB name"
  menu_read source "Source PDB"
  menu_read target "Target PDB"
  menu_confirm_run "$SELF_PATH" -k "$source" -t "$target" -c "$cdb"
}

# -----------------------------------------------------------------------------
# menu_remote_clone
# -----------------------------------------------------------------------------
menu_remote_clone() {
  local cdb="" source_pdb="" target_pdb="" source_db=""
  local scan="" port="1521" service="" sys_password=""
  local non_exadata="" answer=""
  local -a command

  menu_read cdb "Target CDB"
  menu_read source_pdb "Source PDB"
  menu_read target_pdb "Target PDB" "$source_pdb"
  menu_read source_db "Source DB_UNIQUE_NAME"
  menu_read scan "Source SCAN/host/IP"
  menu_read port "Listener port" "1521"
  menu_read service "Source service" "$source_db"
  menu_secret sys_password "Source SYS password"
  read -r -p "Non-Exadata source? [y/N]: " answer

  command=(
    "$SELF_PATH" -R -c "$cdb" -p "$source_pdb" -t "$target_pdb"
    -s "$source_db" -a "$scan" -P "$port" -g "$service"
    -w "$sys_password"
  )
  [[ "$answer" =~ ^[Yy] ]] && command+=(-N)
  menu_confirm_run "${command[@]}"
}

# -----------------------------------------------------------------------------
# menu_refreshable_create
# -----------------------------------------------------------------------------
menu_refreshable_create() {
  local cdb="" source_pdb="" target_pdb="" source_db=""
  local scan="" port="1521" service="" interval="0"
  local sys_password="" key_password=""
  local -a command

  menu_read cdb "Target CDB"
  menu_read source_pdb "Source PDB"
  menu_read target_pdb "Refreshable target PDB"
  menu_read source_db "Source DB_UNIQUE_NAME"
  menu_read scan "Source SCAN/host/IP"
  menu_read port "Listener port" "1521"
  menu_read service "Source service" "$source_db"
  menu_read interval "Refresh interval minutes (0=manual)" "0"
  menu_secret sys_password "Source SYS password"
  menu_secret key_password "Target keystore password"

  command=(
    "$SELF_PATH" -f -c "$cdb" -p "$source_pdb" -t "$target_pdb"
    -s "$source_db" -a "$scan" -P "$port" -g "$service"
    -I "$interval" -w "$sys_password" -K "$key_password"
  )
  menu_confirm_run "${command[@]}"
  menu_add_parallel_degree command
}

# -----------------------------------------------------------------------------
# menu_manual_refresh
# -----------------------------------------------------------------------------
menu_manual_refresh() {
  local cdb="" pdb=""
  menu_read cdb "CDB name"
  menu_read pdb "Refreshable PDB"
  menu_confirm_run "$SELF_PATH" -M -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_refresh_status
# -----------------------------------------------------------------------------
menu_refresh_status() {
  local cdb="" pdb=""
  menu_read cdb "CDB name"
  menu_read pdb "Refreshable PDB"
  menu_confirm_run "$SELF_PATH" -q -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_final_cutover
# -----------------------------------------------------------------------------
menu_final_cutover() {
  local cdb="" pdb="" passes="2" answer=""
  local -a command

  menu_header
  printf 'Final Cutover to Read Write + Datapatch + UTLRP + Validation\n\n'
  menu_read cdb "Target CDB"
  menu_read pdb "Refreshable PDB"
  menu_read passes "Datapatch passes after final cutover" "2"

  command=(
    "$SELF_PATH" -C -c "$cdb" -p "$pdb"
    --final-datapatch-passes "$passes"
  )

  read -r -p "Run Datapatch after cutover? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-final-datapatch)

  read -r -p "Compile invalid objects with utlrp.sql? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-final-utlrp)

  read -r -p "Validate invalid objects before and after? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-final-invalid-validation)

  menu_confirm_run "${command[@]}"
  menu_add_parallel_degree command
}

# -----------------------------------------------------------------------------
# menu_snapshot_enable
# -----------------------------------------------------------------------------
menu_snapshot_enable() {
  local cdb="" source="" target="" mode="auto" dest="" key=""
  local -a command

  menu_read cdb "CDB name"
  menu_read source "Source/refreshable PDB"
  menu_read target "Writable test PDB"
  printf '\n1) Auto\n2) Snapshot only\n3) Full clone\n'
  read -r -p "Clone mode [1]: " mode
  case "${mode:-1}" in
    1) mode="auto" ;;
    2) mode="snapshot"; menu_read dest "Sparse ASM destination" "+SPARSE" ;;
    3) mode="full" ;;
    *) printf 'Invalid mode.\n'; return ;;
  esac
  menu_secret key "Target keystore password"

  command=(
    "$SELF_PATH" --snapshot-test-enable --snapshot-mode "$mode"
    -c "$cdb" -p "$source" -t "$target" -K "$key"
  )
  [[ -n "$dest" ]] && command+=(--snapshot-dest "$dest")
  menu_confirm_run "${command[@]}"
}

# -----------------------------------------------------------------------------
# menu_snapshot_disable
# -----------------------------------------------------------------------------
menu_snapshot_disable() {
  local cdb="" source="" target=""
  menu_read cdb "CDB name"
  menu_read source "Refreshable PDB"
  menu_read target "Writable test PDB to remove"
  menu_confirm_run "$SELF_PATH" --snapshot-test-disable -c "$cdb" -p "$source" -t "$target"
}

# -----------------------------------------------------------------------------
# menu_encryption_status
# -----------------------------------------------------------------------------
menu_encryption_status() {
  local cdb=""
  menu_read cdb "CDB name"
  menu_confirm_run "$SELF_PATH" -E -c "$cdb"
}

# -----------------------------------------------------------------------------
# menu_encrypt_tablespaces
# -----------------------------------------------------------------------------
menu_encrypt_tablespaces() {
  local cdb="" pdb="" algorithm="AES256" answer=""
  local -a command

  menu_read cdb "CDB name"
  menu_read pdb "PDB name"
  menu_read algorithm "Algorithm" "AES256"

  command=(
    "$SELF_PATH"
    -e
    -c "$cdb"
    -p "$pdb"
    --encryption-algorithm "$algorithm"
    --include-system-ts
  )

  read -r -p "Include SYSTEM and SYSAUX tablespaces? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command=( "${command[@]/--include-system-ts/--exclude-system-ts}" )

  menu_confirm_run "${command[@]}"
}

# -----------------------------------------------------------------------------
# menu_subscription_migration
# -----------------------------------------------------------------------------
menu_subscription_migration() {
  local choice=""

  while true; do
    menu_header
    cat <<EOF
Subscription-to-Subscription Migration
--------------------------------------
Configuration: $DEFAULT_MIGRATION_INI

1)  Validate ltm_migration.ini
2)  Primary database create precheck
3)  Standby database create precheck
4)  Create primary database
5)  Create standby database
6)  Prepare primary for standby - dry run
7)  Prepare primary for standby - live
8)  Build standby/Data Guard - dry run
9)  Build standby/Data Guard - live
10) Data Guard status - primary/all
11) Data Guard status - standby/database
12) Data Guard switchover - dry run
13) Data Guard switchover - live
14) Database health check - all
15) Database health check - one database
16) Move latest DB registration TAR files
17) Guided full migration workflow
18) Generate migration summary report
19) Resume interrupted migration
20) Parallel database health check
0)  Back
EOF

    read -r -p "Selection: " choice
    case "$choice" in
      1)  subscription_validate_config ;;
      2)  subscription_precheck_primary ;;
      3)  subscription_precheck_standby ;;
      4)  subscription_create_primary ;;
      5)  subscription_create_standby ;;
      6)  subscription_prepare_standby_test ;;
      7)  subscription_prepare_standby_live ;;
      8)  subscription_build_standby_test ;;
      9)  subscription_build_standby_live ;;
      10) subscription_dg_status_primary_all ;;
      11) subscription_dg_status_standby ;;
      12) subscription_switchover_test ;;
      13) subscription_switchover_live ;;
      14) subscription_health_all ;;
      15) subscription_health_database ;;
      16) subscription_move_registration_tar ;;
      17) subscription_full_workflow ;;
      18) subscription_generate_migration_report ;;
      19) subscription_resume_workflow ;;
      20) subscription_parallel_health_all ;;
      0)  return ;;
      *)  printf 'Invalid selection.\n' ;;
    esac

    menu_pause
  done
}

# -----------------------------------------------------------------------------
# menu_create_manage
# -----------------------------------------------------------------------------
menu_create_tablespace() {
  local cdb="" pdb="" name="" type="PERMANENT" size="1024" next="100" max="UNLIMITED" dest="" alg="AES256" answer=""
  local -a command
  menu_header
  printf 'Create Tablespace / Temporary Tablespace\n\n'
  menu_read cdb "Target CDB"
  menu_read pdb 'Target PDB (blank or CDB$ROOT for root)' ''
  menu_read name "Tablespace name"
  menu_read type "Type: PERMANENT or TEMPORARY" "PERMANENT"
  menu_read size "Initial size MB" "1024"
  menu_read next "Autoextend NEXT MB" "100"
  menu_read max "MAXSIZE MB or UNLIMITED" "UNLIMITED"
  menu_read dest "File destination (blank uses OMF)" ""
  command=("$SELF_PATH" --create-tablespace -c "$cdb" --tablespace-name "$name" --tablespace-type "$type" --tablespace-size-mb "$size" --tablespace-next-mb "$next" --tablespace-maxsize-mb "$max")
  [[ -n "$pdb" ]] && command+=(-p "$pdb")
  [[ -n "$dest" ]] && command+=(--tablespace-dest "$dest")
  if [[ "${type^^}" == PERMANENT ]]; then
    read -r -p "Create BIGFILE tablespace? [y/N]: " answer; [[ "$answer" =~ ^[Yy] ]] && command+=(--bigfile)
    read -r -p "Encrypt tablespace? [Y/n]: " answer
    if [[ "$answer" =~ ^[Nn] ]]; then command+=(--no-tablespace-encryption); else menu_read alg "Encryption algorithm" "AES256"; command+=(--tablespace-encryption-algorithm "$alg"); fi
  fi
  read -r -p "Enable AUTOEXTEND? [Y/n]: " answer; [[ "$answer" =~ ^[Nn] ]] && command+=(--no-autoextend)
  menu_confirm_run "${command[@]}"
  menu_add_parallel_degree command
}

menu_tablespace_report() {
  local cdb="" pdb=""; local -a command
  menu_header
  printf 'Tablespace Inventory Report\n\n'
  menu_read cdb "Target CDB"
  menu_read pdb "Target PDB (blank reports CDB root and all PDBs)" ""
  command=("$SELF_PATH" --tablespace-report -c "$cdb")
  [[ -n "$pdb" ]] && command+=(-p "$pdb")
  menu_confirm_run "${command[@]}"
}

menu_create_manage() {
  local choice=""
  while true; do
    menu_header
    cat <<'EOF'
Create / Manage
---------------
1) Create RAC or Single-Instance CDB
2) Create New PDB
3) Open PDB
4) Close PDB
5) Drop PDB
6) Rename PDB
7) PDB Details
8) Fix Post-Clone PDB Violations (Patch + Encrypt + UTLRP)
9) Create Tablespace / Temporary Tablespace
10) Tablespace Inventory Report
0) Back
EOF
    read -r -p "Selection: " choice
    case "$choice" in
      1) menu_create_cdb ;;
      2) menu_create_pdb ;;
      3) menu_open_pdb ;;
      4) menu_close_pdb ;;
      5) menu_drop_pdb ;;
      6) menu_rename_pdb ;;
      7) menu_pdb_info ;;
      8) menu_fix_pdb_violations ;;
      9) menu_create_tablespace ;;
      10) menu_tablespace_report ;;
      0) return ;;
      *) printf 'Invalid selection.\n' ;;
    esac
    menu_pause
  done
  menu_add_parallel_degree command
}

# -----------------------------------------------------------------------------
# menu_clone_refresh
# -----------------------------------------------------------------------------
menu_clone_refresh() {
  local choice=""
  while true; do
    menu_header
    cat <<'EOF'
Clone / Refresh
---------------
1) Local PDB Clone
2) Remote PDB Clone
3) Create Refreshable PDB
4) Refresh Now
5) Refresh Status
6) Final Cutover to Read Write + Datapatch + UTLRP + Validation
7) Datapatch
8) PDB Datapatch + UTLRP + Validation
9) Compile Invalid PDB Objects
10) Fix Post-Clone PDB Violations (Patch + Encrypt + UTLRP)
0) Back
EOF
    read -r -p "Selection: " choice
    case "$choice" in
      1) menu_local_clone ;;
      2) menu_remote_clone ;;
      3) menu_refreshable_create ;;
      4) menu_manual_refresh ;;
      5) menu_refresh_status ;;
      6) menu_final_cutover ;;
      7) menu_datapatch ;;
      8) menu_pdb_datapatch ;;
      9) menu_compile_utlrp ;;
      10) menu_fix_pdb_violations ;;
      0) return ;;
      *) printf 'Invalid selection.\n' ;;
    esac
    menu_pause
  done
}

# -----------------------------------------------------------------------------
# menu_snapshot
# -----------------------------------------------------------------------------
menu_snapshot() {
  local choice=""
  while true; do
    menu_header
    cat <<'EOF'
Writable Test PDB
-----------------
1) Create Writable Test PDB
2) Remove Test PDB and Resume Refresh
0) Back
EOF
    read -r -p "Selection: " choice
    case "$choice" in
      1) menu_snapshot_enable ;;
      2) menu_snapshot_disable ;;
      0) return ;;
      *) printf 'Invalid selection.\n' ;;
    esac
    menu_pause
  done
}

# -----------------------------------------------------------------------------
# menu_datapatch
# -----------------------------------------------------------------------------
menu_datapatch() {
  local cdb="" pdb="" scope="2" passes="2"
  local -a command

  menu_header
  printf 'Datapatch\n\n'
  menu_read cdb "Target CDB"

  printf '1) Full CDB\n2) One PDB\n'
  read -r -p "Scope [2]: " scope
  scope="${scope:-2}"

  command=("$SELF_PATH" --datapatch -c "$cdb")

  if [[ "$scope" == "2" ]]; then
    menu_read pdb "Target PDB"
    command+=(-p "$pdb")
  fi

  menu_read passes "Datapatch passes" "2"
  command+=(--datapatch-passes "$passes")
  menu_confirm_run "${command[@]}"
}

# -----------------------------------------------------------------------------
# menu_pdb_datapatch
# -----------------------------------------------------------------------------
menu_pdb_datapatch() {
  local cdb="" pdb="" passes="2"
  menu_header
  printf 'PDB Datapatch + UTLRP + Validation\n\n'
  menu_read cdb "Target CDB"
  menu_read pdb "Target PDB"
  menu_read passes "Datapatch passes" "2"
  menu_confirm_run "$SELF_PATH" --pdb-datapatch \
    -c "$cdb" -p "$pdb" --datapatch-passes "$passes"
}

# -----------------------------------------------------------------------------
# menu_compile_utlrp
# -----------------------------------------------------------------------------
menu_compile_utlrp() {
  local cdb="" pdb=""
  menu_header
  printf 'Compile Invalid PDB Objects with UTLRP\n\n'
  menu_read cdb "Target CDB"
  menu_read pdb "Target PDB"
  menu_confirm_run "$SELF_PATH" --compile-utlrp -c "$cdb" -p "$pdb"
}

# -----------------------------------------------------------------------------
# menu_fix_pdb_violations
# -----------------------------------------------------------------------------
menu_fix_pdb_violations() {
  local cdb=""
  local pdb=""
  local passes="2"
  local algorithm="AES256"
  local answer=""
  local -a command

  menu_header
  printf 'Fix Post-Clone PDB Violations (Patch + Encrypt + UTLRP)\n\n'

  menu_read cdb "Target CDB"
  menu_read pdb "Target PDB"
  menu_read passes "Datapatch passes" "2"
  menu_read algorithm "Encryption algorithm" "AES256"

  command=(
    "$SELF_PATH"
    --fix-pdb-violations
    -c "$cdb"
    -p "$pdb"
    --fix-passes "$passes"
    --fix-encryption-algorithm "$algorithm"
  )

  read -r -p "Encrypt unencrypted permanent tablespaces? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-fix-encryption)

  read -r -p "Include SYSTEM and SYSAUX encryption? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--exclude-system-ts)

  read -r -p "Compile invalid objects with utlrp.sql? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-fix-utlrp)

  read -r -p "Bounce PDB after remediation? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-fix-bounce)

  read -r -p "Run final validation? [Y/n]: " answer
  [[ "$answer" =~ ^[Nn] ]] && command+=(--skip-fix-validation)

  read -r -p "Fail if invalid objects remain after UTLRP? [y/N]: " answer
  [[ "$answer" =~ ^[Yy] ]] && command+=(--fail-on-invalids)

  menu_confirm_run "${command[@]}"
}

# -----------------------------------------------------------------------------
# menu_encryption
# -----------------------------------------------------------------------------
menu_encryption() {
  local choice=""
  while true; do
    menu_header
    cat <<'EOF'
Encryption
----------
1) Wallet and PDB Encryption Status
2) Encrypt Eligible User Tablespaces
0) Back
EOF
    read -r -p "Selection: " choice
    case "$choice" in
      1) menu_encryption_status ;;
      2) menu_encrypt_tablespaces ;;
      0) return ;;
      *) printf 'Invalid selection.\n' ;;
    esac
    menu_pause
  done
}

# -----------------------------------------------------------------------------
# interactive_menu
# -----------------------------------------------------------------------------
interactive_menu() {
  local choice=""
  while true; do
    menu_header
    cat <<'EOF'
Main Menu
---------
1) Create / Manage CDB and PDB
2) Clone / Refresh / Cutover
3) Writable Test PDB
4) Encryption
5) Datapatch
6) PDB Datapatch + UTLRP + Validation
7) Compile Invalid PDB Objects
8) Fix Post-Clone PDB Violations (Patch + Encrypt + UTLRP)
9) Subscription-to-Subscription Migration
10) List All CDBs
11) List PDB Inventory
12) Full Help and Examples
0) Exit
EOF
    read -r -p "Selection: " choice
    case "$choice" in
      1) menu_create_manage ;;
      2) menu_clone_refresh ;;
      3) menu_snapshot ;;
      4) menu_encryption ;;
      5) menu_datapatch ;;
      6) menu_pdb_datapatch ;;
      7) menu_compile_utlrp ;;
      8) menu_fix_pdb_violations ;;
      9) menu_subscription_migration ;;
      10) menu_list_cdbs; menu_pause ;;
      11) menu_list_pdbs; menu_pause ;;
      12) "$SELF_PATH" -H; menu_pause ;;
      0) printf 'Goodbye.\n'; return 0 ;;
      *) printf 'Invalid selection.\n'; sleep 1 ;;
    esac
  done
}


#!/usr/bin/env bash
# Module version: 3.3.1
# LTMdbMigration360 module: lib_datapatch.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# validate_invalid_objects
# -----------------------------------------------------------------------------
validate_invalid_objects() {
  local pdb_name="$1"
  local phase="${2:-CURRENT}"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000 trimspool on
col owner for a30
col object_type for a35
col invalid_count for 999999 heading 'INVALID_COUNT'

alter session set container=${pdb_name};

prompt === INVALID OBJECTS: ${phase} ===
select owner,
       object_type,
       count(*) invalid_count
from dba_objects
where status='INVALID'
group by owner, object_type
order by owner, object_type;

select count(*) invalid_total
from dba_objects
where status='INVALID';

exit"

  info "Validating invalid objects in $pdb_name ($phase)..."
  run_local_sql "$sql" || warn "Invalid-object validation failed for $pdb_name."
}

# -----------------------------------------------------------------------------
# compile_utlrp_pdb
# -----------------------------------------------------------------------------
compile_utlrp_pdb() {
  local pdb_name="$1"
  local sql=""

  pdb_name="$(normalize_name "$pdb_name")"
  validate_oracle_name "$pdb_name" "PDB name"
  validate_parallel_degree

  if [[ "${PARALLEL_ENABLED:-true}" == "true" ]]; then
    sql="whenever sqlerror exit sql.sqlcode
set echo on timing on serveroutput on
alter session set container=${pdb_name};
begin
  utl_recomp.recomp_parallel(${PARALLEL_DEGREE});
end;
/
exit"
    info "Compiling invalid objects in $pdb_name with UTL_RECOMP parallel degree ${PARALLEL_DEGREE}..."
  else
    sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=${pdb_name};
@?/rdbms/admin/utlrp.sql
exit"
    info "Compiling invalid objects in $pdb_name using serial UTLRP..."
  fi

  run_local_sql "$sql" ||
    die "Invalid-object compilation failed for PDB $pdb_name."
}

# -----------------------------------------------------------------------------
# datapatch_review_violations
# -----------------------------------------------------------------------------
datapatch_review_violations() {
  local pdb_name="$1"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000 trimspool on
col name for a30
col cause for a25
col type for a10
col status for a15
col action for a75
col message for a155
alter session set container=CDB\$ROOT;

select to_char(time,'YYYYMMDD HH24:MI:SS') time,
       name,
       cause,
       type,
       status,
       action,
       message
from pdb_plug_in_violations
where name='${pdb_name}'
  and status <> 'RESOLVED'
order by time;

exit"

  info "Reviewing unresolved plug-in violations for $pdb_name..."
  run_local_sql "$sql" || warn "Plug-in violation query failed for $pdb_name."
}

# -----------------------------------------------------------------------------
# resolve_datapatch_command
# -----------------------------------------------------------------------------
resolve_datapatch_command() {
  local oracle_home="$1"
  local candidate=""
  local oracle_path=""
  local first_line=""

  DATAPATCH_COMMAND=()

  for candidate in \
    "$oracle_home/OPatch/datapatch" \
    "$oracle_home/bin/datapatch"
  do
    if "$SUDO_BIN" -u oracle test -x "$candidate"; then
      DATAPATCH_COMMAND=("$candidate")
      info "Resolved Datapatch executable as oracle user: $candidate"
      return 0
    fi

    if "$SUDO_BIN" -u oracle test -r "$candidate"; then
      first_line="$(
        "$SUDO_BIN" -u oracle head -1 "$candidate" 2>/dev/null || true
      )"

      case "$first_line" in
        *perl*)
          if "$SUDO_BIN" -u oracle test -x "$oracle_home/perl/bin/perl"; then
            DATAPATCH_COMMAND=("$oracle_home/perl/bin/perl" "$candidate")
            info "Resolved Datapatch through Oracle Perl as oracle user: $candidate"
            return 0
          fi
          ;;
        *bash*|*sh*)
          DATAPATCH_COMMAND=("/usr/bin/env" "bash" "$candidate")
          info "Resolved Datapatch through bash as oracle user: $candidate"
          return 0
          ;;
      esac
    fi
  done

  oracle_path="$(
    "$SUDO_BIN" -u oracle env \
      ORACLE_HOME="$oracle_home" \
      PATH="$oracle_home/OPatch:$oracle_home/bin:/usr/local/bin:/usr/bin:/bin" \
      bash -c 'command -v datapatch 2>/dev/null || true' |
      tail -1
  )"

  if [[ -n "$oracle_path" ]] &&
     "$SUDO_BIN" -u oracle test -x "$oracle_path"; then
    DATAPATCH_COMMAND=("$oracle_path")
    info "Resolved Datapatch from oracle user PATH: $oracle_path"
    return 0
  fi

  oracle_path="$(
    "$SUDO_BIN" -u oracle find "$oracle_home" \
      -maxdepth 5 -type f -name datapatch -print 2>/dev/null |
      head -1
  )"

  if [[ -n "$oracle_path" ]]; then
    if "$SUDO_BIN" -u oracle test -x "$oracle_path"; then
      DATAPATCH_COMMAND=("$oracle_path")
      info "Resolved Datapatch by oracle-user Oracle Home search: $oracle_path"
      return 0
    fi

    if "$SUDO_BIN" -u oracle test -r "$oracle_path" &&
       "$SUDO_BIN" -u oracle test -x "$oracle_home/perl/bin/perl"; then
      DATAPATCH_COMMAND=("$oracle_home/perl/bin/perl" "$oracle_path")
      info "Resolved Datapatch through Oracle Perl after oracle-user search: $oracle_path"
      return 0
    fi
  fi

  error "Datapatch could not be located for Oracle Home: $oracle_home"
  error "Checks were executed as the oracle user."
  error "Checked:"
  error "  $oracle_home/OPatch/datapatch"
  error "  $oracle_home/bin/datapatch"
  error "  oracle user PATH"
  error "  oracle-user find under $oracle_home"
  error "Run the following diagnostics:"
  error "  sudo -u oracle ls -l $oracle_home/OPatch/datapatch"
  error "  sudo -u oracle test -x $oracle_home/OPatch/datapatch; echo \$?"
  error "  sudo -u oracle head -1 $oracle_home/OPatch/datapatch"
  return 1
}

# -----------------------------------------------------------------------------
# datapatch_run_passes
# -----------------------------------------------------------------------------
datapatch_run_passes() {
  local oracle_home="$1"
  local target_pdb="${2:-}"
  local pass=1
  local timestamp_value=""
  local log_file=""
  local datapatch_rc=0
  local -a command

  resolve_datapatch_command "$oracle_home" ||
    die "Datapatch is unavailable for Oracle Home $oracle_home."

  while (( pass <= DATAPATCH_PASSES )); do
    timestamp_value="$(date +%Y%m%d_%H%M%S)"

    if [[ -n "$target_pdb" ]]; then
      log_file="$PROJECT_LOG_DIR/datapatch_${target_pdb}_pass${pass}_${timestamp_value}.log"
      command=(
        "$SUDO_BIN" -u oracle env
        ORACLE_SID="$TARGET_ORACLE_SID"
        ORACLE_HOME="$oracle_home"
        PATH="$oracle_home/OPatch:$oracle_home/bin:/usr/local/bin:/usr/bin:/bin"
        "${DATAPATCH_COMMAND[@]}"
        -verbose
        -pdbs "$target_pdb"
      )
    else
      log_file="$PROJECT_LOG_DIR/datapatch_CDB_${CDB_NAME}_pass${pass}_${timestamp_value}.log"
      command=(
        "$SUDO_BIN" -u oracle env
        ORACLE_SID="$TARGET_ORACLE_SID"
        ORACLE_HOME="$oracle_home"
        PATH="$oracle_home/OPatch:$oracle_home/bin:/usr/local/bin:/usr/bin:/bin"
        "${DATAPATCH_COMMAND[@]}"
        -verbose
      )
    fi

    info "Running Datapatch pass $pass of $DATAPATCH_PASSES..."
    info "Oracle Home  : $oracle_home"
    info "Oracle SID   : $TARGET_ORACLE_SID"
    info "Datapatch    : ${DATAPATCH_COMMAND[*]}"
    info "Datapatch log: $log_file"

    if [[ "$TEST_MODE" == "true" ]]; then
      printf 'DRY RUN:'
      printf ' %q' "${command[@]}"
      printf ' | tee %q\n' "$log_file"
    else
      set +e
      "${command[@]}" 2>&1 | tee "$log_file"
      datapatch_rc=${PIPESTATUS[0]}
      set -e

      (( datapatch_rc == 0 )) ||
        die "Datapatch pass $pass failed with return code $datapatch_rc. Review $log_file."
    fi

    ((pass++))
  done
}

# -----------------------------------------------------------------------------
# datapatch_bounce_pdb
# -----------------------------------------------------------------------------
datapatch_bounce_pdb() {
  local pdb_name="$1"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;
alter pluggable database ${pdb_name} close immediate instances=all;
alter pluggable database ${pdb_name} open instances=all;
select name, open_mode, restricted
from v\$pdbs
where name='${pdb_name}';
exit"

  info "Bouncing PDB $pdb_name..."
  run_local_sql "$sql" || die "Unable to bounce PDB $pdb_name."
}

# -----------------------------------------------------------------------------
# datapatch_verify_sql_inventory
# -----------------------------------------------------------------------------
datapatch_verify_sql_inventory() {
  local pdb_name="${1:-}"
  local container_name="CDB\$ROOT"
  local sql

  [[ -n "$pdb_name" ]] && container_name="$pdb_name"

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000 trimspool on
col description for a80
alter session set container=${container_name};

select patch_id,
       patch_type,
       action,
       status,
       action_time,
       description
from dba_registry_sqlpatch
order by action_time desc;

exit"

  info "Validating DBA_REGISTRY_SQLPATCH in $container_name..."
  run_local_sql "$sql" || warn "SQL patch validation failed in $container_name."
}

# -----------------------------------------------------------------------------
# datapatch_verify_block_sizes
# -----------------------------------------------------------------------------
datapatch_verify_block_sizes() {
  local pdb_name="${1:-}"
  local pdb_sql=""
  local sql

  if [[ -n "$pdb_name" ]]; then
    pdb_sql="
alter session set container=${pdb_name};
prompt === PDB ${pdb_name} BLOCK SIZES ===
select block_size, count(*)
from dba_tablespaces
group by block_size
order by block_size;"
  fi

  sql="whenever sqlerror exit sql.sqlcode
set lines 200 pages 1000
alter session set container=CDB\$ROOT;
prompt === CDB ROOT BLOCK SIZES ===
select block_size, count(*)
from dba_tablespaces
group by block_size
order by block_size;
${pdb_sql}
exit"

  info "Validating CDB/PDB block sizes..."
  run_local_sql "$sql" || warn "Block-size validation failed."
}

# -----------------------------------------------------------------------------
# action_datapatch
# -----------------------------------------------------------------------------
action_datapatch() {
  local exact_pdb=""
  local oracle_home=""

  require_cdb
  validate_cdb_exists
  validate_parallel_degree

  [[ "$DATAPATCH_PASSES" =~ ^[1-9][0-9]*$ ]] ||
    die "--datapatch-passes must be a positive integer."

  if [[ -n "$PDB_LIST" ]]; then
    require_single_pdb
    exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
      die "PDB $PDB_LIST not found in CDB $CDB_NAME."
  fi

  resolve_local_oracle_environment
  oracle_home="$ORACLE_HOME_RESOLVED"

  confirm_action "Run Datapatch for ${exact_pdb:-CDB $CDB_NAME}?"

  [[ -n "$exact_pdb" && "$DATAPATCH_REVIEW_VIOLATIONS" == "true" ]] &&
    datapatch_review_violations "$exact_pdb"

  datapatch_run_passes "$oracle_home" "$exact_pdb"

  [[ -n "$exact_pdb" && "$DATAPATCH_BOUNCE_PDB" == "true" ]] &&
    datapatch_bounce_pdb "$exact_pdb"

  [[ -n "$exact_pdb" && "$DATAPATCH_REVIEW_VIOLATIONS" == "true" ]] &&
    datapatch_review_violations "$exact_pdb"

  [[ "$DATAPATCH_VERIFY_PATCHES" == "true" ]] &&
    datapatch_verify_sql_inventory "$exact_pdb"

  [[ "$DATAPATCH_VERIFY_BLOCKSIZE" == "true" ]] &&
    datapatch_verify_block_sizes "$exact_pdb"

  ok "Datapatch workflow completed."
}

# -----------------------------------------------------------------------------
# action_pdb_datapatch
# -----------------------------------------------------------------------------
action_pdb_datapatch() {
  local exact_pdb=""
  local oracle_home=""

  require_cdb
  require_single_pdb
  validate_cdb_exists
  validate_parallel_degree

  exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "PDB $PDB_LIST not found in CDB $CDB_NAME."

  resolve_local_oracle_environment
  oracle_home="$ORACLE_HOME_RESOLVED"

  confirm_action "Run PDB Datapatch, UTLRP, and validation for $exact_pdb?"

  [[ "$DATAPATCH_VALIDATE_INVALIDS" == "true" ]] &&
    validate_invalid_objects "$exact_pdb" "BEFORE DATAPATCH"

  [[ "$DATAPATCH_REVIEW_VIOLATIONS" == "true" ]] &&
    datapatch_review_violations "$exact_pdb"

  datapatch_run_passes "$oracle_home" "$exact_pdb"

  [[ "$DATAPATCH_COMPILE_UTLRP" == "true" ]] &&
    compile_utlrp_pdb "$exact_pdb" "$oracle_home"

  [[ "$DATAPATCH_BOUNCE_PDB" == "true" ]] &&
    datapatch_bounce_pdb "$exact_pdb"

  [[ "$DATAPATCH_REVIEW_VIOLATIONS" == "true" ]] &&
    datapatch_review_violations "$exact_pdb"

  [[ "$DATAPATCH_VALIDATE_INVALIDS" == "true" ]] &&
    validate_invalid_objects "$exact_pdb" "AFTER DATAPATCH/UTLRP"

  [[ "$DATAPATCH_VERIFY_PATCHES" == "true" ]] &&
    datapatch_verify_sql_inventory "$exact_pdb"

  [[ "$DATAPATCH_VERIFY_BLOCKSIZE" == "true" ]] &&
    datapatch_verify_block_sizes "$exact_pdb"

  ok "PDB Datapatch, UTLRP, and validation completed."
}

# -----------------------------------------------------------------------------
# action_compile_utlrp
# -----------------------------------------------------------------------------
action_compile_utlrp() {
  local exact_pdb=""
  local oracle_home=""

  require_cdb
  require_single_pdb
  validate_cdb_exists
  validate_parallel_degree

  exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "PDB $PDB_LIST not found in CDB $CDB_NAME."

  resolve_local_oracle_environment
  oracle_home="$ORACLE_HOME_RESOLVED"

  confirm_action "Compile invalid objects in PDB $exact_pdb?"

  [[ "$DATAPATCH_VALIDATE_INVALIDS" == "true" ]] &&
    validate_invalid_objects "$exact_pdb" "BEFORE UTLRP"

  compile_utlrp_pdb "$exact_pdb" "$oracle_home"

  [[ "$DATAPATCH_VALIDATE_INVALIDS" == "true" ]] &&
    validate_invalid_objects "$exact_pdb" "AFTER UTLRP"

  ok "UTLRP compilation completed for $exact_pdb."
}

# -----------------------------------------------------------------------------
# action_locate_datapatch
# -----------------------------------------------------------------------------
action_locate_datapatch() {
  require_cdb
  validate_cdb_exists
  resolve_local_oracle_environment

  printf '\nDatapatch Discovery\n'
  printf '%s\n' '-------------------'
  printf 'CDB         : %s\n' "$CDB_NAME"
  printf 'Oracle SID  : %s\n' "$TARGET_ORACLE_SID"
  printf 'Oracle Home : %s\n' "$ORACLE_HOME_RESOLVED"

  printf '\nOracle-user file checks\n'
  printf '%s\n' '-----------------------'
  "$SUDO_BIN" -u oracle ls -ld "$ORACLE_HOME_RESOLVED/OPatch" 2>/dev/null || true
  "$SUDO_BIN" -u oracle ls -l "$ORACLE_HOME_RESOLVED/OPatch/datapatch" 2>/dev/null || true

  if "$SUDO_BIN" -u oracle test -e "$ORACLE_HOME_RESOLVED/OPatch/datapatch"; then
    printf 'Exists      : YES\n'
  else
    printf 'Exists      : NO\n'
  fi

  if "$SUDO_BIN" -u oracle test -r "$ORACLE_HOME_RESOLVED/OPatch/datapatch"; then
    printf 'Readable    : YES\n'
  else
    printf 'Readable    : NO\n'
  fi

  if "$SUDO_BIN" -u oracle test -x "$ORACLE_HOME_RESOLVED/OPatch/datapatch"; then
    printf 'Executable  : YES\n'
  else
    printf 'Executable  : NO\n'
  fi

  resolve_datapatch_command "$ORACLE_HOME_RESOLVED" ||
    die "Datapatch could not be resolved."

  printf 'Datapatch   : %s\n' "${DATAPATCH_COMMAND[*]}"
  ok "Datapatch discovery completed."
}


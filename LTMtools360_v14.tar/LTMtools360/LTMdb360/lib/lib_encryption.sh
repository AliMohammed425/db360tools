#!/usr/bin/env bash
# Module version: 3.3.8
# LTMdbMigration360 module: lib_encryption.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.


# -----------------------------------------------------------------------------
# initialize_target_keystore_password
# Collect the target CDB keystore password once at the beginning of encryption.
# CLI automation may supply it with -K, which lib_args.sh should populate in
# TARGET_KEYSTORE_PASSWORD / TDE_PASSWORD / KEYSTORE_PASSWORD.
# -----------------------------------------------------------------------------
initialize_target_keystore_password() {
  local supplied=""

  if [[ -n "${TARGET_KEYSTORE_PASSWORD:-}" ]]; then
    supplied="$TARGET_KEYSTORE_PASSWORD"
  elif [[ -n "${TDE_PASSWORD:-}" ]]; then
    supplied="$TDE_PASSWORD"
  elif [[ -n "${KEYSTORE_PASSWORD:-}" ]]; then
    supplied="$KEYSTORE_PASSWORD"
  elif [[ -n "${TDEPASS:-}" ]]; then
    supplied="$TDEPASS"
  fi

  if [[ -n "$supplied" ]]; then
    TARGET_KEYSTORE_PASSWORD="$supplied"
    info "Target CDB keystore password: SUPPLIED VIA -K"
    return 0
  fi

  if [[ ! -t 0 ]]; then
    die "Target CDB keystore password is required. Supply it with -K for non-interactive execution."
  fi

  TARGET_KEYSTORE_PASSWORD="${TARGET_KEYSTORE_PASSWORD:?Target CDB keystore password is not initialized}"
  printf '\n'

  [[ -n "${TARGET_KEYSTORE_PASSWORD:-}" ]] ||
    die "Target CDB keystore password cannot be empty."

  info "Target CDB keystore password collected for this operation."
}

# -----------------------------------------------------------------------------
# require_target_keystore_password
# -----------------------------------------------------------------------------
require_target_keystore_password() {
  if [[ -z "$TARGET_KEYSTORE_PASSWORD" ]]; then
    TARGET_KEYSTORE_PASSWORD="${TARGET_KEYSTORE_PASSWORD:?Target CDB keystore password is not initialized}"
    printf '\n'
  fi

  [[ -n "$TARGET_KEYSTORE_PASSWORD" ]] ||
    die "Target CDB keystore password is required for encrypted PDB cloning."
}

# -----------------------------------------------------------------------------
# validate_target_keystore
# -----------------------------------------------------------------------------
validate_target_keystore() {
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
col status for a20
col wallet_type for a20
col keystore_mode for a20
alter session set container=CDB\$ROOT;
select status,
       wallet_type,
       keystore_mode
from v\$encryption_wallet;
exit"

  info "Validating target CDB keystore status..."
  run_local_sql "$sql" ||
    die "Unable to validate target CDB keystore status."
}

# -----------------------------------------------------------------------------
# validate_encryption_algorithm
# -----------------------------------------------------------------------------
validate_encryption_algorithm() {
  ENCRYPTION_ALGORITHM="$(printf '%s' "$ENCRYPTION_ALGORITHM" | tr '[:lower:]' '[:upper:]')"
  case "$ENCRYPTION_ALGORITHM" in
    AES128|AES192|AES256) ;;
    *) die "Invalid encryption algorithm: $ENCRYPTION_ALGORITHM. Use AES128, AES192, or AES256." ;;
  esac
}

# -----------------------------------------------------------------------------
# action_encryption_status
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# report_pdb_tablespace_encryption_inventory
# -----------------------------------------------------------------------------
report_pdb_tablespace_encryption_inventory() {
  local pdb_name="$1"
  local phase="${2:-CURRENT}"

  pdb_name="$(normalize_name "$pdb_name")"
  validate_oracle_name "$pdb_name" "PDB name"

  run_local_sql "
whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
col tablespace_name for a35
col contents for a12
col encrypted for a10
col status for a12

alter session set container=${pdb_name};

prompt
prompt ================================================================================
prompt PDB Tablespace Encryption Inventory - ${phase}
prompt ================================================================================
prompt

select tablespace_name,
       contents,
       block_size,
       encrypted,
       status
from dba_tablespaces
order by contents, tablespace_name;

prompt
prompt Encryption Summary
prompt ------------------

select encrypted,
       count(*) tablespace_count
from dba_tablespaces
group by encrypted
order by encrypted;

exit
"
}

# -----------------------------------------------------------------------------
# validate_or_activate_pdb_tde_master_key
# -----------------------------------------------------------------------------
validate_or_activate_pdb_tde_master_key() {
  local pdb_name="$1"
  local output=""
  local wallet_status=""
  local key_count="0"
  local escaped_password=""

  pdb_name="$(normalize_name "$pdb_name")"
  validate_oracle_name "$pdb_name" "PDB name"

  require_target_keystore_password

  output="$(
    run_local_sql "
whenever sqlerror exit sql.sqlcode
set define off
set verify off
set heading off feedback off pages 0 verify off echo off

alter session set container=${pdb_name};

select 'LTM_WALLET_STATUS=' || nvl(status,'UNKNOWN')
from v\$encryption_wallet
where rownum=1;

select 'LTM_KEY_COUNT=' || count(*)
from v\$encryption_keys
where con_id = sys_context('USERENV','CON_ID');

exit
"
  )" || die "Unable to query TDE wallet/master-key state for PDB $pdb_name."

  wallet_status="$(
    printf '%s\n' "$output" |
      sed -n 's/^[[:space:]]*LTM_WALLET_STATUS=//p' |
      tail -1 |
      tr -d '\r'
  )"

  key_count="$(
    printf '%s\n' "$output" |
      sed -n 's/^[[:space:]]*LTM_KEY_COUNT=//p' |
      tail -1 |
      tr -d '\r'
  )"

  wallet_status="${wallet_status:-UNKNOWN}"
  key_count="${key_count:-0}"

  info "PDB wallet status : $wallet_status"
  info "PDB master keys   : $key_count"

  case "$wallet_status" in
    OPEN)
      if [[ "$key_count" =~ ^[1-9][0-9]*$ ]]; then
        ok "PDB $pdb_name already has an active TDE master key."
        return 0
      fi
      ;;
    OPEN_NO_MASTER_KEY)
      ;;
    *)
      die "TDE wallet for PDB $pdb_name is not ready. Status: $wallet_status"
      ;;
  esac

  escaped_password="$(escape_sql_double_quoted_value "$TARGET_KEYSTORE_PASSWORD")"

  info "Activating TDE master key for PDB $pdb_name..."

  run_local_sql "
whenever sqlerror exit sql.sqlcode
set define off
set verify off
set echo on timing on
set lines 300 pages 1000
col wrl_parameter for a55
col wrl_type for a10
col status for a20
col wallet_type for a15

alter session set container=${pdb_name};

administer key management
  set key
  force keystore
  identified by \"${escaped_password}\"
  with backup;

select wrl_type,
       wrl_parameter,
       status,
       wallet_type,
       con_id
from v\$encryption_wallet
order by con_id;

select key_id,
       activation_time,
       con_id
from v\$encryption_keys
where con_id = sys_context('USERENV','CON_ID')
order by activation_time desc;

exit
" || die "Unable to activate TDE master key for PDB $pdb_name."

  ok "TDE master key activated for PDB $pdb_name."
}

# -----------------------------------------------------------------------------
# validate_pdb_tablespace_encryption
# -----------------------------------------------------------------------------
validate_pdb_tablespace_encryption() {
  local pdb_name="$1"
  local include_system="$2"
  local output=""
  local remaining=""

  output="$(
    run_local_sql "
whenever sqlerror exit sql.sqlcode
set heading off feedback off pages 0 verify off echo off

alter session set container=${pdb_name};

select 'LTM_REMAINING_UNENCRYPTED=' || count(*)
from dba_tablespaces
where contents='PERMANENT'
  and encrypted='NO'
  and tablespace_name not like 'UNDO%'
  and ('${include_system}' = 'true' or tablespace_name not in ('SYSTEM','SYSAUX'));

exit
"
  )" || return 1

  remaining="$(
    printf '%s\n' "$output" |
      sed -n 's/^[[:space:]]*LTM_REMAINING_UNENCRYPTED=//p' |
      tail -1 |
      tr -d '\r'
  )"

  remaining="${remaining:-UNKNOWN}"

  [[ "$remaining" == "0" ]] || return 1
  return 0
}


action_encryption_status() {
  local sql

  require_cdb
  validate_cdb_exists

  sql="whenever sqlerror exit sql.sqlcode
set lines 240 pages 1000 trimspool on
column pdb_name format a30
column open_mode format a12
column encrypted format a10
column encrypted_ts format 999 heading 'ENC_TS'
column wallet_status format a16
column wallet_type format a16
alter session set container=CDB\$ROOT;

select p.name pdb_name,
       p.open_mode,
       case when count(e.ts#) > 0 then 'ENABLED' else 'DISABLED' end encrypted,
       count(e.ts#) encrypted_ts
from v\$pdbs p
left join v\$encrypted_tablespaces e
  on e.con_id = p.con_id
group by p.name, p.open_mode, p.con_id
order by p.con_id;

select con_id,
       status wallet_status,
       wallet_type
from v\$encryption_wallet
order by con_id;

exit"

  run_local_sql "$sql" ||
    die "Unable to retrieve encryption status for CDB $CDB_NAME."
}

# -----------------------------------------------------------------------------
# action_encrypt_tablespaces
# -----------------------------------------------------------------------------
action_encrypt_tablespaces() {
  local exact_pdb
  local exclude_clause=""
  local sql

  require_cdb
  require_single_pdb
  validate_cdb_exists
  validate_encryption_algorithm
  validate_parallel_degree

  exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "PDB $PDB_LIST was not found in CDB $CDB_NAME."

  initialize_oracle_environment

  if [[ "${ENCRYPT_INCLUDE_SYSTEM:-true}" != "true" ]]; then
    exclude_clause="and tablespace_name not in ('SYSTEM','SYSAUX')"
  fi

  cat <<PLAN

  initialize_target_keystore_password

PDB Tablespace Encryption Plan
------------------------------
CDB               : $CDB_NAME
PDB               : $exact_pdb
Algorithm         : $ENCRYPTION_ALGORITHM
Eligible TS       : All unencrypted permanent PDB tablespaces
Include SYSTEM    : ${ENCRYPT_INCLUDE_SYSTEM:-true}
Include SYSAUX    : ${ENCRYPT_INCLUDE_SYSTEM:-true}
Always Excluded   : TEMP and UNDO
Execution         : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
Parallel Enabled  : ${PARALLEL_ENABLED:-true}
Parallel Degree   : $([[ "${PARALLEL_ENABLED:-true}" == "true" ]] && echo "${PARALLEL_DEGREE:-4}" || echo "DISABLED")
PLAN

  confirm_action "Encrypt all eligible permanent tablespaces in $exact_pdb using $ENCRYPTION_ALGORITHM?"

  report_pdb_tablespace_encryption_inventory "$exact_pdb" "PRE-ENCRYPTION" ||
    warn "Unable to capture pre-encryption tablespace inventory."

  validate_or_activate_pdb_tde_master_key "$exact_pdb"

  sql="whenever sqlerror exit sql.sqlcode
set define off
set verify off
set serveroutput on size unlimited
set lines 300 pages 1000
alter session set container=${exact_pdb};
$(parallel_sql_preamble)

declare
  l_sql varchar2(4000);
  l_count number := 0;
begin
  for r in (
    select tablespace_name
      from dba_tablespaces
     where contents = 'PERMANENT'
       and encrypted = 'NO'
       and tablespace_name not like 'UNDO%'
       ${exclude_clause}
     order by case tablespace_name
                when 'SYSTEM' then 1
                when 'SYSAUX' then 2
                else 3
              end,
              tablespace_name
  ) loop
    l_sql :=
      'alter tablespace ' ||
      dbms_assert.enquote_name(r.tablespace_name, false) ||
      ' encryption online using ''${ENCRYPTION_ALGORITHM}'' encrypt';

    dbms_output.put_line('Executing: ' || l_sql);
    execute immediate l_sql;
    l_count := l_count + 1;
  end loop;

  dbms_output.put_line('LTM_TABLESPACES_ENCRYPTED=' || l_count);
end;
/

select tablespace_name,
       contents,
       block_size,
       encrypted,
       status
from dba_tablespaces
order by contents, tablespace_name;

exit"

  run_local_sql "$sql" ||
    die "Tablespace encryption failed for PDB $exact_pdb."

  report_pdb_tablespace_encryption_inventory "$exact_pdb" "POST-ENCRYPTION" ||
    warn "Encryption completed, but post-encryption inventory failed."

  validate_pdb_tablespace_encryption \
    "$exact_pdb" \
    "${ENCRYPT_INCLUDE_SYSTEM:-true}" ||
    die "One or more eligible permanent tablespaces remain unencrypted in PDB $exact_pdb."

  ok "Permanent tablespace encryption completed and validated in $exact_pdb using $ENCRYPTION_ALGORITHM."
}

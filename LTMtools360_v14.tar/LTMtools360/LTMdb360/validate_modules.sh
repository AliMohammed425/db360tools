#!/usr/bin/env bash
set -Eeuo pipefail
TARGET_ROOT="${1:-/home/opc/LTMtools360/LTMdb360}"

bash -n "$TARGET_ROOT/bin/ltm_db_migration.sh"
for name in \
  lib_args.sh lib_menus.sh lib_parallel.sh lib_tablespace.sh \
  lib_datapatch.sh lib_clone.sh lib_refresh.sh lib_encryption.sh lib_oracle.sh
do
  bash -n "$TARGET_ROOT/lib/$name"
done

grep -q 'PARALLEL_DEGREE="4"' "$TARGET_ROOT/bin/ltm_db_migration.sh"
grep -q -- '--parallel-degree)' "$TARGET_ROOT/lib/lib_args.sh"
grep -q -- '--no-parallel)' "$TARGET_ROOT/lib/lib_args.sh"
grep -q '^validate_parallel_degree()' "$TARGET_ROOT/lib/lib_parallel.sh"
grep -q 'Parallel Degree (2-12)' "$TARGET_ROOT/lib/lib_menus.sh"
grep -q 'utl_recomp.recomp_parallel' "$TARGET_ROOT/lib/lib_datapatch.sh"

echo "Parallel degree 2-12 validation: PASS"

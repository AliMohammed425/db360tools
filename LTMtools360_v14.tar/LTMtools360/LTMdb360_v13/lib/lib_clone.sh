#!/usr/bin/env bash
NON_EXADATA_SOURCE="${NON_EXADATA_SOURCE:-false}"

# LTMdbMigration360 module: lib_clone.sh
# Module version: 3.2.7
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# action_local_clone_pdb
# -----------------------------------------------------------------------------
action_local_clone_pdb() {
  local inventory
  local requested_source=""
  local exact_source=""
  local requested_target=""
  local clone_argument=""

  require_cdb
  validate_cdb_exists

  clone_argument="$(normalize_name "$CLONE_PDB_TO")"

  # Mode 1: Create a new blank PDB
  #   -k NEW_PDB
  #
  # Mode 2: Local clone
  #   -k SOURCE_PDB -t TARGET_PDB
  #
  # Backward-compatible local clone
  #   -p SOURCE_PDB -k TARGET_PDB
  if [[ -z "$PDB_LIST" && -z "$TARGET_PDB_NAME" ]]; then
    [[ -n "$clone_argument" ]] ||
      die "New PDB name is required. Use -k NEW_PDB."

    requested_target="$clone_argument"
    validate_oracle_name "$requested_target" "new PDB name"

    inventory="$(get_pdb_inventory)" ||
      die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

    pdb_exists "$requested_target" "$inventory" &&
      die "PDB $requested_target already exists in CDB $CDB_NAME."

    cat <<PLAN

New Local PDB Creation Plan
---------------------------
CDB          : $CDB_NAME
New PDB      : $requested_target
Source PDB   : NONE
Operation    : CREATE NEW PDB
Execution    : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

    confirm_action "Create new PDB $requested_target in CDB $CDB_NAME?"

    execute_or_display "$SUDO_BIN" "$DBAASCLI_BIN" pdb create \
      --pdbname "$requested_target" \
      --dbName "$CDB_NAME"

    ok "New PDB creation request completed: $requested_target"
    return 0
  fi

  # Preferred clone syntax: -k SOURCE -t TARGET
  if [[ -z "$PDB_LIST" && -n "$TARGET_PDB_NAME" ]]; then
    requested_source="$clone_argument"
    requested_target="$(normalize_name "$TARGET_PDB_NAME")"

  # Legacy clone syntax: -p SOURCE -k TARGET
  elif [[ -n "$PDB_LIST" ]]; then
    requested_source="$(normalize_name "$PDB_LIST")"

    if [[ -n "$TARGET_PDB_NAME" ]]; then
      requested_target="$(normalize_name "$TARGET_PDB_NAME")"
    elif [[ -n "$clone_argument" ]]; then
      requested_target="$clone_argument"
    else
      requested_target="${requested_source}_CLONE"
    fi
  fi

  [[ -n "$requested_source" ]] ||
    die "Source PDB is required for local clone."
  [[ -n "$requested_target" ]] ||
    die "Target PDB is required for local clone."

  validate_oracle_name "$requested_source" "source PDB name"
  validate_oracle_name "$requested_target" "target PDB name"

  [[ "$requested_source" != 'PDB$SEED' ]] ||
    die "PDB$SEED cannot be used as a clone source."

  [[ "$requested_target" != 'PDB$SEED' ]] ||
    die "PDB$SEED cannot be used as a clone target."

  [[ "$requested_source" != "$requested_target" ]] ||
    die "Source and target PDB names cannot be the same."

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  exact_source="$(resolve_existing_pdb "$requested_source" "$inventory")" ||
    die "Source PDB $requested_source was not found in CDB $CDB_NAME."

  pdb_exists "$requested_target" "$inventory" &&
    die "Target PDB $requested_target already exists in CDB $CDB_NAME."

  cat <<PLAN

Local PDB Clone Plan
--------------------
CDB          : $CDB_NAME
Source PDB   : $exact_source
Target PDB   : $requested_target
Operation    : LOCAL CLONE
Execution    : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Clone PDB $exact_source to $requested_target?"

  execute_or_display "$SUDO_BIN" "$DBAASCLI_BIN" pdb local_clone \
    --pdbname "$exact_source" \
    --target_pdbname "$requested_target" \
    --dbName "$CDB_NAME"

  ok "Local clone request completed: $exact_source -> $requested_target"
}


# -----------------------------------------------------------------------------
# display_remote_clone_enterprise_plan
# -----------------------------------------------------------------------------
display_remote_clone_enterprise_plan() {
  local source_output=""
  local target_output=""
  local source_size="UNKNOWN"
  local source_open="UNKNOWN"
  local source_blocks="UNKNOWN"
  local source_wallet="UNKNOWN"
  local target_unique="UNKNOWN"
  local target_params="UNKNOWN"
  local source_service="${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}"
  local effective_service="${SOURCE_DBAASCLI_SERVICE:-$source_service}"
  local cache_status="NOT REQUIRED"
  local overall_status="READY"
  local auto_rename="NO"

  [[ "$created_pdb" != "$final_pdb" ]] && auto_rename="YES"

  source_output="$(
    run_source_alias_sql "${SOURCE_TNS_ALIAS}" "
set heading off feedback off pages 0 verify off echo off serveroutput on
alter session set container=CDB\$ROOT;
declare
  l_con_id number;
  l_open_mode varchar2(30);
  l_total_size number;
  l_wallet_status varchar2(30) := 'NOT_CONFIGURED';
  l_blocks varchar2(4000) := '';
begin
  select con_id, open_mode, total_size
    into l_con_id, l_open_mode, l_total_size
    from v\$pdbs
   where upper(name)=upper('${PDB_LIST}');

  begin
    select status
      into l_wallet_status
      from v\$encryption_wallet
     where con_id in (0,1)
       and rownum=1;
  exception when no_data_found then null;
  end;

  for r in (
    select block_size, count(*) cnt
      from cdb_tablespaces
     where con_id=l_con_id
     group by block_size
     order by block_size
  ) loop
    if length(l_blocks) > 0 then l_blocks := l_blocks || ', '; end if;
    l_blocks := l_blocks || to_char(r.block_size/1024) || 'K=' || r.cnt;
  end loop;

  dbms_output.put_line('LTM_SOURCE_SIZE_GB=' || round(l_total_size/1024/1024/1024,2));
  dbms_output.put_line('LTM_SOURCE_OPEN_MODE=' || l_open_mode);
  dbms_output.put_line('LTM_SOURCE_BLOCKS=' || nvl(l_blocks,'NONE'));
  dbms_output.put_line('LTM_SOURCE_WALLET=' || l_wallet_status);
end;
/
" 2>/dev/null
  )" || die "Unable to collect source migration-plan values."

  source_size="$(printf '%s\n' "$source_output" | sed -n 's/^[[:space:]]*LTM_SOURCE_SIZE_GB=//p' | tail -1 | tr -d '\r')"
  source_open="$(printf '%s\n' "$source_output" | sed -n 's/^[[:space:]]*LTM_SOURCE_OPEN_MODE=//p' | tail -1 | tr -d '\r')"
  source_blocks="$(printf '%s\n' "$source_output" | sed -n 's/^[[:space:]]*LTM_SOURCE_BLOCKS=//p' | tail -1 | tr -d '\r')"
  source_wallet="$(printf '%s\n' "$source_output" | sed -n 's/^[[:space:]]*LTM_SOURCE_WALLET=//p' | tail -1 | tr -d '\r')"

  target_output="$(
    run_local_sql "
whenever sqlerror exit sql.sqlcode
set heading off feedback off pages 0 verify off echo off serveroutput on
alter session set container=CDB\$ROOT;
declare
  l_unique varchar2(128);
begin
  select value into l_unique from v\$parameter where name='db_unique_name';
  dbms_output.put_line('LTM_TARGET_UNIQUE=' || l_unique);

  for r in (
    select inst_id,
           name,
           value
      from gv\$parameter
     where name in ('cpu_count','sga_target','sga_max_size',
                    'pga_aggregate_target','pga_aggregate_limit',
                    'db_16k_cache_size')
     order by inst_id, name
  ) loop
    dbms_output.put_line(
      'LTM_TARGET_PARAM=' ||
      r.inst_id || '|' ||
      r.name || '|' ||
      nvl(r.value,'0')
    );
  end loop;
end;
/
exit
" 2>/dev/null
  )" || die "Unable to collect target system values."

  target_unique="$(printf '%s\n' "$target_output" | sed -n 's/^[[:space:]]*LTM_TARGET_UNIQUE=//p' | tail -1 | tr -d '\r')"

  local inst_ids=""
  local inst_id=""
  local cpu="" sga="" sga_max="" pga="" pga_limit="" cache16k=""
  local record=""

  inst_ids="$(
    printf '%s\n' "$target_output" |
      sed -n 's/^[[:space:]]*LTM_TARGET_PARAM=\([^|]*\)|.*$/\1/p' |
      sort -n -u
  )"

  target_params=""

  get_target_param() {
    local requested_inst="$1"
    local requested_name="$2"

    printf '%s\n' "$target_output" |
      awk -F'|' \
        -v id="$requested_inst" \
        -v pname="$requested_name" '
          {
            key=$1
            sub(/^[[:space:]]*LTM_TARGET_PARAM=/, "", key)
          }
          key == id && $2 == pname {
            value=$3
          }
          END {
            gsub(/\r/, "", value)
            print value
          }
        '
  }

  while IFS= read -r inst_id; do
    [[ -n "$inst_id" ]] || continue

    cpu="$(get_target_param "$inst_id" cpu_count)"
    sga="$(get_target_param "$inst_id" sga_target)"
    sga_max="$(get_target_param "$inst_id" sga_max_size)"
    pga="$(get_target_param "$inst_id" pga_aggregate_target)"
    pga_limit="$(get_target_param "$inst_id" pga_aggregate_limit)"
    cache16k="$(get_target_param "$inst_id" db_16k_cache_size)"

    record="INST=${inst_id}"
    record+=",CPU=${cpu:-0}"
    record+=",SGA=${sga:-0}"
    record+=",SGA_MAX=${sga_max:-0}"
    record+=",PGA=${pga:-0}"
    record+=",PGA_LIMIT=${pga_limit:-0}"
    record+=",CACHE16K=${cache16k:-0}"

    [[ -n "$target_params" ]] && target_params+=";"
    target_params+="$record"
  done <<<"$inst_ids"

  target_params="${target_params:-UNKNOWN}"

  if [[ "${SOURCE_PDB_HAS_16K:-false}" == "true" ]]; then
    local instance_count=0
    local ready_count=0
    local cache_value=""

    while IFS= read -r cache_value; do
      [[ -n "$cache_value" ]] || continue
      instance_count=$((instance_count + 1))
      if [[ "$cache_value" =~ ^[0-9]+$ ]] && (( cache_value > 0 )); then
        ready_count=$((ready_count + 1))
      fi
    done < <(
      tr ';' '\n' <<<"$target_params" |
        sed -n 's/.*CACHE16K=\([0-9][0-9]*\).*/\1/p'
    )

    if (( instance_count > 0 && ready_count == instance_count )); then
      cache_status="READY"
    else
      cache_status="NOT READY"
      overall_status="BLOCKED"
    fi
  fi

  cat <<PLAN

================================================================================
LTMdbMigration360 Enterprise Remote Clone Precheck
================================================================================
Overall Status       : ${overall_status}

Source Precheck
---------------
Source Platform      : $([[ "${NON_EXADATA_SOURCE:-false}" == "true" ]] && echo NON_EXADATA || echo EXADATA)
Source DB            : ${SOURCE_DB_UNIQUE_NAME}
Source DB_DOMAIN     : ${SOURCE_DB_DOMAIN:-<empty>}
Requested Service    : ${source_service}
DBaaSCLI Service     : ${effective_service}
Source Address       : ${SOURCE_DB_SCAN}
Source Port          : ${SOURCE_DB_PORT}
Source PDB           : ${PDB_LIST}
Source PDB Open Mode : ${source_open:-UNKNOWN}
Source PDB Size GB   : ${source_size:-UNKNOWN}
Source Block Sizes   : ${source_blocks:-UNKNOWN}
Source Wallet Status : ${source_wallet:-UNKNOWN}

Target System Values
--------------------
Target CDB           : ${CDB_NAME}
Target DB_UNIQUE     : ${target_unique:-UNKNOWN}
Oracle SID           : ${TARGET_ORACLE_SID:-UNKNOWN}
Oracle Home          : ${ORACLE_HOME_RESOLVED:-UNKNOWN}
Source Uses 16K      : ${SOURCE_PDB_HAS_16K:-false}
Target 16K Status    : ${cache_status}
Instance Parameters  : See table below

Validation Summary
------------------
DNS Resolution       : PASS
TCP/${SOURCE_DB_PORT}             : PASS
TNS Alias Update     : PASS
TNSPING              : PASS
SYS SQL*Plus Login   : PASS
Source PDB Exists    : PASS
Source Wallet Check  : PASS
Target CDB           : PASS
Target Oracle Home   : PASS
Target 16K Cache     : $([[ "$cache_status" == "NOT READY" ]] && echo FAIL || echo PASS)

Remote PDB Migration Plan
-------------------------
Source Platform : $([[ "${NON_EXADATA_SOURCE:-false}" == "true" ]] && echo NON_EXADATA || echo EXADATA)
Source DB       : ${SOURCE_DB_UNIQUE_NAME}
Source PDB      : ${PDB_LIST}
Source Address  : ${SOURCE_DB_SCAN}
Source Port     : ${SOURCE_DB_PORT}
SYS Password    : SUPPLIED VIA -w

OCI Target CDB  : ${CDB_NAME}
DBaaSCLI Name   : ${created_pdb}
Requested Target (-t): ${TARGET_PDB_NAME}
Final PDB Name  : ${final_pdb}
Auto Rename     : ${auto_rename}
Clone Type      : Remote network clone
Source DBaaSCLI : Not required
Target DBaaSCLI : ${SUDO_BIN} ${DBAASCLI_BIN}
Execution       : $([[ "$TEST_MODE" == "true" ]] && echo DRY_RUN || echo LIVE)

DBaaSCLI Command
----------------
$(printf '%q ' "${clone_cmd[@]}")
================================================================================
PLAN

  printf '\nTarget Instance Parameters\n'
  printf '%s\n' '--------------------------'
  printf '%-8s %-6s %-14s %-14s %-14s %-14s %-12s\n' \
    "INST_ID" "CPU" "SGA_TARGET" "SGA_MAX" "PGA_TARGET" "PGA_LIMIT" "CACHE_16K"

  local record=""
  local inst="" cpu="" sga="" sga_max="" pga="" pga_limit="" cache16k=""

  while IFS= read -r record; do
    [[ -n "$record" ]] || continue
    inst="$(sed -n 's/.*INST=\([^,;]*\).*/\1/p' <<<"$record")"
    cpu="$(sed -n 's/.*CPU=\([^,;]*\).*/\1/p' <<<"$record")"
    sga="$(sed -n 's/.*SGA=\([^,;]*\).*/\1/p' <<<"$record")"
    sga_max="$(sed -n 's/.*SGA_MAX=\([^,;]*\).*/\1/p' <<<"$record")"
    pga="$(sed -n 's/.*PGA=\([^,;]*\).*/\1/p' <<<"$record")"
    pga_limit="$(sed -n 's/.*PGA_LIMIT=\([^,;]*\).*/\1/p' <<<"$record")"
    cache16k="$(sed -n 's/.*CACHE16K=\([^,;]*\).*/\1/p' <<<"$record")"

    printf '%-8s %-6s %-14s %-14s %-14s %-14s %-12s\n' \
      "${inst:-?}" "${cpu:-?}" "${sga:-?}" "${sga_max:-?}" \
      "${pga:-?}" "${pga_limit:-?}" "${cache16k:-?}"
  done < <(tr ';' '\n' <<<"${target_params:-}")

  [[ "$overall_status" == "READY" ]] ||
    die "Enterprise precheck status is BLOCKED. Remote clone will not start."
}

# -----------------------------------------------------------------------------
# action_remote_clone_pdb
# -----------------------------------------------------------------------------
action_remote_clone_pdb() {
  local created_pdb
  local final_pdb
  local inventory
  local created_exists="false"
  local final_exists="false"
  local workflow_mode="NEW_CLONE"
  local -a clone_cmd
  local -a rename_cmd

  require_cdb
  require_single_pdb
  require_source_db
  require_source_scan
  validate_source_port

  PDB_LIST="$(normalize_name "$PDB_LIST")"
  validate_oracle_name "$PDB_LIST" "source PDB name"

  validate_cdb_exists

  # DBaaSCLI creates TARGET_CDB_SOURCE_PDB during remote clone.
  created_pdb="${CDB_NAME}_${PDB_LIST}"

  if [[ -n "${TARGET_PDB_NAME:-}" ]]; then
    final_pdb="$(normalize_name "$TARGET_PDB_NAME")"
  else
    final_pdb="$PDB_LIST"
  fi

  validate_oracle_name "$final_pdb" "target PDB name"
  [[ "$final_pdb" != 'PDB\$SEED' ]] ||
    die "PDB\$SEED cannot be used as the target PDB name."

  # Detect prior progress before repeating source checks. This allows an
  # interrupted workflow to continue from rename or post-clone validation.
  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  if pdb_exists "$created_pdb" "$inventory"; then
    created_exists="true"
  fi

  if pdb_exists "$final_pdb" "$inventory"; then
    final_exists="true"
  fi

  if [[ "$created_pdb" == "$final_pdb" ]]; then
    if [[ "$final_exists" == "true" ]]; then
      workflow_mode="POST_CLONE_RESUME"
    fi
  else
    case "${created_exists}:${final_exists}" in
      true:false)
        workflow_mode="RENAME_RESUME"
        ;;
      false:true)
        workflow_mode="POST_CLONE_RESUME"
        ;;
      true:true)
        die "Both intermediate PDB $created_pdb and final PDB $final_pdb exist in CDB $CDB_NAME. Automatic recovery is unsafe; review the inventory manually."
        ;;
      false:false)
        workflow_mode="NEW_CLONE"
        ;;
    esac
  fi

  printf '\nRemote Clone Recovery State\n'
  printf '%s\n' '---------------------------'
  printf 'Workflow Mode       : %s\n' "$workflow_mode"
  printf 'Intermediate PDB    : %s (%s)\n' "$created_pdb" "$created_exists"
  printf 'Final PDB           : %s (%s)\n' "$final_pdb" "$final_exists"

  if [[ "$workflow_mode" == "NEW_CLONE" ]]; then
    source_network_precheck
    prepare_source_tns_and_validate "$PDB_LIST"

    clone_cmd=(
      "$SUDO_BIN" "$DBAASCLI_BIN" pdb remote_clone
      --pdbname "$PDB_LIST"
      --source_db "$SOURCE_DB_UNIQUE_NAME"
      --source_db_scan "$SOURCE_DB_SCAN"
      --dbName "$CDB_NAME"
    )

    display_remote_clone_enterprise_plan
    confirm_action "Proceed with remote PDB clone/migration?"

    if [[ -n "${SOURCE_SYS_PASSWORD:-}" ]]; then
      info "Supplying source SYS password and reconfirmation through stdin."
      execute_with_password_stdin "$SOURCE_SYS_PASSWORD" "${clone_cmd[@]}" ||
        die "Remote clone failed."
    else
      execute_or_display "${clone_cmd[@]}" ||
        die "Remote clone failed."
    fi

    ok "Remote clone command completed. Expected DBaaSCLI PDB name: $created_pdb"

    if [[ "$TEST_MODE" != "true" ]]; then
      info "Waiting for DBaaSCLI to register $created_pdb before rename..."
      wait_for_pdb_state "$created_pdb" present 1800 15 ||
        die "Remote clone completed, but $created_pdb was not found in the target inventory within 30 minutes."
    fi
  elif [[ "$workflow_mode" == "RENAME_RESUME" ]]; then
    warn "Intermediate PDB $created_pdb already exists."
    info "Skipping source prechecks and DBaaSCLI remote clone."
    info "Resuming workflow from the PDB rename step."
  else
    warn "Final PDB $final_pdb already exists."
    info "Skipping source prechecks, DBaaSCLI remote clone, and rename."
    info "Resuming workflow from post-clone validation."
  fi

  if [[ "$workflow_mode" != "POST_CLONE_RESUME" &&
        "$created_pdb" != "$final_pdb" ]]; then
    # DBaaSCLI 26.2.2 supports only pdbname, newname, and dbname.
    rename_cmd=(
      "$SUDO_BIN" "$DBAASCLI_BIN" pdb rename
      --pdbname "$created_pdb"
      --newname "$final_pdb"
      --dbname "$CDB_NAME"
    )

    info "Renaming target PDB $created_pdb to $final_pdb..."
    execute_or_display "${rename_cmd[@]}" ||
      die "Clone completed as $created_pdb, but rename to $final_pdb failed. Run manually: sudo dbaascli pdb rename --pdbname $created_pdb --newname $final_pdb --dbname $CDB_NAME"

    if [[ "$TEST_MODE" != "true" ]]; then
      info "Verifying final PDB name..."
      wait_for_pdb_state "$final_pdb" present 900 15 ||
        die "Rename returned successfully, but $final_pdb was not found."
      wait_for_pdb_state "$created_pdb" absent 900 15 ||
        die "Final PDB $final_pdb exists, but old name $created_pdb is still present."
    fi

    ok "Target PDB renamed and verified: $created_pdb -> $final_pdb"
  fi

  info "Final target PDB name: $final_pdb"

  if declare -F report_target_pdb_details >/dev/null 2>&1; then
    info "Running post-clone target PDB report for $final_pdb..."

    if ! report_target_pdb_details "$final_pdb"; then
      warn "Clone/rename is complete, but the optional target PDB report failed."
      warn "The completed migration state is preserved."
    fi
  else
    warn "report_target_pdb_details is unavailable; post-clone reporting skipped."
  fi

  ok "Remote clone workflow completed successfully. Final PDB: $final_pdb"
}

# -----------------------------------------------------------------------------
# validate_post_clone_algorithm
# -----------------------------------------------------------------------------
validate_post_clone_algorithm() {
  POST_CLONE_FIX_ALGORITHM="$(
    printf '%s' "$POST_CLONE_FIX_ALGORITHM" |
      tr '[:lower:]' '[:upper:]'
  )"

  case "$POST_CLONE_FIX_ALGORITHM" in
    AES128|AES192|AES256) ;;
    *)
      die "Invalid fix encryption algorithm: $POST_CLONE_FIX_ALGORITHM. Use AES128, AES192, or AES256."
      ;;
  esac
}

# -----------------------------------------------------------------------------
# post_clone_open_pdb
# -----------------------------------------------------------------------------
post_clone_open_pdb() {
  local pdb_name="$1"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

declare
  l_open_mode v\$pdbs.open_mode%type;
begin
  select open_mode
    into l_open_mode
    from v\$pdbs
   where name='${pdb_name}';

  if l_open_mode = 'MOUNTED' then
    execute immediate
      'alter pluggable database ${pdb_name} open instances=all';
  end if;
exception
  when others then
    if sqlcode in (-65019, -65144, -65145) then
      null;
    else
      raise;
    end if;
end;
/

select name,
       open_mode,
       restricted
from v\$pdbs
where name='${pdb_name}';

exit"

  info "Opening PDB $pdb_name on all instances..."
  run_local_sql "$sql" ||
    warn "Initial PDB open returned an error. Continuing with remediation."
}

# -----------------------------------------------------------------------------
# post_clone_review_violations
# -----------------------------------------------------------------------------
post_clone_review_violations() {
  local pdb_name="$1"
  datapatch_review_violations "$pdb_name"
}

# -----------------------------------------------------------------------------
# post_clone_run_datapatch
# -----------------------------------------------------------------------------
post_clone_run_datapatch() {
  local pdb_name="$1"
  local oracle_home="$2"
  local saved_passes="$DATAPATCH_PASSES"

  [[ "$POST_CLONE_FIX_PASSES" =~ ^[1-9][0-9]*$ ]] ||
    die "--fix-passes must be a positive integer."

  DATAPATCH_PASSES="$POST_CLONE_FIX_PASSES"
  datapatch_run_passes "$oracle_home" "$pdb_name"
  DATAPATCH_PASSES="$saved_passes"
}

# -----------------------------------------------------------------------------
# post_clone_encrypt_tablespaces
# -----------------------------------------------------------------------------
post_clone_encrypt_tablespaces() {
  local pdb_name="$1"
  local exclude_clause=""
  local sql

  validate_post_clone_algorithm

  if [[ "$POST_CLONE_FIX_INCLUDE_SYSTEM" != "true" ]]; then
    exclude_clause="and tablespace_name not in ('SYSTEM','SYSAUX')"
  fi

  sql="whenever sqlerror exit sql.sqlcode
set serveroutput on lines 300 pages 1000
alter session set container=${pdb_name};

declare
  l_sql varchar2(4000);
begin
  for r in (
    select tablespace_name
      from dba_tablespaces
     where contents='PERMANENT'
       and encrypted='NO'
       ${exclude_clause}
     order by case tablespace_name
                when 'SYSTEM' then 1
                when 'SYSAUX' then 2
                else 3
              end,
              tablespace_name
  ) loop
    l_sql :=
      'alter tablespace ' ||
      dbms_assert.enquote_name(r.tablespace_name, false) ||
      ' encryption online using ''${POST_CLONE_FIX_ALGORITHM}'' encrypt';

    dbms_output.put_line(l_sql);
    execute immediate l_sql;
  end loop;
end;
/

select tablespace_name,
       contents,
       encrypted,
       block_size
from dba_tablespaces
order by tablespace_name;

exit"

  info "Encrypting unencrypted permanent tablespaces in $pdb_name..."
  info "Algorithm             : $POST_CLONE_FIX_ALGORITHM"
  info "Include SYSTEM/SYSAUX : $POST_CLONE_FIX_INCLUDE_SYSTEM"

  run_local_sql "$sql" ||
    die "Tablespace encryption failed for PDB $pdb_name."
}

# -----------------------------------------------------------------------------
# post_clone_validate_all
# -----------------------------------------------------------------------------
post_clone_validate_all() {
  local pdb_name="$1"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000 trimspool on
col owner for a30
col object_type for a35
col description for a90
col tablespace_name for a30
col name for a30
col cause for a25
col type for a10
col status for a15
col action for a75
col message for a155

alter session set container=${pdb_name};

prompt === INVALID OBJECTS ===
select owner,
       object_type,
       count(*) invalid_count
from dba_objects
where status='INVALID'
group by owner, object_type
order by owner, object_type;

prompt === SQL PATCH INVENTORY ===
select patch_id,
       patch_type,
       action,
       status,
       action_time,
       description
from dba_registry_sqlpatch
order by action_time desc;

prompt === TABLESPACE ENCRYPTION AND BLOCK SIZE ===
select tablespace_name,
       contents,
       encrypted,
       block_size
from dba_tablespaces
order by tablespace_name;

alter session set container=CDB\$ROOT;

prompt === PDB OPEN MODE ===
select name,
       open_mode,
       restricted
from v\$pdbs
where name='${pdb_name}';

prompt === UNRESOLVED PLUG-IN VIOLATIONS ===
select to_char(time,'YYYYMMDD HH24:MI:SS') time,
       name,
       cause,
       type,
       status,
       action,
       message
from pdb_plug_in_violations
where name='${pdb_name}'
  and status <> 'RESOLVED'
order by time;

exit"

  info "Running final validation for PDB $pdb_name..."
  run_local_sql "$sql" ||
    die "Final post-clone validation failed for PDB $pdb_name."
}

# -----------------------------------------------------------------------------
# post_clone_assert_clean_state
# -----------------------------------------------------------------------------
post_clone_assert_clean_state() {
  local pdb_name="$1"
  local sql
  local output
  local patch_pending=""
  local unencrypted_count=""
  local invalid_count=""
  local open_mode=""
  local restricted=""

  sql="whenever sqlerror exit sql.sqlcode
set heading off feedback off verify off echo off pages 0 trimspool on
alter session set container=CDB\$ROOT;

select 'PATCH_PENDING=' || count(*)
from pdb_plug_in_violations
where name='${pdb_name}'
  and status <> 'RESOLVED'
  and cause='SQL Patch';

select 'ENCRYPT_PENDING=' || count(*)
from pdb_plug_in_violations
where name='${pdb_name}'
  and status <> 'RESOLVED'
  and cause='is encrypted tablespace?';

select 'OPEN_MODE=' || open_mode
from v\$pdbs
where name='${pdb_name}';

select 'RESTRICTED=' || nvl(restricted,'NO')
from v\$pdbs
where name='${pdb_name}';

alter session set container=${pdb_name};

select 'UNENCRYPTED=' || count(*)
from dba_tablespaces
where contents='PERMANENT'
  and encrypted='NO';

select 'INVALIDS=' || count(*)
from dba_objects
where status='INVALID';

exit"

  output="$(run_local_sql "$sql")" ||
    die "Unable to collect final remediation status for PDB $pdb_name."

  patch_pending="$(
    printf '%s\n' "$output" |
      awk -F= '/^PATCH_PENDING=/ {gsub(/[[:space:]]/,"",$2); print $2; exit}'
  )"
  unencrypted_count="$(
    printf '%s\n' "$output" |
      awk -F= '/^UNENCRYPTED=/ {gsub(/[[:space:]]/,"",$2); print $2; exit}'
  )"
  invalid_count="$(
    printf '%s\n' "$output" |
      awk -F= '/^INVALIDS=/ {gsub(/[[:space:]]/,"",$2); print $2; exit}'
  )"
  open_mode="$(
    printf '%s\n' "$output" |
      awk -F= '/^OPEN_MODE=/ {sub(/^[^=]*=/,""); gsub(/^[[:space:]]+|[[:space:]]+$/,""); print; exit}'
  )"
  restricted="$(
    printf '%s\n' "$output" |
      awk -F= '/^RESTRICTED=/ {sub(/^[^=]*=/,""); gsub(/^[[:space:]]+|[[:space:]]+$/,""); print; exit}'
  )"

  patch_pending="${patch_pending:-999}"
  unencrypted_count="${unencrypted_count:-999}"
  invalid_count="${invalid_count:-999}"
  open_mode="${open_mode:-UNKNOWN}"
  restricted="${restricted:-UNKNOWN}"

  printf '\nFinal Remediation Result\n'
  printf '%s\n' '------------------------'
  printf 'PDB                 : %s\n' "$pdb_name"
  printf 'Open Mode           : %s\n' "$open_mode"
  printf 'Restricted          : %s\n' "$restricted"
  printf 'Pending SQL Patches : %s\n' "$patch_pending"
  printf 'Unencrypted Perm TS : %s\n' "$unencrypted_count"
  printf 'Invalid Objects     : %s\n' "$invalid_count"

  [[ "$open_mode" == "READ WRITE" ]] ||
    die "PDB $pdb_name is not READ WRITE after remediation."

  [[ "$restricted" == "NO" ]] ||
    die "PDB $pdb_name remains restricted after remediation."

  if [[ "$POST_CLONE_FIX_REQUIRE_CLEAN_PATCH" == "true" ]] &&
     (( patch_pending > 0 )); then
    die "SQL patch violations remain pending for PDB $pdb_name."
  fi

  if [[ "$POST_CLONE_FIX_REQUIRE_ENCRYPTED" == "true" ]] &&
     (( unencrypted_count > 0 )); then
    die "$unencrypted_count permanent tablespace(s) remain unencrypted in PDB $pdb_name."
  fi

  if [[ "$POST_CLONE_FIX_FAIL_ON_INVALIDS" == "true" ]] &&
     (( invalid_count > 0 )); then
    die "$invalid_count invalid object(s) remain in PDB $pdb_name."
  fi

  ok "Final remediation assertions passed for PDB $pdb_name."
}

# -----------------------------------------------------------------------------
# post_clone_report_rac_warning
# -----------------------------------------------------------------------------
post_clone_report_rac_warning() {
  local pdb_name="$1"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
col cause for a25
col status for a15
col message for a155
alter session set container=CDB\$ROOT;

select cause,
       status,
       message
from pdb_plug_in_violations
where name='${pdb_name}'
  and status <> 'RESOLVED'
  and cause='OPTION'
  and upper(message) like '%RAC MISMATCH%'
order by time;

exit"

  info "Checking for remaining RAC option warning..."
  run_local_sql "$sql" ||
    warn "Unable to report RAC option warning for PDB $pdb_name."

  warn "A RAC option mismatch can remain because RAC is installed at the CDB level, not independently inside a PDB."
}


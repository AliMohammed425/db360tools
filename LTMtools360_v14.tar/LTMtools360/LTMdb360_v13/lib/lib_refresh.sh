#!/usr/bin/env bash
# Module version: 3.1.15
# LTMdbMigration360 module: lib_refresh.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# validate_refresh_interval
# -----------------------------------------------------------------------------
validate_refresh_interval() {
  [[ "$REFRESH_INTERVAL" =~ ^[0-9]+$ ]] ||
    die "Refresh interval must be a non-negative integer."

  (( REFRESH_INTERVAL < 3000 )) ||
    die "Refresh interval in minutes must be less than 3000."
}

# -----------------------------------------------------------------------------
# action_refreshable_create
# -----------------------------------------------------------------------------
action_refreshable_create() {
  local target_pdb
  local refresh_clause
  local escaped_keystore_password
  local keystore_clause
  local sql

  require_cdb
  require_single_pdb
  validate_cdb_exists

  [[ -n "$TARGET_PDB_NAME" ]] ||
    die "Target refreshable PDB name is required with -t."

  validate_refresh_interval
  prepare_source_tns_and_validate "$PDB_LIST"
  ensure_database_link
  require_target_keystore_password
  validate_target_keystore

  escaped_keystore_password="$(escape_sql_double_quoted_value "$TARGET_KEYSTORE_PASSWORD")"
  keystore_clause="KEYSTORE IDENTIFIED BY \"${escaped_keystore_password}\""

  PDB_LIST="$(normalize_name "$PDB_LIST")"
  target_pdb="$(normalize_name "$TARGET_PDB_NAME")"
  validate_oracle_name "$PDB_LIST" "source PDB name"
  validate_oracle_name "$target_pdb" "target refreshable PDB name"

  if (( REFRESH_INTERVAL == 0 )); then
    refresh_clause="REFRESH MODE MANUAL"
  else
    refresh_clause="REFRESH MODE EVERY ${REFRESH_INTERVAL} MINUTES"
  fi

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;
alter session set global_names=false;
create pluggable database ${target_pdb}
  from ${PDB_LIST}@${REFRESH_DBLINK}
  ${keystore_clause}
  ${refresh_clause};
select pdb_name, status, refresh_mode
from dba_pdbs
where pdb_name='${target_pdb}';
exit"

  cat <<PLAN

Refreshable PDB Creation Plan
-----------------------------
Target CDB       : $CDB_NAME
Source DB        : $SOURCE_DB_UNIQUE_NAME
Source Service   : ${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}
Source SCAN/IP   : $SOURCE_DB_SCAN
Source Port      : $SOURCE_DB_PORT
Source PDB       : $PDB_LIST
Target PDB       : $target_pdb
Database Link    : $REFRESH_DBLINK
Target Keystore  : PASSWORD SUPPLIED
Refresh Mode     : $([[ "$REFRESH_INTERVAL" == "0" ]] && echo "MANUAL" || echo "EVERY $REFRESH_INTERVAL MINUTES")
Execution        : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Proceed with refreshable PDB creation?"
  run_local_sql "$sql" || die "Refreshable PDB creation failed."
  ok "Refreshable PDB created: $target_pdb"
  drop_database_link_if_requested
}

# -----------------------------------------------------------------------------
# action_refreshable_refresh
# -----------------------------------------------------------------------------
action_refreshable_refresh() {
  local exact_pdb
  local sql

  require_cdb
  require_single_pdb
  validate_cdb_exists

  exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "PDB $PDB_LIST was not found in CDB $CDB_NAME using v\$pdbs."

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

declare
  l_open_mode v\$pdbs.open_mode%type;
begin
  select open_mode
    into l_open_mode
    from v\$pdbs
   where name='${exact_pdb}';

  if l_open_mode <> 'MOUNTED' then
    execute immediate
      'alter pluggable database ${exact_pdb} close immediate instances=all';
  end if;
end;
/

alter pluggable database ${exact_pdb} refresh;

select p.pdb_name,
       p.status,
       p.refresh_mode,
       v.open_mode
from dba_pdbs p
join v\$pdbs v
  on v.name = p.pdb_name
where p.pdb_name='${exact_pdb}';

exit"

  confirm_action "Refresh PDB $exact_pdb now?"
  run_local_sql "$sql" || die "Refresh failed for PDB $exact_pdb."
  ok "Refresh completed: $exact_pdb"
}

# -----------------------------------------------------------------------------
# action_refreshable_status
# -----------------------------------------------------------------------------
action_refreshable_status() {
  local pdb
  local exact_pdb
  local sql

  require_cdb
  require_single_pdb
  validate_cdb_exists

  pdb="$(normalize_name "$PDB_LIST")"
  exact_pdb="$(resolve_existing_pdb_sql "$pdb")" ||
    die "PDB $pdb was not found in CDB $CDB_NAME using v\$pdbs."

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
col pdb_name for a30
col status for a15
col refresh_mode for a15
col refresh_interval for a20
col refresh_scn for 99999999999999999999
col open_mode for a15
alter session set container=CDB\$ROOT;

select p.pdb_name,
       p.status,
       p.refresh_mode,
       p.refresh_interval,
       p.refresh_scn,
       v.open_mode,
       v.restricted
from dba_pdbs p
join v\$pdbs v
  on v.name = p.pdb_name
where p.pdb_name='${exact_pdb}';

exit"

  run_local_sql "$sql"
}

# -----------------------------------------------------------------------------
# action_refreshable_switchover
# -----------------------------------------------------------------------------
action_refreshable_switchover() {
  local source_pdb
  local clone_pdb
  local refresh_clause
  local sql

  require_single_pdb
  require_source_db
  require_source_scan
  validate_source_port

  [[ -n "$TARGET_PDB_NAME" ]] ||
    die "Refreshable clone PDB name is required with -t."

  validate_refresh_interval

  if [[ -z "$REFRESH_DBLINK" ]]; then
    REFRESH_DBLINK="$(generate_default_dblink_name)"
    warn "Generated database link name: $REFRESH_DBLINK"
    warn "For switchover, this reciprocal link must exist in the current source CDB."
  fi

  validate_dblink_name "$REFRESH_DBLINK"

  source_pdb="$(normalize_name "$PDB_LIST")"
  clone_pdb="$(normalize_name "$TARGET_PDB_NAME")"
  validate_oracle_name "$source_pdb" "source primary PDB name"
  validate_oracle_name "$clone_pdb" "refreshable clone PDB name"

  if (( REFRESH_INTERVAL == 0 )); then
    refresh_clause="REFRESH MODE MANUAL"
  else
    refresh_clause="REFRESH MODE EVERY ${REFRESH_INTERVAL} MINUTES"
  fi

  sql="alter session set container=${source_pdb};
select sys_context('USERENV','CON_NAME') current_container from dual;
${refresh_clause}
"
  # Build the exact ALTER statement separately for clarity.
  sql="alter session set container=${source_pdb};
alter session set global_names=false;
select sys_context('USERENV','CON_NAME') current_container from dual;
alter pluggable database
  ${refresh_clause}
  from ${clone_pdb}@${REFRESH_DBLINK}
  switchover;
select pdb_name, status, refresh_mode
from dba_pdbs
where pdb_name='${source_pdb}';"

  cat <<PLAN

Refreshable PDB Switchover Plan
-------------------------------
Current Primary PDB : $source_pdb
Refreshable Clone   : $clone_pdb
Source DB           : $SOURCE_DB_UNIQUE_NAME
Source Service      : ${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}
Source Address      : $SOURCE_DB_SCAN:$SOURCE_DB_PORT
Link to Clone CDB   : $REFRESH_DBLINK
Old Source Mode     : $([[ "$REFRESH_INTERVAL" == "0" ]] && echo "MANUAL" || echo "EVERY $REFRESH_INTERVAL MINUTES")
Execution Location  : Current primary PDB
Execution           : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Proceed with refreshable PDB switchover?"
  run_remote_source_sql "$sql" ||
    die "Refreshable PDB switchover failed."

  ok "Switchover command completed."
  info "The former source PDB is now the refreshable clone."
  info "Validate the new primary PDB $clone_pdb on its target CDB."
}

# -----------------------------------------------------------------------------
# action_refreshable_convert_rw
# -----------------------------------------------------------------------------
action_refreshable_convert_rw() {
  local refresh_pdb=""
  local sql=""
  local saved_passes=""

  require_cdb
  require_single_pdb
  validate_cdb_exists

  refresh_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "Refreshable PDB $PDB_LIST not found in CDB $CDB_NAME."

  resolve_local_oracle_environment

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

declare
  l_refresh_mode dba_pdbs.refresh_mode%type;
  l_open_mode    v\$pdbs.open_mode%type;
begin
  select p.refresh_mode, v.open_mode
    into l_refresh_mode, l_open_mode
    from dba_pdbs p
    join v\$pdbs v on v.name=p.pdb_name
   where p.pdb_name='${refresh_pdb}';

  if l_refresh_mode = 'NONE' then
    raise_application_error(-20001,
      'PDB ${refresh_pdb} is not refreshable.');
  end if;

  if l_open_mode <> 'MOUNTED' then
    execute immediate
      'alter pluggable database ${refresh_pdb} close immediate instances=all';
  end if;
end;
/

alter pluggable database ${refresh_pdb} refresh;
alter pluggable database ${refresh_pdb} refresh mode none;
alter pluggable database ${refresh_pdb} open read write instances=all;
alter pluggable database ${refresh_pdb} save state instances=all;

select p.pdb_name,
       p.status,
       p.refresh_mode,
       v.open_mode,
       v.restricted
from dba_pdbs p
join v\$pdbs v on v.name=p.pdb_name
where p.pdb_name='${refresh_pdb}';

exit"

  cat <<PLAN

Final Cutover Plan
------------------
Target CDB          : $CDB_NAME
Refreshable PDB     : $refresh_pdb
Final Refresh       : YES
Refresh Mode NONE   : YES
Open READ WRITE     : YES
Datapatch           : $FINAL_CUTOVER_DATAPATCH
Datapatch Passes    : $FINAL_CUTOVER_DATAPATCH_PASSES
Compile UTLRP       : $FINAL_CUTOVER_COMPILE_UTLRP
Validate Invalids   : $FINAL_CUTOVER_VALIDATE_INVALIDS
Validate SQL Patches: YES
Validate Block Sizes: YES
Reversible          : NO
PLAN

  warn "This permanently disables refresh mode for $refresh_pdb."
  confirm_action "Proceed with final cutover, Datapatch, UTLRP, and validation?"

  run_local_sql "$sql" ||
    die "Final cutover failed for $refresh_pdb."

  ok "PDB converted to standalone READ WRITE: $refresh_pdb"

  if [[ "$FINAL_CUTOVER_DATAPATCH" == "true" ]]; then
    saved_passes="$DATAPATCH_PASSES"
    DATAPATCH_PASSES="$FINAL_CUTOVER_DATAPATCH_PASSES"

    [[ "$FINAL_CUTOVER_VALIDATE_INVALIDS" == "true" ]] &&
      validate_invalid_objects "$refresh_pdb" "BEFORE FINAL DATAPATCH"

    datapatch_review_violations "$refresh_pdb"
    datapatch_run_passes "$ORACLE_HOME_RESOLVED" "$refresh_pdb"

    [[ "$FINAL_CUTOVER_COMPILE_UTLRP" == "true" ]] &&
      compile_utlrp_pdb "$refresh_pdb" "$ORACLE_HOME_RESOLVED"

    datapatch_bounce_pdb "$refresh_pdb"
    datapatch_review_violations "$refresh_pdb"

    [[ "$FINAL_CUTOVER_VALIDATE_INVALIDS" == "true" ]] &&
      validate_invalid_objects "$refresh_pdb" "AFTER FINAL DATAPATCH/UTLRP"

    datapatch_verify_sql_inventory "$refresh_pdb"
    datapatch_verify_block_sizes "$refresh_pdb"

    DATAPATCH_PASSES="$saved_passes"
    ok "Final-cutover Datapatch, UTLRP, and validation completed."
  else
    warn "Final-cutover Datapatch was skipped."
  fi
}


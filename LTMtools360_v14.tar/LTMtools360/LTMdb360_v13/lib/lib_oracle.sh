#!/usr/bin/env bash
SOURCE_PDB_HAS_16K="${SOURCE_PDB_HAS_16K:-false}"

SOURCE_DB_DOMAIN="${SOURCE_DB_DOMAIN:-}"
SOURCE_DBAASCLI_SERVICE="${SOURCE_DBAASCLI_SERVICE:-}"
SOURCE_DBAASCLI_TNS_ALIAS="${SOURCE_DBAASCLI_TNS_ALIAS:-}"

# Module version: 3.2.7
# LTMdbMigration360 module: lib_oracle.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# run_dbaascli
# -----------------------------------------------------------------------------
run_dbaascli() {
  "$SUDO_BIN" "$DBAASCLI_BIN" "$@"
}

# -----------------------------------------------------------------------------
# resolve_local_oracle_environment
# -----------------------------------------------------------------------------
resolve_local_oracle_environment() {
  local requested_db="$CDB_NAME"
  local candidate_db="$CDB_NAME"
  local status_output=""
  local config_output=""
  local pmon_sid=""
  local oratab_sid=""
  local db_unique_name=""

  # 1. Try the DBaaSCLI/Clusterware database name directly.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    status_output="$(
      "$SUDO_BIN" -u oracle /bin/bash -c \
        "srvctl status database -d '$candidate_db' 2>/dev/null" || true
    )"

    TARGET_ORACLE_SID="$(
      printf '%s\n' "$status_output" |
        awk '/^Instance[[:space:]]+/ {print $2; exit}'
    )"
  fi

  # 2. Resolve DB_UNIQUE_NAME from DBaaSCLI JSON and retry srvctl.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    db_unique_name="$(
      run_dbaascli system getDatabases 2>/dev/null |
        awk -v requested="$requested_db" '
          function clean(v) {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
            gsub(/^"|"[,]?$/, "", v)
            return v
          }

          /"dbName"[[:space:]]*:/ {
            line=$0
            sub(/^.*"dbName"[[:space:]]*:[[:space:]]*/, "", line)
            current_db=clean(line)
          }

          /"dbUniqueName"[[:space:]]*:/ {
            line=$0
            sub(/^.*"dbUniqueName"[[:space:]]*:[[:space:]]*/, "", line)
            unique_name=clean(line)

            if (toupper(current_db) == toupper(requested)) {
              print unique_name
              exit
            }
          }
        '
    )"

    if [[ -n "$db_unique_name" ]]; then
      candidate_db="$db_unique_name"
      info "Resolved target DB_UNIQUE_NAME: $candidate_db"

      status_output="$(
        "$SUDO_BIN" -u oracle /bin/bash -c \
          "srvctl status database -d '$candidate_db' 2>/dev/null" || true
      )"

      TARGET_ORACLE_SID="$(
        printf '%s\n' "$status_output" |
          awk '/^Instance[[:space:]]+/ {print $2; exit}'
      )"
    fi
  fi

  # 3. Try running PMON processes.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    pmon_sid="$(
      ps -ef |
        awk -v db="$requested_db" '
          /ora_pmon_/ && $0 !~ /awk/ {
            sid=$NF
            sub(/^ora_pmon_/, "", sid)

            if (toupper(sid) ~ "^" toupper(db)) {
              print sid
              exit
            }
          }
        '
    )"

    [[ -n "$pmon_sid" ]] && TARGET_ORACLE_SID="$pmon_sid"
  fi

  # 4. Try /etc/oratab using CDB name, DB_UNIQUE_NAME, or SID prefix.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    oratab_sid="$(
      awk -F: -v db="$requested_db" -v uniq="$db_unique_name" '
        $1 !~ /^#/ && NF >= 2 {
          sid=$1

          if (toupper(sid) == toupper(db) ||
              (uniq != "" && toupper(sid) == toupper(uniq)) ||
              toupper(sid) ~ "^" toupper(db)) {
            print sid
            exit
          }
        }
      ' /etc/oratab 2>/dev/null
    )"

    [[ -n "$oratab_sid" ]] && TARGET_ORACLE_SID="$oratab_sid"
  fi

  ORACLE_HOME_RESOLVED="${TARGET_ORACLE_HOME:-}"

  # Resolve ORACLE_HOME from srvctl.
  if [[ -z "$ORACLE_HOME_RESOLVED" && -n "$candidate_db" ]]; then
    config_output="$(
      "$SUDO_BIN" -u oracle /bin/bash -c \
        "srvctl config database -d '$candidate_db' 2>/dev/null" || true
    )"

    ORACLE_HOME_RESOLVED="$(
      printf '%s\n' "$config_output" |
        awk -F':[[:space:]]*' '
          tolower($1) ~ /^oracle home$/ {
            print $2
            exit
          }
        '
    )"
  fi

  # Fall back to /etc/oratab.
  if [[ -z "$ORACLE_HOME_RESOLVED" && -n "$TARGET_ORACLE_SID" ]]; then
    ORACLE_HOME_RESOLVED="$(
      awk -F: -v sid="$TARGET_ORACLE_SID" '
        $1 !~ /^#/ && toupper($1) == toupper(sid) {
          print $2
          exit
        }
      ' /etc/oratab 2>/dev/null
    )"
  fi

  # Derive ORACLE_HOME from the running PMON process.
  if [[ -z "$ORACLE_HOME_RESOLVED" && -n "$TARGET_ORACLE_SID" ]]; then
    local pmon_pid=""
    local oracle_exe=""

    pmon_pid="$(
      ps -eo pid=,args= |
        awk -v sid="$TARGET_ORACLE_SID" '
          index($0, "ora_pmon_" sid) {
            print $1
            exit
          }
        '
    )"

    if [[ -n "$pmon_pid" ]]; then
      oracle_exe="$(
        "$SUDO_BIN" readlink -f "/proc/${pmon_pid}/exe" 2>/dev/null || true
      )"

      if [[ "$oracle_exe" == */bin/oracle ]]; then
        ORACLE_HOME_RESOLVED="${oracle_exe%/bin/oracle}"
      fi
    fi
  fi

  # Search common Oracle database-home paths as a final automatic fallback.
  if [[ -z "$ORACLE_HOME_RESOLVED" ]]; then
    ORACLE_HOME_RESOLVED="$(
      for sqlplus_bin in \
        /u01/app/oracle/product/*/dbhome_*/bin/sqlplus \
        /u02/app/oracle/product/*/dbhome_*/bin/sqlplus \
        /opt/oracle/product/*/dbhome_*/bin/sqlplus
      do
        [[ -x "$sqlplus_bin" ]] || continue
        dirname "$(dirname "$sqlplus_bin")"
        break
      done
    )"
  fi

  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    error "Unable to determine target Oracle SID automatically."
    error "Checked srvctl database name: $requested_db"
    [[ -n "$db_unique_name" ]] &&
      error "Checked srvctl DB_UNIQUE_NAME: $db_unique_name"
    error "Checked PMON processes and /etc/oratab."
    die "Supply -O ORACLE_SID."
  fi

  [[ -n "${ORACLE_HOME_RESOLVED:-}" &&
     -x "$ORACLE_HOME_RESOLVED/bin/sqlplus" ]] ||
    die "Unable to determine a valid ORACLE_HOME for SID $TARGET_ORACLE_SID. Supply -J ORACLE_HOME."

  info "Oracle SID  : $TARGET_ORACLE_SID"
  info "Oracle Home : $ORACLE_HOME_RESOLVED"
}

# -----------------------------------------------------------------------------
# run_local_sql
# -----------------------------------------------------------------------------
run_local_sql() {
  local sql_text="$1"

  resolve_local_oracle_environment

  if [[ "$TEST_MODE" == "true" ]]; then
    printf '%s\n' "DRY RUN SQL:"
    printf '%s\n' "$sql_text"
    return 0
  fi

  printf '%s\n' "$sql_text" |
    "$SUDO_BIN" -u oracle env \
      ORACLE_SID="$TARGET_ORACLE_SID" \
      ORACLE_HOME="$ORACLE_HOME_RESOLVED" \
      PATH="$ORACLE_HOME_RESOLVED/bin:/usr/bin:/bin" \
      "$ORACLE_HOME_RESOLVED/bin/sqlplus" -s "/ as sysdba"
}

# -----------------------------------------------------------------------------
# run_remote_source_sql
# -----------------------------------------------------------------------------
run_remote_source_sql() {
  local sql_text="$1"
  local service="${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}"
  local connect_descriptor
  local sqlplus_bin

  require_source_db
  require_source_scan
  validate_source_port

  [[ -n "$SOURCE_SYS_PASSWORD" ]] ||
    read -r -s -p "Enter source SYS password: " SOURCE_SYS_PASSWORD
  printf '\n'

  [[ -n "$service" ]] || die "Source service is required; use -g."

  # Use the locally installed Oracle client from the resolved target
  # ORACLE_HOME. Do not depend on sqlplus being present in the opc PATH.
  resolve_local_oracle_environment
  sqlplus_bin="$ORACLE_HOME_RESOLVED/bin/sqlplus"

  [[ -x "$sqlplus_bin" ]] ||
    die "SQL*Plus executable was not found: $sqlplus_bin"

  connect_descriptor="//${SOURCE_DB_SCAN%%,*}:${SOURCE_DB_PORT}/${service}"

  if [[ "$TEST_MODE" == "true" ]]; then
    printf '%s\n' "DRY RUN REMOTE SQL:"
    printf '%s\n' "SQLPLUS: $sqlplus_bin"
    printf '%s\n' "CONNECT SYS/<redacted>@${connect_descriptor} AS SYSDBA"
    printf '%s\n' "$sql_text"
    return 0
  fi

  {
    printf 'whenever sqlerror exit sql.sqlcode\n'
    printf 'set echo off feedback on heading on pages 1000 lines 300\n'
    printf 'connect sys/"%s"@%s as sysdba\n' \
      "$SOURCE_SYS_PASSWORD" "$connect_descriptor"
    printf '%s\n' "$sql_text"
    printf 'exit\n'
  } |
    "$SUDO_BIN" -u oracle env \
      ORACLE_HOME="$ORACLE_HOME_RESOLVED" \
      PATH="$ORACLE_HOME_RESOLVED/bin:/usr/bin:/bin" \
      TNS_ADMIN="${TNS_ADMIN:-$ORACLE_HOME_RESOLVED/network/admin}" \
      "$sqlplus_bin" -s /nolog
}

# -----------------------------------------------------------------------------
# require_cdb
# -----------------------------------------------------------------------------
require_cdb() {
  prompt_required CDB_NAME "Enter existing CDB name: "

  # Preserve the exact CDB case because DBaaSCLI maps --dbname to a
  # case-sensitive cloud registry filename, for example bny.ini.
  CDB_NAME="$(printf '%s' "$CDB_NAME" | xargs)"

  [[ "$CDB_NAME" =~ ^[A-Za-z][A-Za-z0-9_$#.-]{0,127}$ ]] ||
    die "Invalid CDB name: $CDB_NAME"
}

# -----------------------------------------------------------------------------
# require_single_pdb
# -----------------------------------------------------------------------------
require_single_pdb() {
  prompt_required PDB_LIST "Enter PDB name: "

  [[ "$PDB_LIST" != *,* ]] ||
    die "Only one PDB may be supplied for action: $ACTION"

  # Accept upper, lower, or mixed-case user input. The exact registered PDB
  # name is resolved from DBaaSCLI inventory before the operation is executed.
  PDB_LIST="$(printf '%s' "$PDB_LIST" | xargs)"

  [[ "$PDB_LIST" =~ ^[A-Za-z][A-Za-z0-9_$#]{0,29}$ ]] ||
    die "Invalid PDB name: $PDB_LIST. Use 1-30 Oracle identifier characters."

  [[ "${PDB_LIST^^}" != 'PDB\$SEED' ]] ||
    die "This action is not allowed for PDB\$SEED."
}

# -----------------------------------------------------------------------------
# resolve_exact_inventory_name
# -----------------------------------------------------------------------------
resolve_exact_inventory_name() {
  local requested_name="$1"
  local inventory="$2"
  local exact_name=""

  exact_name="$(
    printf '%s\n' "$inventory" |
      awk -v requested="$requested_name" '
        {
          for (i = 1; i <= NF; i++) {
            token=$i

            # Remove common table/JSON delimiters while preserving valid
            # database-name characters such as _, $, #, hyphen, and period.
            gsub(/^[[:space:]"'\''([{<,:;=]+/, "", token)
            gsub(/[[:space:]"'\''\])}>,:;=]+$/, "", token)

            if (toupper(token) == toupper(requested)) {
              print token
              exit
            }
          }
        }
      '
  )"

  [[ -n "$exact_name" ]] || return 1
  printf '%s\n' "$exact_name"
}

# -----------------------------------------------------------------------------
# validate_cdb_exists
# -----------------------------------------------------------------------------
validate_cdb_exists() {
  local requested_cdb="$CDB_NAME"
  local output=""
  local exact_cdb=""

  info "Validating CDB: $requested_cdb"

  # DBaaSCLI 26.x returns JSON from system getDatabases. Older versions may
  # require database list, which returns text lines such as DB Name=bny.
  if ! output="$(run_dbaascli system getDatabases 2>&1)"; then
    warn "system getDatabases failed; retrying with database list."
    if ! output="$(run_dbaascli database list 2>&1)"; then
      printf '%s\n' "$output"
      die "Unable to retrieve the DBaaSCLI database inventory."
    fi
  fi

  # Supported inventory formats:
  #   JSON   : "dbName" : "bny",
  #   Legacy : 2.DB Name=bny
  #
  # Compare case-insensitively, but retain the exact registered spelling.
  exact_cdb="$(
    printf '%s\n' "$output" |
      awk -v requested="$requested_cdb" '
        function trim(value) {
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
          return value
        }

        {
          line=$0
          candidate=""

          if (line ~ /"dbName"[[:space:]]*:/) {
            sub(/^.*"dbName"[[:space:]]*:[[:space:]]*"/, "", line)
            sub(/".*$/, "", line)
            candidate=trim(line)
          }
          else if (line ~ /DB Name[[:space:]]*=/) {
            sub(/^.*DB Name[[:space:]]*=[[:space:]]*/, "", line)
            sub(/[[:space:]]+$/, "", line)
            candidate=trim(line)
          }

          if (candidate != "" &&
              toupper(candidate) == toupper(requested)) {
            print candidate
            exit
          }
        }
      '
  )"

  if [[ -z "$exact_cdb" ]]; then
    printf '%s\n' "$output"
    die "CDB $requested_cdb was not found in DBaaSCLI database inventory."
  fi

  CDB_NAME="$exact_cdb"

  info "Requested CDB name: $requested_cdb"
  info "Resolved CDB name : $CDB_NAME"

  if [[ "$requested_cdb" != "$CDB_NAME" ]]; then
    warn "CDB names $requested_cdb and $CDB_NAME refer to the same registered database."
    warn "Using exact DBaaSCLI registry name: $CDB_NAME"
  fi

  ok "CDB $CDB_NAME exists."
}

# -----------------------------------------------------------------------------
# get_pdb_inventory
# -----------------------------------------------------------------------------
get_pdb_inventory() {
  run_dbaascli database getPDBs --dbName "$CDB_NAME"
}

# -----------------------------------------------------------------------------
# resolve_exact_pdb_name
# -----------------------------------------------------------------------------
resolve_exact_pdb_name() {
  local requested_name="$1"
  local inventory="$2"

  resolve_exact_inventory_name "$requested_name" "$inventory"
}

# -----------------------------------------------------------------------------
# pdb_exists
# -----------------------------------------------------------------------------
pdb_exists() {
  local pdb_name="$1"
  local inventory="$2"

  resolve_exact_pdb_name "$pdb_name" "$inventory" >/dev/null 2>&1
}

# -----------------------------------------------------------------------------
# resolve_existing_pdb
# -----------------------------------------------------------------------------
resolve_existing_pdb() {
  local requested_name="$1"
  local inventory="$2"
  local exact_name=""

  exact_name="$(resolve_exact_pdb_name "$requested_name" "$inventory")" ||
    return 1

  printf '%s\n' "$exact_name"
}

# -----------------------------------------------------------------------------
# require_source_db
# -----------------------------------------------------------------------------
require_source_db() {
  prompt_required SOURCE_DB_UNIQUE_NAME "Enter source DB_UNIQUE_NAME: "
  SOURCE_DB_UNIQUE_NAME="$(printf '%s' "$SOURCE_DB_UNIQUE_NAME" | xargs)"
  [[ "$SOURCE_DB_UNIQUE_NAME" =~ ^[A-Za-z][A-Za-z0-9_$#.-]{0,127}$ ]] ||
    die "Invalid source DB_UNIQUE_NAME: $SOURCE_DB_UNIQUE_NAME"
}

# -----------------------------------------------------------------------------
# require_source_scan
# -----------------------------------------------------------------------------
require_source_scan() {
  prompt_required SOURCE_DB_SCAN \
    "Enter source SCAN/hostname or comma-separated IP addresses: "
  SOURCE_DB_SCAN="$(printf '%s' "$SOURCE_DB_SCAN" | tr -d '[:space:]')"
  [[ -n "$SOURCE_DB_SCAN" ]] || die "Source SCAN/hostname is required."
}

# -----------------------------------------------------------------------------
# validate_source_port
# -----------------------------------------------------------------------------
validate_source_port() {
  [[ "$SOURCE_DB_PORT" =~ ^[0-9]+$ ]] ||
    die "Invalid source listener port: $SOURCE_DB_PORT"
  (( SOURCE_DB_PORT >= 1 && SOURCE_DB_PORT <= 65535 )) ||
    die "Source listener port must be between 1 and 65535."
}

# -----------------------------------------------------------------------------
# source_network_precheck
# -----------------------------------------------------------------------------
source_network_precheck() {
  local endpoint
  local failures=0
  local -a endpoints=()

  IFS=',' read -r -a endpoints <<< "$SOURCE_DB_SCAN"

  printf '\nSource Network Precheck\n'
  printf '%s\n' '-----------------------'

  for endpoint in "${endpoints[@]}"; do
    endpoint="$(printf '%s' "$endpoint" | xargs)"
    [[ -n "$endpoint" ]] || continue

    if getent ahosts "$endpoint" >/dev/null 2>&1; then
      printf '  %-35s DNS/Host resolution: PASS\n' "$endpoint"
    else
      printf '  %-35s DNS/Host resolution: FAIL\n' "$endpoint"
      ((failures+=1))
      continue
    fi

    if command -v timeout >/dev/null 2>&1 &&
       timeout 3 bash -c "exec 3<>/dev/tcp/${endpoint}/${SOURCE_DB_PORT}" \
         >/dev/null 2>&1; then
      printf '  %-35s TCP/%s: PASS\n' "$endpoint" "$SOURCE_DB_PORT"
    else
      printf '  %-35s TCP/%s: WARN (not verified)\n' \
        "$endpoint" "$SOURCE_DB_PORT"
    fi
  done

  (( failures == 0 )) ||
    warn "One or more source endpoints did not resolve. DBaaSCLI may fail."
}


# -----------------------------------------------------------------------------
# initialize_oracle_environment
# -----------------------------------------------------------------------------
initialize_oracle_environment() {
  require_cdb
  validate_cdb_exists
  resolve_local_oracle_environment

  export ORACLE_HOME="$ORACLE_HOME_RESOLVED"
  export ORACLE_SID="$TARGET_ORACLE_SID"
  export TNS_ADMIN="${TNS_ADMIN:-$ORACLE_HOME_RESOLVED/network/admin}"

  [[ -x "$ORACLE_HOME/bin/sqlplus" ]] ||
    die "SQL*Plus was not found under Oracle Home: $ORACLE_HOME"

  [[ -x "$ORACLE_HOME/bin/tnsping" ]] ||
    die "tnsping was not found under Oracle Home: $ORACLE_HOME"

  info "Oracle environment initialized."
  info "Oracle SID  : $ORACLE_SID"
  info "Oracle Home : $ORACLE_HOME"
  info "TNS Admin   : $TNS_ADMIN"
}

# -----------------------------------------------------------------------------
# generate_source_tns_alias
# -----------------------------------------------------------------------------
generate_source_tns_alias() {
  local base="${SOURCE_DB_UNIQUE_NAME:-SOURCE}"
  base="$(printf '%s' "$base" | tr '[:lower:]' '[:upper:]')"
  base="$(printf '%s' "$base" | sed 's/[^A-Z0-9_]/_/g')"
  printf 'LTM_%s\n' "${base:0:120}"
}

# -----------------------------------------------------------------------------
# source_tns_service
# -----------------------------------------------------------------------------
source_tns_service() {
  local service="${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}"
  [[ -n "$service" ]] ||
    die "Source service is required. Supply it with -g."
  printf '%s\n' "$service"
}

# -----------------------------------------------------------------------------
# update_source_tnsnames
# -----------------------------------------------------------------------------
update_source_tnsnames() {
  local alias_name="${1:-$(generate_source_tns_alias)}"
  local service=""
  local host=""
  local tns_file=""
  local backup_file=""
  local begin_marker=""
  local end_marker=""
  local temp_file=""

  require_source_db
  require_source_scan
  validate_source_port
  initialize_oracle_environment

  service="$(source_tns_service)"
  host="${SOURCE_DB_SCAN%%,*}"
  tns_file="$TNS_ADMIN/tnsnames.ora"
  begin_marker="# BEGIN LTMdbMigration360 ${alias_name}"
  end_marker="# END LTMdbMigration360 ${alias_name}"
  temp_file="/tmp/ltm_tnsnames_${$}.ora"

  if "$SUDO_BIN" -u oracle test -f "$tns_file"; then
    backup_file="${tns_file}.backup_$(date +%Y%m%d_%H%M%S)"
    "$SUDO_BIN" -u oracle cp -p "$tns_file" "$backup_file"
    info "TNS backup created: $backup_file"

    "$SUDO_BIN" -u oracle awk \
      -v begin="$begin_marker" \
      -v end="$end_marker" '
        $0 == begin {skip=1; next}
        $0 == end   {skip=0; next}
        !skip       {print}
      ' "$tns_file" > "$temp_file"
  else
    : > "$temp_file"
  fi

  cat >> "$temp_file" <<EOF

${begin_marker}
${alias_name} =
  (DESCRIPTION =
    (ADDRESS =
      (PROTOCOL = TCP)
      (HOST = ${host})
      (PORT = ${SOURCE_DB_PORT})
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = ${service})
    )
  )
${end_marker}
EOF

  "$SUDO_BIN" install -o oracle -g oinstall -m 640 \
    "$temp_file" "$tns_file"
  rm -f "$temp_file"

  SOURCE_TNS_ALIAS="$alias_name"

  ok "Source TNS alias updated: $SOURCE_TNS_ALIAS"
  info "Source TNS file : $tns_file"
  info "Source service  : $service"
}


# -----------------------------------------------------------------------------
# write_managed_tns_alias
# -----------------------------------------------------------------------------
write_managed_tns_alias() {
  local alias_name="$1"
  local service="$2"
  local host="${SOURCE_DB_SCAN%%,*}"
  local tns_file="$TNS_ADMIN/tnsnames.ora"
  local begin_marker="# BEGIN LTMdbMigration360 ${alias_name}"
  local end_marker="# END LTMdbMigration360 ${alias_name}"
  local temp_file="/tmp/ltm_tnsnames_${alias_name}_${$}.ora"

  if "$SUDO_BIN" -u oracle test -f "$tns_file"; then
    "$SUDO_BIN" -u oracle awk \
      -v begin="$begin_marker" \
      -v end="$end_marker" '
        $0 == begin {skip=1; next}
        $0 == end   {skip=0; next}
        !skip       {print}
      ' "$tns_file" > "$temp_file"
  else
    : > "$temp_file"
  fi

  cat >> "$temp_file" <<EOF

${begin_marker}
${alias_name} =
  (DESCRIPTION =
    (ADDRESS =
      (PROTOCOL = TCP)
      (HOST = ${host})
      (PORT = ${SOURCE_DB_PORT})
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = ${service})
    )
  )
${end_marker}
EOF

  "$SUDO_BIN" install -o oracle -g oinstall -m 640 \
    "$temp_file" "$tns_file"
  rm -f "$temp_file"

  ok "Managed TNS alias updated: $alias_name"
  info "Alias service: $service"
}

# -----------------------------------------------------------------------------
# discover_source_db_domain
# -----------------------------------------------------------------------------
discover_source_db_domain() {
  local alias_name="$1"
  local output=""
  local marker=""
  local rc=0

  info "Discovering source DB_DOMAIN through alias: $alias_name"

  set +e
  output="$(
    run_source_alias_sql "$alias_name" "
set heading off feedback off pages 0 verify off echo off termout on
select 'LTM_DB_DOMAIN=' || nvl(
         trim(value),
         '<EMPTY>'
       )
from v\$parameter
where name='db_domain';
"
  )"
  rc=$?
  set -e

  if (( rc != 0 )); then
    printf '%s\n' "$output" >&2
    die "Unable to query source DB_DOMAIN through alias $alias_name."
  fi

  marker="$(
    printf '%s\n' "$output" |
      sed -n 's/^[[:space:]]*LTM_DB_DOMAIN=//p' |
      tail -1 |
      tr -d '\r'
  )"

  if [[ -z "$marker" ]]; then
    printf '%s\n' "$output" >&2
    die "DB_DOMAIN query completed, but no LTM_DB_DOMAIN marker was returned through alias $alias_name."
  fi

  if [[ "$marker" == "<EMPTY>" ]]; then
    SOURCE_DB_DOMAIN=""
    info "Source DB_DOMAIN: <empty>"
  else
    SOURCE_DB_DOMAIN="$marker"
    info "Source DB_DOMAIN: $SOURCE_DB_DOMAIN"
  fi

  return 0
}

# -----------------------------------------------------------------------------
# derive_dbaascli_source_service
# -----------------------------------------------------------------------------
derive_dbaascli_source_service() {
  local db_unique="$SOURCE_DB_UNIQUE_NAME"
  local domain="${SOURCE_DB_DOMAIN:-}"

  [[ -n "$db_unique" ]] ||
    die "Source DB_UNIQUE_NAME is empty; cannot derive DBaaSCLI service."

  if [[ -n "$domain" ]]; then
    SOURCE_DBAASCLI_SERVICE="${db_unique}.${domain}"
  else
    SOURCE_DBAASCLI_SERVICE="$db_unique"
  fi

  SOURCE_DBAASCLI_TNS_ALIAS="$(generate_source_tns_alias)_DBAASCLI"

  info "Requested source service : $(source_tns_service)"
  info "Source DB_UNIQUE_NAME    : $db_unique"
  info "Source DB_DOMAIN         : ${domain:-<empty>}"
  info "DBaaSCLI effective service: $SOURCE_DBAASCLI_SERVICE"
}

# -----------------------------------------------------------------------------
# validate_dbaascli_effective_service
# -----------------------------------------------------------------------------
validate_dbaascli_effective_service() {
  local source_pdb="$1"

  derive_dbaascli_source_service

  if [[ "$SOURCE_DBAASCLI_SERVICE" == "$(source_tns_service)" ]]; then
    info "DBaaSCLI effective service matches requested source service."
    return 0
  fi

  warn "DBaaSCLI will not use the requested -g service."
  warn "Requested service : $(source_tns_service)"
  warn "DBaaSCLI service   : $SOURCE_DBAASCLI_SERVICE"

  write_managed_tns_alias \
    "$SOURCE_DBAASCLI_TNS_ALIAS" \
    "$SOURCE_DBAASCLI_SERVICE"

  validate_source_tnsping "$SOURCE_DBAASCLI_TNS_ALIAS"

  if ! validate_source_database_for_clone \
      "$SOURCE_DBAASCLI_TNS_ALIAS" \
      "$source_pdb"; then
    die "DBaaSCLI effective source service is not usable: ${SOURCE_DBAASCLI_SERVICE}. Register this service with the source listener before retrying."
  fi

  ok "DBaaSCLI effective source service validation completed."
}


# -----------------------------------------------------------------------------
# validate_source_tnsping
# -----------------------------------------------------------------------------
validate_source_tnsping() {
  local alias_name="$1"

  info "Running tnsping for source alias: $alias_name"

  "$SUDO_BIN" -u oracle env \
    ORACLE_HOME="$ORACLE_HOME_RESOLVED" \
    PATH="$ORACLE_HOME_RESOLVED/bin:/usr/bin:/bin" \
    TNS_ADMIN="$TNS_ADMIN" \
    "$ORACLE_HOME_RESOLVED/bin/tnsping" "$alias_name" 3 ||
      die "TNSPING failed for source alias $alias_name."

  ok "TNSPING succeeded: $alias_name"
}

# -----------------------------------------------------------------------------
# run_source_alias_sql
# -----------------------------------------------------------------------------
run_source_alias_sql() {
  local alias_name="$1"
  local sql_text="$2"
  local sqlplus_bin="$ORACLE_HOME_RESOLVED/bin/sqlplus"

  [[ -n "${SOURCE_SYS_PASSWORD:-}" ]] ||
    die "Source SYS password is required for connectivity validation."

  if [[ "$TEST_MODE" == "true" ]]; then
    printf 'DRY RUN: SQL*Plus SYS/<redacted>@%s AS SYSDBA\n' "$alias_name"
    printf '%s\n' "$sql_text"
    return 0
  fi

  {
    printf 'whenever oserror exit 90\n'
    printf 'whenever sqlerror exit sql.sqlcode\n'
    printf 'set echo off feedback on heading on pages 1000 lines 300 trimspool on serveroutput on\n'
    printf 'connect sys/"%s"@%s as sysdba\n' \
      "$SOURCE_SYS_PASSWORD" "$alias_name"
    printf '%s\n' "$sql_text"
    printf 'exit\n'
  } |
    "$SUDO_BIN" -u oracle env \
      ORACLE_HOME="$ORACLE_HOME_RESOLVED" \
      PATH="$ORACLE_HOME_RESOLVED/bin:/usr/bin:/bin" \
      TNS_ADMIN="$TNS_ADMIN" \
      "$sqlplus_bin" -s /nolog
}

# -----------------------------------------------------------------------------
# validate_source_database_for_clone
# -----------------------------------------------------------------------------
validate_source_database_for_clone() {
  local alias_name="$1"
  local source_pdb="$2"
  local service=""
  local sql=""

  service="$(source_tns_service)"
  source_pdb="$(normalize_name "$source_pdb")"
  validate_oracle_name "$source_pdb" "source PDB name"

  printf '\nSource Oracle Service Precheck\n'
  printf '%s\n' '------------------------------'
  printf '  TNS Alias      : %s\n' "$alias_name"
  printf '  Source Host    : %s\n' "${SOURCE_DB_SCAN%%,*}"
  printf '  Source Port    : %s\n' "$SOURCE_DB_PORT"
  printf '  Source Service : %s\n' "$service"
  printf '  Source PDB     : %s\n' "$source_pdb"

  sql="declare
  l_pdb_count number;
  l_open_mode varchar2(30);
  l_source_con_id number;
  l_encrypted_ts number;
  l_wallet_rows number;
  l_wallet_configured number;
  l_wallet_open number;
  l_wallet_open_no_key number;
begin
  select count(*)
    into l_pdb_count
    from v\$pdbs
   where upper(name)=upper('${source_pdb}');

  if l_pdb_count = 0 then
    raise_application_error(-20001, 'Source PDB ${source_pdb} does not exist');
  end if;

  select con_id,
         open_mode
    into l_source_con_id,
         l_open_mode
    from v\$pdbs
   where upper(name)=upper('${source_pdb}');

  dbms_output.put_line('Source PDB open mode: ' || l_open_mode);

  select count(*)
    into l_encrypted_ts
    from cdb_tablespaces
   where con_id = l_source_con_id
     and encrypted = 'YES';

  dbms_output.put_line(
    'Source PDB encrypted tablespaces: ' || l_encrypted_ts
  );

  select count(*),
         sum(
           case
             when nvl(status,'NOT_AVAILABLE') <> 'NOT_AVAILABLE'
               or nvl(wallet_type,'UNKNOWN') <> 'UNKNOWN'
               or trim(wrl_parameter) is not null
             then 1
             else 0
           end
         ),
         sum(
           case
             when status = 'OPEN'
             then 1
             else 0
           end
         ),
         sum(
           case
             when status = 'OPEN_NO_MASTER_KEY'
             then 1
             else 0
           end
         )
    into l_wallet_rows,
         l_wallet_configured,
         l_wallet_open,
         l_wallet_open_no_key
    from v\$encryption_wallet
   where con_id in (0,1);

  dbms_output.put_line(
    'Wallet rows/configured/open/open_no_key: ' ||
    l_wallet_rows || '/' ||
    nvl(l_wallet_configured,0) || '/' ||
    nvl(l_wallet_open,0) || '/' ||
    nvl(l_wallet_open_no_key,0)
  );

  if l_encrypted_ts = 0 then
    dbms_output.put_line(
      'Source PDB has no encrypted tablespaces; wallet validation skipped'
    );
  elsif nvl(l_wallet_configured,0) = 0 then
    raise_application_error(
      -20002,
      'Source PDB contains encrypted tablespaces but no TDE wallet is configured'
    );
  elsif nvl(l_wallet_open_no_key,0) > 0 then
    raise_application_error(
      -20003,
      'Source TDE wallet is OPEN_NO_MASTER_KEY'
    );
  elsif nvl(l_wallet_open,0) = 0 then
    raise_application_error(
      -20004,
      'Source PDB contains encrypted tablespaces and the TDE wallet is not OPEN'
    );
  else
    dbms_output.put_line('Source TDE wallet validation: PASS');
  end if;
end;
/

select name,
       db_unique_name,
       cdb
from v\$database;

select name,
       open_mode
from v\$pdbs
where upper(name)=upper('${source_pdb}');

select status,
       wallet_type,
       keystore_mode,
       wrl_type,
       wrl_parameter,
       con_id
from v\$encryption_wallet
where con_id in (0,1)
order by con_id;"

  run_source_alias_sql "$alias_name" "$sql" ||
    die "Source SQL*Plus validation failed for alias $alias_name."

  ok "Source SQL*Plus validation completed successfully."
}


# -----------------------------------------------------------------------------
# query_source_pdb_block_sizes
# -----------------------------------------------------------------------------
query_source_pdb_block_sizes() {
  local alias_name="$1"
  local source_pdb="$2"
  local output=""
  local source_pdb_upper=""

  source_pdb_upper="$(normalize_name "$source_pdb")"

  output="$(
    run_source_alias_sql "$alias_name" "
set heading off feedback off pages 0 verify off echo off serveroutput on
declare
  l_con_id number;
  l_total_size number;
begin
  select con_id,
         total_size
    into l_con_id,
         l_total_size
    from v\$pdbs
   where upper(name)=upper('${source_pdb_upper}');

  dbms_output.put_line(
    'LTM_SOURCE_PDB_SIZE_GB=' ||
    to_char(round(l_total_size/1024/1024/1024,2))
  );

  for r in (
    select block_size,
           count(*) tablespace_count
      from cdb_tablespaces
     where con_id=l_con_id
     group by block_size
     order by block_size
  ) loop
    dbms_output.put_line(
      'LTM_SOURCE_BLOCK_SIZE=' ||
      r.block_size ||
      ',COUNT=' ||
      r.tablespace_count
    );
  end loop;
end;
/
"
  )" || die "Unable to query source PDB block sizes through alias $alias_name."

  printf '%s\n' "$output"

  SOURCE_PDB_HAS_16K="false"
  if printf '%s\n' "$output" | grep -q '^LTM_SOURCE_BLOCK_SIZE=16384,'; then
    SOURCE_PDB_HAS_16K="true"
  fi

  if [[ "$SOURCE_PDB_HAS_16K" == "true" ]]; then
    warn "Source PDB $source_pdb contains 16K tablespaces."
  else
    info "Source PDB $source_pdb does not contain 16K tablespaces."
  fi
}

# -----------------------------------------------------------------------------
# ensure_target_16k_cache
# -----------------------------------------------------------------------------
ensure_target_16k_cache() {
  local sql=""

  [[ "${SOURCE_PDB_HAS_16K:-false}" == "true" ]] || return 0

  initialize_oracle_environment

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on serveroutput on
alter session set container=CDB\$ROOT;

declare
  l_value number;
begin
  select to_number(value)
    into l_value
    from v\$parameter
   where name='db_16k_cache_size';

  dbms_output.put_line(
    'Current db_16k_cache_size bytes: ' || l_value
  );

  if l_value = 0 then
    execute immediate
      'alter system set db_16k_cache_size=512M scope=both sid=''*''';

    dbms_output.put_line(
      'db_16k_cache_size configured to 512M'
    );
  else
    dbms_output.put_line(
      'db_16k_cache_size already configured; no change required'
    );
  end if;
end;
/

show parameter db_16k_cache_size

col inst_id for 999
col name for a30
col value for a30

select inst_id,
       name,
       value
from gv\$parameter
where name in (
  'cpu_count',
  'sga_target',
  'sga_max_size',
  'pga_aggregate_target',
  'pga_aggregate_limit',
  'db_16k_cache_size'
)
order by name, inst_id;

exit"

  info "Source PDB requires 16K cache support on target CDB $CDB_NAME."

  run_local_sql "$sql" ||
    die "Unable to configure or validate target DB_16K_CACHE_SIZE."

  ok "Target DB_16K_CACHE_SIZE validation completed."
}

# -----------------------------------------------------------------------------
# report_source_pdb_details
# -----------------------------------------------------------------------------
report_source_pdb_details() {
  local alias_name="$1"
  local source_pdb="$2"

  run_source_alias_sql "$alias_name" "
set lines 300 pages 1000
col name for a30
col open_mode for a12
col block_size for 999999
col tablespace_count for 999999

select con_id,
       name,
       open_mode,
       to_char(open_time,'YYYY-MM-DD HH24:MI') open_time,
       round(total_size/1024/1024/1024,1) total_size_gb,
       to_char(creation_time,'YYYY-MM-DD HH24:MI') creation_time
from v\$pdbs
where upper(name)=upper('${source_pdb}');

alter session set container=${source_pdb};

select block_size,
       count(*) tablespace_count
from dba_tablespaces
group by block_size
order by block_size;
" || die "Unable to capture source PDB size/block-size details."
}

# -----------------------------------------------------------------------------
# report_target_pdb_details
# -----------------------------------------------------------------------------
report_target_pdb_details() {
  local target_pdb="$1"
  local sql=""

  target_pdb="$(normalize_name "$target_pdb")"
  validate_oracle_name "$target_pdb" "target PDB name"

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
col con_name for a20
col name for a45
col network_name for a70
col open_mode for a12
col block_size for 999999
col tablespace_count for 999999

alter session set container=CDB\$ROOT;

select con_id,
       name,
       open_mode,
       to_char(open_time,'YYYY-MM-DD HH24:MI') open_time,
       round(total_size/1024/1024/1024,1) total_size_gb,
       to_char(creation_time,'YYYY-MM-DD HH24:MI') creation_time
from v\$pdbs
where name='${target_pdb}';

alter session set container=${target_pdb};

select block_size,
       count(*) tablespace_count
from dba_tablespaces
group by block_size
order by block_size;

select sys_context('USERENV','CON_NAME') con_name,
       inst_id,
       name,
       network_name,
       to_char(creation_date,'YYYY-MM-DD HH24:MI') creation_date
from gv\$active_services
order by con_id, inst_id, name;

exit"

  info "Capturing target PDB block-size and service details for $target_pdb..."
  if ! run_local_sql "$sql"; then
    error "Unable to capture target PDB details for $target_pdb."
    return 1
  fi

  ok "Target PDB validation report completed for $target_pdb."
  return 0
}


# -----------------------------------------------------------------------------
# prepare_source_tns_and_validate
# -----------------------------------------------------------------------------
prepare_source_tns_and_validate() {
  local source_pdb="$1"
  local alias_name=""

  initialize_oracle_environment
  alias_name="$(generate_source_tns_alias)"
  update_source_tnsnames "$alias_name"
  validate_source_tnsping "$alias_name"
  validate_source_database_for_clone "$alias_name" "$source_pdb"
  report_source_pdb_details "$alias_name" "$source_pdb"
  query_source_pdb_block_sizes "$alias_name" "$source_pdb"
  ensure_target_16k_cache
  discover_source_db_domain "$alias_name"
  validate_dbaascli_effective_service "$source_pdb"

  SOURCE_TNS_ALIAS="$alias_name"
  ok "Source TNS and database validation completed."
}

# -----------------------------------------------------------------------------
# resolve_existing_pdb_sql
# -----------------------------------------------------------------------------
resolve_existing_pdb_sql() {
  local requested_pdb="$1"
  local sql
  local output
  local exact_pdb

  sql="whenever sqlerror exit sql.sqlcode
set heading off feedback off pages 0 verify off echo off
alter session set container=CDB\$ROOT;
select name
from v\$pdbs
where upper(name)=upper('${requested_pdb}');
exit"

  output="$(run_local_sql "$sql" 2>/dev/null || true)"

  exact_pdb="$(
    printf '%s\n' "$output" |
      awk '
        NF == 1 &&
        $1 !~ /^(Session|Elapsed:|Connected|Disconnected)$/ {
          print $1
          exit
        }
      '
  )"

  [[ -n "$exact_pdb" ]] || return 1
  printf '%s\n' "$exact_pdb"
}

# -----------------------------------------------------------------------------
# wait_for_pdb_state
# -----------------------------------------------------------------------------
wait_for_pdb_state() {
  local pdb_name="$1"
  local expected="$2"   # present|absent
  local timeout_seconds="${3:-900}"
  local interval_seconds="${4:-15}"
  local elapsed=0
  local inventory

  while (( elapsed < timeout_seconds )); do
    inventory="$(get_pdb_inventory 2>/dev/null || true)"

    if [[ "$expected" == "present" ]] && pdb_exists "$pdb_name" "$inventory"; then
      return 0
    fi

    if [[ "$expected" == "absent" ]] && ! pdb_exists "$pdb_name" "$inventory"; then
      return 0
    fi

    sleep "$interval_seconds"
    elapsed=$((elapsed + interval_seconds))
    info "Waiting for PDB registry update: $pdb_name ($elapsed/${timeout_seconds}s)"
  done

  return 1
}

# -----------------------------------------------------------------------------
# escape_sql_double_quoted_value
# -----------------------------------------------------------------------------


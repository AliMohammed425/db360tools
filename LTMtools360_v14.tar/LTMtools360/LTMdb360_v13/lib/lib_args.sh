#!/usr/bin/env bash
# LTMdbMigration360 module: lib_args.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# parse_long_options
# -----------------------------------------------------------------------------
parse_long_options() {
  local -a rewritten=()

  while (($#)); do
    case "$1" in
      --rac)
        CREATE_RAC_MODE="RAC"
        shift
        ;;
      --single-instance)
        CREATE_RAC_MODE="SINGLE"
        shift
        ;;
      --nodes)
        [[ $# -ge 2 ]] || die "--nodes requires a comma-separated node list."
        CREATE_NODE_LIST="$2"
        shift 2
        ;;
      --nodes=*)
        CREATE_NODE_LIST="${1#*=}"
        shift
        ;;
      --engine)
        [[ $# -ge 2 ]] || die "--engine requires auto, dbaascli, or dbca."
        CREATE_ENGINE_REQUEST="$(printf '%s' "$2" | tr '[:lower:]' '[:upper:]')"
        shift 2
        ;;
      --engine=*)
        CREATE_ENGINE_REQUEST="$(printf '%s' "${1#*=}" | tr '[:lower:]' '[:upper:]')"
        shift
        ;;
      --use-dbaascli)
        CREATE_ENGINE_REQUEST="DBAASCLI"
        shift
        ;;
      --use-dbca)
        CREATE_ENGINE_REQUEST="DBCA"
        shift
        ;;
      --dbCharset)
        [[ $# -ge 2 ]] || die "--dbCharset requires a value."
        CREATE_CHARSET="$2"
        shift 2
        ;;
      --dbCharset=*)
        CREATE_CHARSET="${1#*=}"
        shift
        ;;
      --dbNCharset)
        [[ $# -ge 2 ]] || die "--dbNCharset requires a value."
        CREATE_NCHARSET="$2"
        shift 2
        ;;
      --dbNCharset=*)
        CREATE_NCHARSET="${1#*=}"
        shift
        ;;
      --create-pdb)
        set_action "create"
        shift
        ;;
      --list-cdbs)
        set_action "list_cdbs"
        shift
        ;;
      --snapshot-test-enable)
        set_action "snapshot_test_enable"
        shift
        ;;
      --snapshot-test-disable)
        set_action "snapshot_test_disable"
        shift
        ;;
      --clone-user)
        [[ $# -ge 2 ]] || die "--clone-user requires a user name."
        SOURCE_DB_USER="$2"
        shift 2
        ;;
      --clone-user=*)
        SOURCE_DB_USER="${1#*=}"
        shift
        ;;
      --oracle-home)
        [[ $# -ge 2 ]] || die "--oracle-home requires a path."
        TARGET_ORACLE_HOME="$2"
        shift 2
        ;;
      --oracle-home=*)
        TARGET_ORACLE_HOME="${1#*=}"
        shift
        ;;
      --encryption-algorithm)
        [[ $# -ge 2 ]] || die "--encryption-algorithm requires AES128, AES192, or AES256."
        ENCRYPTION_ALGORITHM="$2"
        shift 2
        ;;
      --encryption-algorithm=*)
        ENCRYPTION_ALGORITHM="${1#*=}"
        shift
        ;;
      --snapshot-mode)
        [[ $# -ge 2 ]] || die "--snapshot-mode requires auto, snapshot, or full."
        SNAPSHOT_TEST_MODE="$(printf '%s' "$2" | tr '[:lower:]' '[:upper:]')"
        shift 2
        ;;
      --snapshot-mode=*)
        SNAPSHOT_TEST_MODE="$(printf '%s' "${1#*=}" | tr '[:lower:]' '[:upper:]')"
        shift
        ;;
      --snapshot-dest)
        [[ $# -ge 2 ]] || die "--snapshot-dest requires an ASM disk group."
        SNAPSHOT_CREATE_FILE_DEST="${2%/}"
        shift 2
        ;;
      --snapshot-dest=*)
        SNAPSHOT_CREATE_FILE_DEST="${1#*=}"
        SNAPSHOT_CREATE_FILE_DEST="${SNAPSHOT_CREATE_FILE_DEST%/}"
        shift
        ;;
      --datapatch)
        set_action "datapatch"
        shift
        ;;
      --pdb-datapatch)
        set_action "pdb_datapatch"
        shift
        ;;
      --compile-utlrp)
        set_action "compile_utlrp"
        shift
        ;;
      --datapatch-passes)
        [[ $# -ge 2 ]] || die "--datapatch-passes requires a positive integer."
        DATAPATCH_PASSES="$2"
        shift 2
        ;;
      --datapatch-passes=*)
        DATAPATCH_PASSES="${1#*=}"
        shift
        ;;
      --no-datapatch-bounce)
        DATAPATCH_BOUNCE_PDB="false"
        shift
        ;;
      --no-datapatch-violations)
        DATAPATCH_REVIEW_VIOLATIONS="false"
        shift
        ;;
      --no-datapatch-verify)
        DATAPATCH_VERIFY_PATCHES="false"
        DATAPATCH_VERIFY_BLOCKSIZE="false"
        shift
        ;;
      --skip-utlrp)
        DATAPATCH_COMPILE_UTLRP="false"
        shift
        ;;
      --no-invalid-validation)
        DATAPATCH_VALIDATE_INVALIDS="false"
        shift
        ;;
      --final-datapatch-passes)
        [[ $# -ge 2 ]] || die "--final-datapatch-passes requires a positive integer."
        FINAL_CUTOVER_DATAPATCH_PASSES="$2"
        shift 2
        ;;
      --final-datapatch-passes=*)
        FINAL_CUTOVER_DATAPATCH_PASSES="${1#*=}"
        shift
        ;;
      --skip-final-datapatch)
        FINAL_CUTOVER_DATAPATCH="false"
        shift
        ;;
      --skip-final-utlrp)
        FINAL_CUTOVER_COMPILE_UTLRP="false"
        shift
        ;;
      --skip-final-invalid-validation)
        FINAL_CUTOVER_VALIDATE_INVALIDS="false"
        shift
        ;;
      --fix-pdb-violations)
        set_action "fix_pdb_violations"
        shift
        ;;
      --locate-datapatch)
        set_action "locate_datapatch"
        shift
        ;;
      --resume-workflow)
        set_action "resume_workflow"
        shift
        ;;
      --generate-migration-report)
        set_action "generate_migration_report"
        shift
        ;;
      --parallel-health)
        set_action "parallel_health"
        shift
        ;;
      --create-tablespace) set_action "create_tablespace"; shift ;;
      --tablespace-report) set_action "tablespace_report"; shift ;;
      --tablespace-name) TABLESPACE_NAME="$2"; shift 2 ;;
      --tablespace-name=*) TABLESPACE_NAME="${1#*=}"; shift ;;
      --tablespace-type) TABLESPACE_TYPE="$2"; shift 2 ;;
      --tablespace-type=*) TABLESPACE_TYPE="${1#*=}"; shift ;;
      --tablespace-size-mb) TABLESPACE_SIZE_MB="$2"; shift 2 ;;
      --tablespace-size-mb=*) TABLESPACE_SIZE_MB="${1#*=}"; shift ;;
      --tablespace-next-mb) TABLESPACE_NEXT_MB="$2"; shift 2 ;;
      --tablespace-next-mb=*) TABLESPACE_NEXT_MB="${1#*=}"; shift ;;
      --tablespace-maxsize-mb) TABLESPACE_MAXSIZE_MB="$2"; shift 2 ;;
      --tablespace-maxsize-mb=*) TABLESPACE_MAXSIZE_MB="${1#*=}"; shift ;;
      --tablespace-dest) TABLESPACE_FILE_DEST="$2"; shift 2 ;;
      --tablespace-dest=*) TABLESPACE_FILE_DEST="${1#*=}"; shift ;;
      --bigfile) TABLESPACE_BIGFILE="true"; shift ;;
      --no-autoextend) TABLESPACE_AUTOEXTEND="false"; shift ;;
      --no-tablespace-encryption) TABLESPACE_ENCRYPT="false"; shift ;;
      --tablespace-encryption-algorithm) TABLESPACE_ALGORITHM="$2"; shift 2 ;;
      --tablespace-encryption-algorithm=*) TABLESPACE_ALGORITHM="${1#*=}"; shift ;;
      --tablespace-block-size) TABLESPACE_BLOCK_SIZE_KB="$2"; shift 2 ;;
      --tablespace-block-size=*) TABLESPACE_BLOCK_SIZE_KB="${1#*=}"; shift ;;
      --tablespace-16k-cache-size) TABLESPACE_16K_CACHE_SIZE="$2"; shift 2 ;;
      --tablespace-16k-cache-size=*) TABLESPACE_16K_CACHE_SIZE="${1#*=}"; shift ;;
      --workers)
        [[ $# -ge 2 ]] || die "--workers requires a positive integer."
        PARALLEL_WORKERS="$2"
        shift 2
        ;;
      --workers=*)
        PARALLEL_WORKERS="${1#*=}"
        shift
        ;;
      --run-id)
        [[ $# -ge 2 ]] || die "--run-id requires a value."
        RESUME_RUN_ID="$2"
        REPORT_RUN_ID="$2"
        shift 2
        ;;
      --run-id=*)
        RESUME_RUN_ID="${1#*=}"
        REPORT_RUN_ID="${1#*=}"
        shift
        ;;
      --fix-passes)
        [[ $# -ge 2 ]] || die "--fix-passes requires a positive integer."
        POST_CLONE_FIX_PASSES="$2"
        shift 2
        ;;
      --fix-passes=*)
        POST_CLONE_FIX_PASSES="${1#*=}"
        shift
        ;;
      --skip-fix-encryption)
        POST_CLONE_FIX_ENCRYPT="false"
        shift
        ;;
      --exclude-system-ts)
        POST_CLONE_FIX_INCLUDE_SYSTEM="false"
        ENCRYPT_INCLUDE_SYSTEM="false"
        shift
        ;;
      --include-system-ts)
        POST_CLONE_FIX_INCLUDE_SYSTEM="true"
        ENCRYPT_INCLUDE_SYSTEM="true"
        shift
        ;;
      --skip-fix-utlrp)
        POST_CLONE_FIX_UTLRP="false"
        shift
        ;;
      --skip-fix-bounce)
        POST_CLONE_FIX_BOUNCE="false"
        shift
        ;;
      --skip-fix-validation)
        POST_CLONE_FIX_VALIDATE="false"
        shift
        ;;
      --fix-encryption-algorithm)
        [[ $# -ge 2 ]] || die "--fix-encryption-algorithm requires AES128, AES192, or AES256."
        POST_CLONE_FIX_ALGORITHM="$2"
        shift 2
        ;;
      --fix-encryption-algorithm=*)
        POST_CLONE_FIX_ALGORITHM="${1#*=}"
        shift
        ;;
      --allow-patch-violations)
        POST_CLONE_FIX_REQUIRE_CLEAN_PATCH="false"
        shift
        ;;
      --allow-unencrypted-ts)
        POST_CLONE_FIX_REQUIRE_ENCRYPTED="false"
        shift
        ;;
      --fail-on-invalids)
        POST_CLONE_FIX_FAIL_ON_INVALIDS="true"
        shift
        ;;
      *)
        rewritten+=("$1")
        shift
        ;;
    esac
  done

  PARSED_ARGUMENTS=("${rewritten[@]}")
}

# -----------------------------------------------------------------------------
# parse_arguments
# -----------------------------------------------------------------------------
parse_arguments() {
  local opt

  parse_long_options "$@"
  set -- "${PARSED_ARGUMENTS[@]}"

  while getopts ":YzeLlidoxRk:r:fMSqEXCQ:V:W:Z:c:p:m:u:s:a:P:t:T:w:Nb:I:g:O:J:K:U:F:AGBDyjvHh" opt; do
    case "$opt" in
      Y) set_action "create_cdb" ;;
      z) set_action "create" ;;
      e) set_action "encrypt_tablespaces" ;;
      n) TEST_MODE="true" ;;
      k)
        set_action "local_clone"
        CLONE_PDB_TO="$OPTARG"
        ;;
      R) set_action "remote_clone" ;;
      f) set_action "refreshable_create" ;;
      M) set_action "refreshable_refresh" ;;
      S) set_action "refreshable_switchover" ;;
      q) set_action "refreshable_status" ;;
      E) set_action "encryption_status" ;;
      X) set_action "snapshot_test_disable" ;;
      C) set_action "refreshable_convert_rw" ;;
      L) set_action "list_cdbs" ;;
      l) set_action "list_pdbs" ;;
      i) set_action "info" ;;
      d) set_action "drop" ;;
      o) set_action "open" ;;
      x) set_action "close" ;;
      r)
        set_action "rename"
        RENAME_PDB_TO="$OPTARG"
        ;;
      Q) CREATE_DB_UNIQUE_NAME="$OPTARG" ;;
      V) CREATE_DB_SID="$OPTARG" ;;
      W) CREATE_DATA_DEST="$OPTARG" ;;
      Z) CREATE_FRA_DEST="$OPTARG" ;;
      c) CDB_NAME="$OPTARG" ;;
      p) PDB_LIST="$OPTARG" ;;
      m) MAX_SIZE="$OPTARG" ;;
      u) MAX_CPU="$OPTARG" ;;
      s) SOURCE_DB_UNIQUE_NAME="$OPTARG" ;;
      a) SOURCE_DB_SCAN="$OPTARG" ;;
      P) SOURCE_DB_PORT="$OPTARG"; SOURCE_DB_PORT_SUPPLIED="true" ;;
      t) TARGET_PDB_NAME="$OPTARG" ;;
      T) TARGET_PDB_NAME="$OPTARG" ;;
      w) SOURCE_SYS_PASSWORD="$OPTARG" ;;
      N) SOURCE_PLATFORM="NON_EXADATA" ;;
      b) REFRESH_DBLINK="$OPTARG" ;;
      I) REFRESH_INTERVAL="$OPTARG" ;;
      g) SOURCE_DB_SERVICE="$OPTARG" ;;
      O) TARGET_ORACLE_SID="$OPTARG" ;;
      J) TARGET_ORACLE_HOME="$OPTARG" ;;
      K) TARGET_KEYSTORE_PASSWORD="$OPTARG" ;;
      U) SOURCE_DB_USER="$OPTARG" ;;
      F) CLONE_USER_PROFILE="$OPTARG" ;;
      A) AUTO_CREATE_CLONE_USER="false" ;;
      G) GRANT_DBA_TO_CLONE_USER="false" ;;
      B) DROP_AUTO_DBLINK="true" ;;
      D) TEST_MODE="true" ;;
      y) ASSUME_YES="true" ;;
      j) JSON_OUTPUT="true" ;;
      v)
        printf '%s version %s\n' "$SCRIPT_NAME" "$SCRIPT_VERSION"
        exit 0
        ;;
      H)
        show_detailed_help
        exit 0
        ;;
      h)
        usage
        exit 0
        ;;
      :)
        die "Option -$OPTARG requires a value."
        ;;
      \?)
        die "Unknown option: -$OPTARG. Use -h for help."
        ;;
    esac
  done

  shift $((OPTIND - 1))
  [[ $# -eq 0 ]] || die "Unexpected argument(s): $*"

  [[ -n "$ACTION" ]] || {
    usage
    die "An action is required. Use -h for supported actions."
  }
}

# -----------------------------------------------------------------------------
# set_action
# -----------------------------------------------------------------------------
set_action() {
  local requested="$1"

  if [[ -n "$ACTION" && "$ACTION" != "$requested" ]]; then
    die "Specify only one action at a time."
  fi

  ACTION="$requested"
}


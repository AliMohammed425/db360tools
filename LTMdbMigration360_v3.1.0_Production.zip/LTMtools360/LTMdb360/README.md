# LTMdbMigration360 Enterprise v3.1.0

Oracle Database migration and lifecycle automation for Oracle Database@Azure,
OCI, Exadata, RAC, and single-instance environments.

## Installation

```bash
unzip LTMdbMigration360_v3.1.0_Production.zip
cd LTMtools360/LTMdb360

sudo ./install.sh   /home/opc/LTMtools360/LTMdb360   opc   oinstall
```

## Primary command

```bash
/home/opc/LTMtools360/LTMdb360/bin/ltm_db_migration.sh
```

Run without arguments for interactive mode:

```bash
./bin/ltm_db_migration.sh
```

## Included production scripts

```text
bin/ltm_db_migration.sh
bin/ltm_db_migration_pdb.sh
bin/ltm_db_create_precheck.sh
bin/ltm_db_create.sh
bin/ltm_db_prepare_standby.sh
bin/ltm_db_build_standby.sh
bin/ltm_dg_manager.sh
bin/ltm_db_health.sh
bin/ltm_db_registration.sh
bin/install.sh
bin/uninstall.sh
```

## Subscription-to-Subscription Migration

The existing workflow is preserved:

```text
1)  Validate ltm_migration.ini
2)  Primary database create precheck
3)  Standby database create precheck
4)  Create primary database
5)  Create standby database
6)  Prepare primary for standby - dry run
7)  Prepare primary for standby - live
8)  Build standby/Data Guard - dry run
9)  Build standby/Data Guard - live
10) Data Guard status - primary/all
11) Data Guard status - standby/database
12) Data Guard switchover - dry run
13) Data Guard switchover - live
14) Database health check - all
15) Database health check - one database
16) Move latest DB registration TAR files
17) Guided full migration workflow
0)  Back
```

Configuration:

```text
/home/opc/LTMtools360/LTMdb360/config/ltm_migration.ini
```

## Post-clone remediation

```bash
./bin/ltm_db_migration.sh   --fix-pdb-violations   -c SNY   -p LNYPDB5   -y
```

The workflow includes Datapatch discovery as the Oracle user, Datapatch passes,
UTLRP, permanent tablespace encryption including SYSTEM and SYSAUX, PDB bounce,
SQL patch validation, invalid-object validation, block-size validation, and
plug-in violation reporting.

## Modular architecture

The main executable is intentionally small. Functional implementations are
stored in `lib/` by responsibility. See:

- `docs/MODULE_REFERENCE.md`
- `docs/DEVELOPER_GUIDE.md`
- `bin/validate_modules.sh`


## Enterprise v3.1 features

### Resume a migration

```bash
./bin/ltm_db_migration.sh --resume-workflow
./bin/ltm_db_migration.sh --resume-workflow --run-id RUN_ID
```

### Generate reports

```bash
./bin/ltm_db_migration.sh --generate-migration-report
./bin/ltm_db_migration.sh --generate-migration-report --run-id RUN_ID
```

### Parallel health checks

```bash
./bin/ltm_db_migration.sh --parallel-health --workers 4
```

### Validation

```bash
./tools/validate_modules.sh
./tools/validate_release.sh
./tools/run_unit_tests.sh
```

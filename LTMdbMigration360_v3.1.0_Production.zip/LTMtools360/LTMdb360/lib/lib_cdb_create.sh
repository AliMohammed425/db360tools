#!/usr/bin/env bash
# LTMdbMigration360 module: lib_cdb_create.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# oracle_home_is_valid
# -----------------------------------------------------------------------------
oracle_home_is_valid() {
  local home="$1"

  [[ -n "$home" ]] || return 1

  "$SUDO_BIN" test -d "$home" 2>/dev/null &&
  "$SUDO_BIN" test -x "$home/bin/dbca" 2>/dev/null &&
  "$SUDO_BIN" test -x "$home/bin/oracle" 2>/dev/null
}

# -----------------------------------------------------------------------------
# resolve_creation_oracle_home
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# resolve_creation_oracle_home
# -----------------------------------------------------------------------------
resolve_creation_oracle_home() {
  local candidate=""
  local pid=""
  local exe=""
  local grid_home=""
  local srvctl_bin=""
  local db_name=""
  local home=""

  # 1. Explicit override. Validate as root/oracle, not as opc.
  if oracle_home_is_valid "$TARGET_ORACLE_HOME"; then
    printf '%s\n' "$TARGET_ORACLE_HOME"
    return 0
  fi

  if [[ -n "$TARGET_ORACLE_HOME" ]]; then
    warn "Specified Oracle Home is not accessible or incomplete: $TARGET_ORACLE_HOME"
  fi

  # 2. Derive from running PMON processes.
  while read -r pid candidate; do
    [[ -n "$pid" ]] || continue

    exe="$(
      "$SUDO_BIN" readlink -f "/proc/${pid}/exe" 2>/dev/null || true
    )"

    if [[ "$exe" == */bin/oracle ]]; then
      home="${exe%/bin/oracle}"
      if oracle_home_is_valid "$home"; then
        printf '%s\n' "$home"
        return 0
      fi
    fi
  done < <(
    ps -eo pid=,args= |
      awk '/ora_pmon_/ && $0 !~ /awk/ {print $1, $2}'
  )

  # 3. Read Grid Home and inspect Clusterware database registrations.
  if [[ -r /etc/oracle/olr.loc ]]; then
    grid_home="$(
      awk -F= '/^[[:space:]]*crs_home[[:space:]]*=/ {
        gsub(/[[:space:]]/, "", $2)
        print $2
        exit
      }' /etc/oracle/olr.loc
    )"
  fi

  for srvctl_bin in \
    "${grid_home:+$grid_home/bin/srvctl}" \
    /u01/app/*/grid/bin/srvctl \
    /u01/app/*/*/grid/bin/srvctl \
    /u02/app/*/grid/bin/srvctl
  do
    "$SUDO_BIN" test -x "$srvctl_bin" 2>/dev/null || continue

    while IFS= read -r db_name; do
      [[ -n "$db_name" ]] || continue

      home="$(
        "$SUDO_BIN" -u oracle "$srvctl_bin" config database -d "$db_name" 2>/dev/null |
          awk -F':[[:space:]]*' '
            tolower($1) == "oracle home" {
              print $2
              exit
            }
          '
      )"

      if oracle_home_is_valid "$home"; then
        printf '%s\n' "$home"
        return 0
      fi
    done < <(
      "$SUDO_BIN" -u oracle "$srvctl_bin" config database 2>/dev/null || true
    )
  done

  # 4. Read /etc/oratab.
  if [[ -r /etc/oratab ]]; then
    while IFS=: read -r candidate home _; do
      [[ -n "$candidate" ]] || continue
      [[ "$candidate" == \#* ]] && continue

      if oracle_home_is_valid "$home"; then
        printf '%s\n' "$home"
        return 0
      fi
    done < /etc/oratab
  fi

  # 5. Inspect DBaaSCLI inventory.
  if [[ -x "$DBAASCLI_BIN" ]]; then
    home="$(
      "$SUDO_BIN" "$DBAASCLI_BIN" system getDatabases 2>/dev/null |
        awk -F'[:,]' '
          /"?(oracleHome|dbHome)"?[[:space:]]*:/ {
            value=$2
            gsub(/[",[:space:]]/, "", value)
            if (value != "") {
              print value
              exit
            }
          }
        '
    )"

    if oracle_home_is_valid "$home"; then
      printf '%s\n' "$home"
      return 0
    fi
  fi

  # 6. Controlled filesystem search.
  home="$(
    "$SUDO_BIN" find \
      /u01/app/oracle \
      /u02/app/oracle \
      /opt/oracle \
      -type f \
      -path '*/bin/dbca' \
      -perm /111 \
      -print 2>/dev/null |
      head -1 |
      sed 's#/bin/dbca$##'
  )"

  if oracle_home_is_valid "$home"; then
    printf '%s\n' "$home"
    return 0
  fi

  return 1
}

# -----------------------------------------------------------------------------
# detect_cdb_creation_engine
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# detect_cdb_creation_engine
# -----------------------------------------------------------------------------
detect_cdb_creation_engine() {
  local help_output=""

  case "$CREATE_ENGINE_REQUEST" in
    AUTO)
      if [[ -x "$DBAASCLI_BIN" ]]; then
        help_output="$(
          "$SUDO_BIN" "$DBAASCLI_BIN" database create --help 2>&1 || true
        )"

        if printf '%s\n' "$help_output" | grep -q -- '--dbName'; then
          CREATE_ENGINE="DBAASCLI"
          return 0
        fi

        warn "DBaaSCLI was found, but database create --dbName is not supported."
      fi

      CREATE_ENGINE="DBCA"
      ;;

    DBAASCLI)
      [[ -x "$DBAASCLI_BIN" ]] ||
        die "DBaaSCLI was explicitly requested but $DBAASCLI_BIN was not found."

      help_output="$(
        "$SUDO_BIN" "$DBAASCLI_BIN" database create --help 2>&1 || true
      )"

      printf '%s\n' "$help_output" | grep -q -- '--dbName' ||
        die "DBaaSCLI was explicitly requested, but this release does not support database create --dbName."

      CREATE_ENGINE="DBAASCLI"
      ;;

    DBCA)
      CREATE_ENGINE="DBCA"
      ;;

    *)
      die "Invalid creation engine: $CREATE_ENGINE_REQUEST. Use auto, dbaascli, or dbca."
      ;;
  esac
}

# -----------------------------------------------------------------------------
# run_create_command
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# run_create_command
# -----------------------------------------------------------------------------
run_create_command() {
  if [[ "$TEST_MODE" == "true" ]]; then
    printf 'DRY RUN:'
    printf ' %q' "$@"
    printf '\n'
    return 0
  fi

  "$@"
}

# -----------------------------------------------------------------------------
# run_dbaascli_create_with_passwords
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# run_dbaascli_create_with_passwords
# -----------------------------------------------------------------------------
run_dbaascli_create_with_passwords() {
  local sys_password="$1"
  local tde_password="$2"
  shift 2

  if [[ "$TEST_MODE" == "true" ]]; then
    printf 'DRY RUN:'
    printf ' %q' "$@"
    printf ' <SYS/TDE passwords supplied securely through stdin>\n'
    return 0
  fi

  {
    printf '%s\n' "$sys_password"
    printf '%s\n' "$sys_password"
    printf '%s\n' "$tde_password"
    printf '%s\n' "$tde_password"
  } | "$@"
}

# -----------------------------------------------------------------------------
# detect_cluster_nodes
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# detect_cluster_nodes
# -----------------------------------------------------------------------------
detect_cluster_nodes() {
  local nodes=""
  local grid_home=""

  if [[ -n "$CREATE_NODE_LIST" ]]; then
    printf '%s\n' "$CREATE_NODE_LIST"
    return 0
  fi

  if command -v olsnodes >/dev/null 2>&1; then
    nodes="$(olsnodes 2>/dev/null | awk 'NF {printf "%s%s", sep, $1; sep=","}')"
  fi

  if [[ -z "$nodes" && -r /etc/oracle/olr.loc ]]; then
    grid_home="$(
      awk -F= '/^[[:space:]]*crs_home[[:space:]]*=/ {
        gsub(/[[:space:]]/, "", $2); print $2; exit
      }' /etc/oracle/olr.loc
    )"

    if [[ -x "$grid_home/bin/olsnodes" ]]; then
      nodes="$(
        "$grid_home/bin/olsnodes" 2>/dev/null |
          awk 'NF {printf "%s%s", sep, $1; sep=","}'
      )"
    fi
  fi

  printf '%s\n' "$nodes"
}

# -----------------------------------------------------------------------------
# resolve_rac_mode
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# resolve_rac_mode
# -----------------------------------------------------------------------------
resolve_rac_mode() {
  local node_count=0

  CREATE_NODE_LIST="$(detect_cluster_nodes)"

  if [[ -n "$CREATE_NODE_LIST" ]]; then
    node_count="$(awk -F',' '{print NF}' <<< "$CREATE_NODE_LIST")"
  fi

  case "$CREATE_RAC_MODE" in
    RAC)
      (( node_count >= 2 )) ||
        die "RAC creation requires at least two nodes. Use --nodes node1,node2."
      CREATE_IS_RAC="true"
      ;;
    SINGLE)
      CREATE_IS_RAC="false"
      ;;
    AUTO)
      if (( node_count >= 2 )); then
        CREATE_IS_RAC="true"
      else
        CREATE_IS_RAC="false"
      fi
      ;;
    *)
      die "Invalid RAC mode: $CREATE_RAC_MODE"
      ;;
  esac
}

# -----------------------------------------------------------------------------
# resolve_dbca_template
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# resolve_dbca_template
# -----------------------------------------------------------------------------
resolve_dbca_template() {
  local oracle_home="$1"
  local template=""

  for template in \
    "$oracle_home/assistants/dbca/templates/General_Purpose.dbc" \
    "$oracle_home/assistants/dbca/templates/General_Purpose.dbt" \
    "$oracle_home/assistants/dbca/templates/Data_Warehouse.dbc" \
    "$oracle_home/assistants/dbca/templates/Data_Warehouse.dbt"
  do
    if "$SUDO_BIN" test -r "$template" 2>/dev/null; then
      printf '%s\n' "$template"
      return 0
    fi
  done

  template="$(
    "$SUDO_BIN" find "$oracle_home/assistants/dbca/templates" \
      -maxdepth 1 -type f \
      \( -name '*.dbc' -o -name '*.dbt' \) \
      -print 2>/dev/null |
      head -1
  )"

  [[ -n "$template" ]] || return 1
  printf '%s\n' "$template"
}

# -----------------------------------------------------------------------------
# extract_resume_session_id
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# extract_resume_session_id
# -----------------------------------------------------------------------------
extract_resume_session_id() {
  awk '
    /--sessionID[[:space:]]+[0-9]+[[:space:]]+--resume/ {
      for (i=1; i<=NF; i++) {
        if ($i == "--sessionID" && (i+1) <= NF) {
          print $(i+1)
          exit
        }
      }
    }
  '
}

# -----------------------------------------------------------------------------
# action_create_local_cdb
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# action_create_local_cdb
# -----------------------------------------------------------------------------
action_create_local_cdb() {
  local oracle_home=""
  local storage_type="FS"
  local -a create_cmd
  local dbaas_help=""
  local database_type="SINGLE"
  local dbca_template=""
  local create_output=""
  local resume_session_id=""
  local create_rc=0

  [[ -n "$CDB_NAME" ]] ||
    read -r -p "Enter new CDB name: " CDB_NAME
  [[ -n "$CDB_NAME" ]] || die "CDB name is required."

  CDB_NAME="$(normalize_name "$CDB_NAME")"
  validate_oracle_name "$CDB_NAME" "CDB name"

  CREATE_DB_UNIQUE_NAME="${CREATE_DB_UNIQUE_NAME:-$CDB_NAME}"
  CREATE_DB_SID="${CREATE_DB_SID:-$CDB_NAME}"

  validate_oracle_name "$CREATE_DB_SID" "database SID"

  if [[ -z "$CREATE_DATA_DEST" ]]; then
    read -r -p "Enter data destination [+DATA]: " CREATE_DATA_DEST
    CREATE_DATA_DEST="${CREATE_DATA_DEST:-+DATA}"
  fi

  if [[ -z "$CREATE_FRA_DEST" ]]; then
    read -r -p "Enter recovery destination [+RECO]: " CREATE_FRA_DEST
    CREATE_FRA_DEST="${CREATE_FRA_DEST:-+RECO}"
  fi

  if [[ -z "$SOURCE_SYS_PASSWORD" ]]; then
    read -r -s -p "Enter SYS/SYSTEM password: " SOURCE_SYS_PASSWORD
    printf '\n'
  fi
  [[ -n "$SOURCE_SYS_PASSWORD" ]] ||
    die "SYS/SYSTEM password is required."

  oracle_home="$(resolve_creation_oracle_home)" ||
    die "Unable to validate Oracle Home. Verify -J points to a DB home containing bin/oracle and bin/dbca."
  TARGET_ORACLE_HOME="$oracle_home"

  resolve_rac_mode
  [[ "$CREATE_IS_RAC" == "true" ]] && database_type="RAC"

  detect_cdb_creation_engine

  CREATE_DATA_DEST="${CREATE_DATA_DEST%/}"
  CREATE_FRA_DEST="${CREATE_FRA_DEST%/}"

  if [[ "$CREATE_DATA_DEST" == +* ]]; then
    storage_type="ASM"
  fi

  cat <<PLAN

Local CDB Creation Plan
-----------------------
CDB Name          : $CDB_NAME
DB_UNIQUE_NAME    : $CREATE_DB_UNIQUE_NAME
SID               : $CREATE_DB_SID
Oracle Home       : $oracle_home
Character Set     : $CREATE_CHARSET
National Charset  : $CREATE_NCHARSET
Data Destination  : $CREATE_DATA_DEST
FRA Destination   : $CREATE_FRA_DEST
Storage Type      : $storage_type
Database Type     : $database_type
RAC Node List     : ${CREATE_NODE_LIST:-N/A}
CDB Enabled       : YES
Engine Requested  : $CREATE_ENGINE_REQUEST
Creation Engine   : $CREATE_ENGINE
SYS Password      : $([[ -n "$SOURCE_SYS_PASSWORD" ]] && echo "SUPPLIED VIA -w" || echo "PROMPT")
TDE Password      : $([[ -n "$TARGET_KEYSTORE_PASSWORD" ]] && echo "SUPPLIED VIA -K" || echo "PROMPT IF REQUIRED")
Execution         : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Proceed with local CDB creation?"

  if [[ "$CREATE_ENGINE" == "DBAASCLI" ]]; then
    dbaas_help="$(
      "$SUDO_BIN" "$DBAASCLI_BIN" database create --help 2>&1 || true
    )"

    create_cmd=(
      "$SUDO_BIN" "$DBAASCLI_BIN" database create
      --dbName "$CDB_NAME"
      --oracleHome "$ORACLE_HOME_RESOLVED"
      --dbUniqueName "$CREATE_DB_UNIQUE_NAME"
      --dbSID "$CREATE_DB_SID"
      --createAsCDB true
      --dbCharset "$CREATE_CHARSET"
      --dbNCharset "$CREATE_NCHARSET"
      --datafileDestination "$CREATE_DATA_DEST"
      --fraDestination "$CREATE_FRA_DEST"
      --waitForCompletion true
    )

    if printf '%s\n' "$dbaas_help" | grep -q -- '--tdeConfigMethod'; then
      create_cmd+=(--tdeConfigMethod FILE)
    fi

    if [[ "$CREATE_IS_RAC" == "true" ]]; then
      create_cmd+=(
        --nodeList "$CREATE_NODE_LIST"
        --honorNodeNumberForInstance true
      )
    fi

    info "Creating local CDB with DBaaSCLI..."
    info "SYS password supplied through -w."
    if [[ -n "$TARGET_KEYSTORE_PASSWORD" ]]; then
      info "TDE password supplied through -K."
    fi

    if [[ "$TEST_MODE" == "true" ]]; then
      run_dbaascli_create_with_passwords \
        "$SOURCE_SYS_PASSWORD" \
        "$TARGET_KEYSTORE_PASSWORD" \
        "${create_cmd[@]}"
      return 0
    fi

    set +e
    create_output="$(
      run_dbaascli_create_with_passwords \
        "$SOURCE_SYS_PASSWORD" \
        "$TARGET_KEYSTORE_PASSWORD" \
        "${create_cmd[@]}" 2>&1
    )"
    create_rc=$?
    set -e

    printf '%s\n' "$create_output"

    if (( create_rc == 0 )); then
      ok "DBaaSCLI CDB creation completed."
      return 0
    fi

    resume_session_id="$(
      printf '%s\n' "$create_output" |
        extract_resume_session_id
    )"

    if [[ -n "$resume_session_id" ]]; then
      warn "DBaaSCLI create failed but session $resume_session_id can be resumed."

      if [[ "$ASSUME_YES" != "true" ]]; then
        confirm_action "Resume DBaaSCLI database creation session $resume_session_id?"
      fi

      info "Resuming DBaaSCLI session: $resume_session_id"

      if run_dbaascli_create_with_passwords \
           "$SOURCE_SYS_PASSWORD" \
           "$TARGET_KEYSTORE_PASSWORD" \
           "${create_cmd[@]}" \
           --sessionID "$resume_session_id" \
           --resume; then
        ok "DBaaSCLI CDB creation resumed and completed."
        return 0
      fi

      die "DBaaSCLI resume failed for session $resume_session_id. Review the DBaaSCLI session log."
    fi

    warn "DBaaSCLI CDB creation failed and no resumable session was detected."

    if [[ "$CREATE_ENGINE_REQUEST" == "DBAASCLI" ]]; then
      die "DBaaSCLI was explicitly requested; DBCA fallback is disabled."
    fi

    warn "Attempting DBCA fallback using Oracle Home $oracle_home."
    CREATE_ENGINE="DBCA"
  fi
  oracle_home="$(resolve_creation_oracle_home)" ||
    die "DBCA fallback requires a valid Oracle Home. Supply -J ORACLE_HOME."

  dbca_template="$(resolve_dbca_template "$oracle_home")" ||
    die "No readable DBCA template was found under $oracle_home/assistants/dbca/templates."

  info "DBCA template: $dbca_template"

  create_cmd=(
    "$SUDO_BIN" -u oracle env
    ORACLE_HOME="$oracle_home"
    PATH="$oracle_home/bin:/usr/bin:/bin"
    "$oracle_home/bin/dbca"
    -silent
    -createDatabase
    -templateName "$dbca_template"
    -gdbName "$CDB_NAME"
    -sid "$CREATE_DB_SID"
    -dbUniqueName "$CREATE_DB_UNIQUE_NAME"
    -sysPassword "$SOURCE_SYS_PASSWORD"
    -systemPassword "$SOURCE_SYS_PASSWORD"
    -characterSet "$CREATE_CHARSET"
    -nationalCharacterSet "$CREATE_NCHARSET"
    -createAsContainerDatabase true
    -numberOfPDBs 0
    -storageType "$storage_type"
    -datafileDestination "$CREATE_DATA_DEST"
    -recoveryAreaDestination "$CREATE_FRA_DEST"
    -enableArchive true
    -emConfiguration NONE
  )

  if [[ "$CREATE_IS_RAC" == "true" ]]; then
    create_cmd+=(-databaseConfigType RAC -nodelist "$CREATE_NODE_LIST")
  else
    create_cmd+=(-databaseConfigType SINGLE)
  fi

  info "Creating local CDB with DBCA..."
  run_create_command "${create_cmd[@]}" ||
    die "Local CDB creation failed using DBCA."

  ok "Local CDB creation completed: $CDB_NAME"
  info "DB_UNIQUE_NAME: $CREATE_DB_UNIQUE_NAME"
  info "SID           : $CREATE_DB_SID"
  info "Creation Engine: DBCA"
  info "Engine Requested: $CREATE_ENGINE_REQUEST"
  info "Database Type : $database_type"
  [[ "$CREATE_IS_RAC" == "true" ]] && info "RAC Nodes     : $CREATE_NODE_LIST"
}


#!/usr/bin/env bash
# LTMdbMigration360 module: lib_help.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# usage
# -----------------------------------------------------------------------------
usage() {
  cat <<USAGE
Usage:
  $SCRIPT_NAME                  Interactive menu mode
  $SCRIPT_NAME --menu           Interactive menu mode
  $SCRIPT_NAME ACTION [OPTIONS] Non-interactive CLI mode

Core actions:
  -Y                         Create local CDB
  -z, --create-pdb           Create local PDB
  -L, --list-cdbs           List all CDBs
  -l                         List PDB inventory
  -i                         Display PDB information
  -o                         Open PDB read/write
  -x                         Close PDB
  -d                         Drop PDB
  -r NEW_PDB                 Rename PDB
  -k PDB_NAME                Create or locally clone PDB
  -R                         Remote PDB clone
  -f                         Create refreshable PDB
  -M                         Refresh refreshable PDB now
  -q                         Display refreshable PDB status
  -S                         Refreshable PDB switchover
  -C                         Final cutover to read/write
  -E                         Display encryption status
  -e                         Encrypt all unencrypted permanent PDB tablespaces

Encryption controls:
  --include-system-ts        Include SYSTEM and SYSAUX; default
  --exclude-system-ts        Exclude SYSTEM and SYSAUX

Patch and validation actions:
  --datapatch                Run Datapatch on full CDB or selected PDB
  --pdb-datapatch            Run PDB Datapatch, UTLRP, and validation
  --compile-utlrp             Compile invalid objects in one PDB
  --fix-pdb-violations       Fix post-clone PDB violations end-to-end
  --locate-datapatch         Locate Datapatch for the selected CDB Oracle Home
  --datapatch-passes N       Datapatch passes; default 2
  --no-datapatch-bounce      Skip PDB bounce
  --no-datapatch-violations  Skip plug-in violation review
  --no-datapatch-verify      Skip SQL patch and block-size verification
  --skip-utlrp               Skip UTLRP in --pdb-datapatch
  --no-invalid-validation    Skip invalid-object validation
  --final-datapatch-passes N Final-cutover Datapatch passes; default 2
  --skip-final-datapatch     Skip Datapatch after final cutover
  --skip-final-utlrp         Skip UTLRP after final cutover
  --skip-final-invalid-validation
                             Skip invalid-object validation after cutover

CDB/PDB parameters:
  -c CDB_NAME
  -p PDB_NAME
  -t TARGET_PDB
  -O ORACLE_SID
  -J ORACLE_HOME
  -w SYS_PASSWORD
  -K KEYSTORE_PASSWORD

Post-clone remediation options:
  --fix-pdb-violations       Run Datapatch, UTLRP, encryption, bounce, validation
  --fix-passes N             Datapatch passes; default 2
  --skip-fix-encryption      Skip tablespace encryption
  --exclude-system-ts        Do not encrypt SYSTEM and SYSAUX
  --skip-fix-utlrp           Skip UTLRP
  --skip-fix-bounce          Skip PDB bounce
  --skip-fix-validation      Skip final validation
  --fix-encryption-algorithm AES128|AES192|AES256
  --allow-patch-violations   Do not fail when SQL patch violations remain
  --allow-unencrypted-ts     Do not fail when permanent tablespaces remain unencrypted
  --fail-on-invalids         Fail if invalid objects remain after UTLRP

Enterprise v3.1:
  --resume-workflow          Resume latest or selected checkpoint
  --generate-migration-report Generate HTML/JSON/CSV report
  --parallel-health          Run health checks in parallel
  --workers N                Maximum parallel workers; default 4
  --run-id ID                Select checkpoint/report run ID

General:
  -y                         Auto-confirm
  -n, -D                     Dry run
  -j                         JSON output
  -v                         Display version
  -h                         Short help
  -H                         Detailed help

Examples:
  $SCRIPT_NAME --datapatch -c SNY
  $SCRIPT_NAME --datapatch -c SNY -p OMADAD06
  $SCRIPT_NAME --pdb-datapatch -c SNY -p OMADAD06
  $SCRIPT_NAME --compile-utlrp -c SNY -p OMADAD06
  $SCRIPT_NAME --fix-pdb-violations -c SNY -p LNYPDB5
  $SCRIPT_NAME -C -c SNY -p OMADAD06 --final-datapatch-passes 2
USAGE
}

# -----------------------------------------------------------------------------
# show_detailed_help
# -----------------------------------------------------------------------------
show_detailed_help() {
  cat <<EOF
================================================================================
LTMdbMigration360 Enterprise Database Migration and Lifecycle Utility
Version: ${SCRIPT_VERSION} — Single Production Script
================================================================================

USAGE
  ${SCRIPT_NAME} [OPTIONS]

GENERAL OPTIONS
  -h                  Short help
  -H                  Detailed help with examples for every function
  -v                  Display version
  -y                  Auto-confirm prompts
  -n                  Dry-run
  -D                  Backward-compatible dry-run alias
  -O ORACLE_SID       Target Oracle SID override
  -J ORACLE_HOME      Target Oracle Home override
  -j                  JSON output where supported

--------------------------------------------------------------------------------
1. CREATE A LOCAL CDB
--------------------------------------------------------------------------------

The script checks for DBaaSCLI first. If its database-create interface supports
the required parameters, DBaaSCLI is used. Otherwise, the script falls back to
DBCA automatically.

Create using ASM destinations:

  ${SCRIPT_NAME} -Y \
    -c BNYCDB \
    -Q BNYCDB_NONRAC \
    -V BNYCDB \
    -W +DATA \
    -Z +RECO \
    -J /u02/app/oracle/product/19.0.0.0/dbhome_1 \
    -w 'SYS_PASSWORD'

Creation engine selection:

  Automatic selection (default):

  ${SCRIPT_NAME} --engine auto -Y ...

  Force DBaaSCLI:

  ${SCRIPT_NAME} --use-dbaascli -Y ...

  Force DBCA:

  ${SCRIPT_NAME} --use-dbca -Y ...

Create a RAC CDB using auto-detected cluster nodes:

  ${SCRIPT_NAME} --rac     -Y -c BNYCDB -Q BNYCDB_OCI -V BNYCDB     -W +DATAC2 -Z +RECOC2 -w 'SYS_PASSWORD'

Force a RAC node list:

  ${SCRIPT_NAME} --rac     --nodes clust02-8rwpj1,clust02-8rwpj2     -Y -c BNYCDB -Q BNYCDB_OCI -V BNYCDB     -W +DATAC2 -Z +RECOC2 -w 'SYS_PASSWORD'

Create using filesystem destinations:

  ${SCRIPT_NAME} -Y \
    -c BNYCDB \
    -Q BNYCDB_NONRAC \
    -V BNYCDB \
    -W /u02/oradata \
    -Z /u03/fra \
    -J /u02/app/oracle/product/19.0.0.0/dbhome_1 \
    -w 'SYS_PASSWORD'

Character set overrides:

  Short options:

  ${SCRIPT_NAME} -Y     -c BNYCDB     -Q BNYCDB_OCI     -V BNYCDB     -C WE8MSWIN1252     -N AL16UTF16     -W +DATAC2     -Z +RECOC2     -w 'SYS_PASSWORD'

  DBaaSCLI-style long options:

  ${SCRIPT_NAME} -Y     -c BNYCDB     -Q BNYCDB_OCI     -V BNYCDB     --dbCharset WE8MSWIN1252     --dbNCharset AL16UTF16     -W +DATAC2     -Z +RECOC2     -w 'SYS_PASSWORD'

Defaults:
  DB_UNIQUE_NAME     = CDB name
  SID                = CDB name
  Character Set      = AL32UTF8
  National Character = AL16UTF16
  CDB                = ENABLED
  PDB count          = 0 (PDB\$SEED only)

Dry run:

  ${SCRIPT_NAME} -Y \
    -c BNYCDB \
    -Q BNYCDB_NONRAC \
    -W +DATA \
    -Z +RECO \
    -J /u02/app/oracle/product/19.0.0.0/dbhome_1 \
    -w 'SYS_PASSWORD' \
    -n

--------------------------------------------------------------------------------
2. LIST ALL CDBs WITH -L
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -L

--------------------------------------------------------------------------------
3. LIST PDBs WITH MODE, REFRESH STATUS, AND ENCRYPTION
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -l -c sny

  Mode: R/W=READ WRITE, R/O=READ ONLY, M=MOUNTED
  Encryption: ENABLED or DISABLED per PDB

--------------------------------------------------------------------------------
4. DISPLAY ONE PDB'S INFORMATION
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -i -c sny -p BNYPDB3

--------------------------------------------------------------------------------
5. CREATE A PDB
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -z -c sny -p TESTPDB1

  Create with AES256 tablespace encryption:
  ${SCRIPT_NAME} -z -c sny -p TESTPDB1 -e

--------------------------------------------------------------------------------
5. DROP A PDB
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -d -c sny -p TESTPDB1

  Auto-confirm:
  ${SCRIPT_NAME} -d -c sny -p TESTPDB1 -y

  Dry run:
  ${SCRIPT_NAME} -d -c sny -p TESTPDB1 -n

--------------------------------------------------------------------------------
6. RENAME A PDB
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -r BNYPDB9 -c bny -p BNYPDB4

--------------------------------------------------------------------------------
7. OPEN A PDB
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -o -c sny -p TESTPDB1

--------------------------------------------------------------------------------
8. CLOSE A PDB
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -x -c sny -p TESTPDB1

--------------------------------------------------------------------------------
9. LOCAL PDB CLONE
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -k BNYPDB3_CLONE -c sny -p BNYPDB3

--------------------------------------------------------------------------------
10. REMOTE PDB CLONE
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -R \
    -c sny \
    -p BNYPDB3 \
    -t BNYPDB3_NEW \
    -s bny_exa \
    -a dbhost-ttqtv-scan.example.com \
    -P 1521 \
    -w 'SOURCE_SYS_PASSWORD'

--------------------------------------------------------------------------------
11. REMOTE CLONE FROM NON-EXADATA SOURCE
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -R -N \
    -c sny \
    -p ORCLPDB \
    -t ORCLPDB_NEW \
    -s orcl19 \
    -a source-host.example.com \
    -P 1521 \
    -w 'SOURCE_SYS_PASSWORD'

--------------------------------------------------------------------------------
12. CREATE A MANUAL REFRESHABLE PDB
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -f \
    -c sny \
    -p BNYPDB3 \
    -t BNYPDB3_REFRESH \
    -s bny_exa \
    -a dbhost-ttqtv-scan.ociodaadelegat.ocicsuodaavnet.oraclevcn.com \
    -P 1521 \
    -g bny_exa.ociodaadelegat.ocicsuodaavnet.oraclevcn.com \
    -I 0 \
    -w 'SOURCE_SYS_PASSWORD' \
    -K 'TARGET_KEYSTORE_PASSWORD'

--------------------------------------------------------------------------------
13. CREATE AN AUTOMATICALLY REFRESHED CLONE EVERY 60 MINUTES
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -f \
    -c sny \
    -p BNYPDB3 \
    -t BNYPDB3_REFRESH \
    -s bny_exa \
    -a dbhost-ttqtv-scan.ociodaadelegat.ocicsuodaavnet.oraclevcn.com \
    -P 1521 \
    -g bny_exa.ociodaadelegat.ocicsuodaavnet.oraclevcn.com \
    -I 60 \
    -w 'SOURCE_SYS_PASSWORD' \
    -K 'TARGET_KEYSTORE_PASSWORD'

  Generated SQL includes:
    REFRESH MODE EVERY 60 MINUTES

  Other intervals:
    -I 15      Every 15 minutes
    -I 30      Every 30 minutes
    -I 60      Every 60 minutes
    -I 120     Every 120 minutes
    -I 1440    Every 24 hours
    -I 0       Manual refresh mode

--------------------------------------------------------------------------------
14. MANUAL REFRESH
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -M -c sny -p BNYPDB3_REFRESH

--------------------------------------------------------------------------------
15. DISPLAY REFRESHABLE PDB STATUS
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -q -c sny -p BNYPDB3_REFRESH

--------------------------------------------------------------------------------
16. CREATE WRITABLE SNAPSHOT-COPY PDB FOR TESTING
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} --snapshot-test-enable \
    -c sny \
    -p BNYPDB3_REFRESH \
    -t BNYPDB3_TEST

--------------------------------------------------------------------------------
17. DROP TEST SNAPSHOT AND RESUME REFRESH
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} --snapshot-test-disable \
    -c sny \
    -p BNYPDB3_REFRESH \
    -t BNYPDB3_TEST

--------------------------------------------------------------------------------
18. FINAL REFRESH AND CONVERT TO READ WRITE
--------------------------------------------------------------------------------
  Interactive:
  ${SCRIPT_NAME} -C -c sny -p BNYPDB3_REFRESH

  Auto-confirm:
  ${SCRIPT_NAME} -C -c sny -p BNYPDB3_REFRESH -y

  Dry run:
  ${SCRIPT_NAME} -C -c sny -p BNYPDB3_REFRESH -n

  Workflow:
    1. Final refresh
    2. REFRESH MODE NONE
    3. OPEN READ WRITE
    4. SAVE STATE

  WARNING: REFRESH MODE NONE permanently disables future refreshes.

--------------------------------------------------------------------------------
19. REFRESHABLE PDB SWITCHOVER
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -S \
    -p BNYPDB3 \
    -t BNYPDB3_REFRESH \
    -s bny_exa \
    -g bny_exa \
    -a source-scan.example.com \
    -P 1521 \
    -b CLONE_TARGET_LINK \
    -w 'SOURCE_SYS_PASSWORD'

--------------------------------------------------------------------------------
20. USE AN EXISTING DATABASE LINK
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -f \
    -c sny \
    -p BNYPDB3 \
    -t BNYPDB3_REFRESH \
    -b BNY_EXA_LINK \
    -K 'TARGET_KEYSTORE_PASSWORD'

--------------------------------------------------------------------------------
21. AUTO-CREATE DATABASE LINK AND CLONE USER
--------------------------------------------------------------------------------
  Omit -b and provide source connection details:

  ${SCRIPT_NAME} -f \
    -c sny \
    -p BNYPDB3 \
    -t BNYPDB3_REFRESH \
    -s bny_exa \
    -a source-scan.example.com \
    -P 1521 \
    -g bny_exa.example.com \
    -w 'SOURCE_SYS_PASSWORD' \
    -K 'TARGET_KEYSTORE_PASSWORD'

  The script creates or validates:
    C##REMOTE_CLONE_USER
    C##PWD_NON_AGING_DBO
    Required clone privileges
    Database link

--------------------------------------------------------------------------------
22. ORACLE SID AND ORACLE HOME OVERRIDES
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -l \
    -c sny \
    -O sny1 \
    -J /u02/app/oracle/product/19.0.0.0/dbhome_1

--------------------------------------------------------------------------------
23. TARGET KEYSTORE PASSWORD
--------------------------------------------------------------------------------
  -K 'TARGET_KEYSTORE_PASSWORD'

  When omitted for encrypted refreshable clone creation, the script prompts
  securely.

--------------------------------------------------------------------------------
24. COMPLETE MIGRATION WORKFLOW
--------------------------------------------------------------------------------
  1. List source and target PDB inventory
  2. Validate target wallet
  3. Create or validate clone user
  4. Create or validate database link
  5. Create refreshable clone
  6. Run manual or automatic refresh
  7. Create writable snapshot-copy PDB for testing
  8. Drop test snapshot
  9. Perform final refresh
 10. Set REFRESH MODE NONE
 11. Open target PDB READ WRITE
 12. Save state and validate application connectivity


--------------------------------------------------------------------------------
25. DISPLAY ENCRYPTION STATUS
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -E -c sny

--------------------------------------------------------------------------------
26. ENCRYPT ALL PERMANENT PDB TABLESPACES
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} -e -c sny -p TESTPDB1 \
    --encryption-algorithm AES256

--------------------------------------------------------------------------------
27. FIX POST-CLONE PDB VIOLATIONS
--------------------------------------------------------------------------------
  ${SCRIPT_NAME} --fix-pdb-violations -c SNY -p LNYPDB5

  Default workflow:
    1. Review unresolved PDB_PLUG_IN_VIOLATIONS
    2. Run Datapatch twice for the selected PDB
    3. Run utlrp.sql
    4. Encrypt all unencrypted permanent tablespaces using AES256
       including SYSTEM, SYSAUX, and USERS
    5. Bounce the PDB on all RAC instances
    6. Validate invalid objects
    7. Validate DBA_REGISTRY_SQLPATCH
    8. Validate tablespace encryption and block sizes
    9. Recheck unresolved plug-in violations
   10. Validate READ WRITE and RESTRICTED status

  Optional controls:
    --fix-passes 1
    --skip-fix-encryption
    --exclude-system-ts
    --skip-fix-utlrp
    --skip-fix-bounce
    --skip-fix-validation
    --fix-encryption-algorithm AES256

  RAC option mismatch warnings may remain because RAC is a CDB-level option.

SUPPORTED PLATFORMS
  Oracle Database@Azure
  Oracle Cloud Infrastructure
  Oracle Exadata
  Oracle RAC
  Oracle Single Instance
  Non-Exadata source databases
  Oracle Database 19c and later
  DBaaSCLI
  SQL*Plus
  TDE/AES256
  Refreshable PDB
  Snapshot-copy testing
================================================================================
EOF
}

# LTMdbMigration360 v3.1.0 Release Notes

Released: 2026-08-04

## New in v3.1

- Parallel database health execution with configurable worker limits.
- Persistent workflow checkpoints under `state/`.
- Resume interrupted Subscription-to-Subscription migrations.
- Structured reports in HTML, JSON, and CSV.
- Optional PDF conversion when `LTM_ENABLE_PDF=true` and `wkhtmltopdf` or Chromium is installed.
- Run-specific log and report directories.
- Developer and release utilities moved to `tools/`.
- Unit-test framework under `tests/`.

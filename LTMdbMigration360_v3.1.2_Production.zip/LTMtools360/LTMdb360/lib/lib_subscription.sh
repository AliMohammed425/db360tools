#!/usr/bin/env bash
# LTMdbMigration360 module: lib_subscription.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# subscription_script_path
# -----------------------------------------------------------------------------
subscription_script_path() {
  local script_name="$1"
  printf '%s/%s\n' "$SCRIPT_DIR" "$script_name"
}

# -----------------------------------------------------------------------------
# subscription_require_script
# -----------------------------------------------------------------------------
subscription_require_script() {
  local script_path="$1"

  [[ -f "$script_path" ]] ||
    die "Required Subscription migration script was not found: $script_path"

  [[ -x "$script_path" ]] ||
    die "Required script is not executable: $script_path. Run chmod 700 $script_path"
}

# -----------------------------------------------------------------------------
# subscription_run
# -----------------------------------------------------------------------------
subscription_run() {
  local script_name="$1"
  shift
  local script_path=""

  script_path="$(subscription_script_path "$script_name")"
  subscription_require_script "$script_path"
  menu_confirm_run "$script_path" "$@"
}

# -----------------------------------------------------------------------------
# subscription_prompt_database
# -----------------------------------------------------------------------------
subscription_prompt_database() {
  local variable_name="$1"
  local db_name=""
  menu_read db_name "Database name from ltm_migration.ini"
  [[ -n "$db_name" ]] || {
    printf 'Database name is required.\n'
    return 1
  }
  printf -v "$variable_name" '%s' "$db_name"
}

# -----------------------------------------------------------------------------
# subscription_validate_config
# -----------------------------------------------------------------------------
subscription_validate_config() {
  local ini_file="$DEFAULT_MIGRATION_INI"

  menu_header
  printf 'Subscription-to-Subscription: Validate Configuration\n\n'
  menu_read ini_file "Migration INI file" "$DEFAULT_MIGRATION_INI"

  [[ -r "$ini_file" ]] || {
    printf 'INI file is not readable: %s\n' "$ini_file"
    return 1
  }

  printf '\nConfiguration file: %s\n' "$ini_file"
  printf 'Permissions       : '
  stat -c '%a %U:%G' "$ini_file" 2>/dev/null || true
  printf '\nHeader validation\n'
  printf '%s\n' '-----------------'

  local expected_header='dbName|dbUniqueName|dbSID|dbCharset|dbNCharset|pdatafileDestination|pfraDestination|pNodeList|port|syspass|tdepass|primaryScanIPAddresses|primaryScanPort|pServiceName|standbyScanIPAddresses|standbyScanPort|sServiceName|standbyDBUniqueName|sdatafileDestination|sfraDestination|sNodeList|flagSkip|dbBlockSizeInKB|enableCDB|dbHome'
  local actual_header=""
  actual_header="$(head -1 "$ini_file" | tr -d '\r')"

  if [[ "$actual_header" == "$expected_header" ]]; then
    printf 'PASS: ltm_migration.ini header matches the documented format.\n'
  else
    printf 'FAIL: ltm_migration.ini header does not match the documented format.\n'
    printf 'Expected: %s\n' "$expected_header"
    printf 'Actual  : %s\n' "$actual_header"
    return 1
  fi

  if [[ "$(stat -c '%a' "$ini_file" 2>/dev/null || echo 000)" == "600" ]]; then
    printf 'PASS: Recommended file permission 600 is configured.\n'
  else
    printf 'WARN: Recommended permission is 600.\n'
  fi
}

# -----------------------------------------------------------------------------
# subscription_precheck_primary
# -----------------------------------------------------------------------------
subscription_precheck_primary() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_create_precheck.sh" -p -d "$db" -t
}

# -----------------------------------------------------------------------------
# subscription_precheck_standby
# -----------------------------------------------------------------------------
subscription_precheck_standby() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_create_precheck.sh" -s -d "$db" -t
}

# -----------------------------------------------------------------------------
# subscription_create_primary
# -----------------------------------------------------------------------------
subscription_create_primary() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_create.sh" -p -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_create_standby
# -----------------------------------------------------------------------------
subscription_create_standby() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_create.sh" -s -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_prepare_standby_test
# -----------------------------------------------------------------------------
subscription_prepare_standby_test() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_prepare_standby.sh" -d "$db" -t
}

# -----------------------------------------------------------------------------
# subscription_prepare_standby_live
# -----------------------------------------------------------------------------
subscription_prepare_standby_live() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_prepare_standby.sh" -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_build_standby_test
# -----------------------------------------------------------------------------
subscription_build_standby_test() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_build_standby.sh" -d "$db" -t
}

# -----------------------------------------------------------------------------
# subscription_build_standby_live
# -----------------------------------------------------------------------------
subscription_build_standby_live() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_build_standby.sh" -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_dg_status_primary_all
# -----------------------------------------------------------------------------
subscription_dg_status_primary_all() {
  subscription_run "ltm_dg_manager.sh" -p --status --all
}

# -----------------------------------------------------------------------------
# subscription_dg_status_standby
# -----------------------------------------------------------------------------
subscription_dg_status_standby() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_dg_manager.sh" -s --status -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_switchover_test
# -----------------------------------------------------------------------------
subscription_switchover_test() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_dg_manager.sh" -p --switchover -d "$db" -t
}

# -----------------------------------------------------------------------------
# subscription_switchover_live
# -----------------------------------------------------------------------------
subscription_switchover_live() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_dg_manager.sh" -p --switchover -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_health_all
# -----------------------------------------------------------------------------
subscription_health_all() {
  subscription_run "ltm_db_health.sh" --all
}

# -----------------------------------------------------------------------------
# subscription_health_database
# -----------------------------------------------------------------------------
subscription_health_database() {
  local db=""
  subscription_prompt_database db || return
  subscription_run "ltm_db_health.sh" -d "$db"
}

# -----------------------------------------------------------------------------
# subscription_move_registration_tar
# -----------------------------------------------------------------------------
subscription_move_registration_tar() {
  subscription_run "ltm_db_registration.sh"
}

# -----------------------------------------------------------------------------
# subscription_full_workflow
# -----------------------------------------------------------------------------
subscription_run_workflow_steps() {
  local db="$1"
  local start_step="${2:-1}"
  local step=0
  local description=""

  subscription_workflow_step() {
    step="$1"
    description="$2"
    shift 2

    (( step < start_step )) && return 0
    checkpoint_step_start "$step" "$description"

    if "$@"; then
      checkpoint_step_success "$step" "$description"
      return 0
    fi

    checkpoint_step_failed "$step" "$description"
    return 1
  }

  subscription_workflow_step 1 "Primary database create precheck" \
    subscription_run "ltm_db_create_precheck.sh" -p -d "$db" -t || return
  subscription_workflow_step 2 "Standby database create precheck" \
    subscription_run "ltm_db_create_precheck.sh" -s -d "$db" -t || return
  subscription_workflow_step 3 "Create target standby database" \
    subscription_run "ltm_db_create.sh" -s -d "$db" || return
  subscription_workflow_step 4 "Prepare source primary for standby" \
    subscription_run "ltm_db_prepare_standby.sh" -d "$db" || return
  subscription_workflow_step 5 "Build standby and configure Data Guard" \
    subscription_run "ltm_db_build_standby.sh" -d "$db" || return
  subscription_workflow_step 6 "Validate Data Guard status" \
    subscription_run "ltm_dg_manager.sh" -s --status -d "$db" || return
  subscription_workflow_step 7 "Run database health check" \
    subscription_run "ltm_db_health.sh" -d "$db" || return
  subscription_workflow_step 8 "Move latest registration TAR files" \
    subscription_run "ltm_db_registration.sh" || return

  checkpoint_complete
  generate_migration_report "$RUN_ID"
}

subscription_full_workflow() {
  local db=""
  local answer=""

  menu_header
  printf 'Subscription-to-Subscription Full Migration Workflow\n\n'
  subscription_prompt_database db || return

  cat <<EOF
Workflow for database: $db

1. Primary create precheck
2. Standby create precheck
3. Create target standby database
4. Prepare source primary for standby
5. Build standby and configure Data Guard
6. Validate Data Guard status
7. Run database health check
8. Move latest DB registration TAR files
9. Generate final HTML/JSON/CSV report

Checkpoint/resume is enabled.
EOF

  read -r -p "Start this workflow? [y/N]: " answer
  [[ "$answer" =~ ^[Yy] ]] || return

  checkpoint_init "subscription_migration" "$db"
  subscription_run_workflow_steps "$db" 1
}

subscription_resume_workflow() {
  local run_id=""
  local state_file=""
  local db=""
  local workflow=""
  local status=""
  local last_step=""
  local next_step=""

  menu_header
  printf 'Resume Interrupted Migration\n\n'
  checkpoint_list
  printf '\n'
  menu_read run_id "Run ID (blank uses latest)" ""
  [[ -n "$run_id" ]] || run_id="$(checkpoint_latest_run)"
  [[ -n "$run_id" ]] || {
    printf 'No checkpoint is available.\n'
    return 1
  }

  state_file="$(checkpoint_state_file "$run_id")"
  [[ -r "$state_file" ]] || {
    printf 'Checkpoint not found: %s\n' "$state_file"
    return 1
  }

  workflow="$(checkpoint_get WORKFLOW "$state_file")"
  db="$(checkpoint_get DATABASE "$state_file")"
  status="$(checkpoint_get STATUS "$state_file")"
  last_step="$(checkpoint_get LAST_SUCCESSFUL_STEP "$state_file")"
  next_step=$(( ${last_step:-0} + 1 ))

  printf 'Workflow             : %s\n' "$workflow"
  printf 'Database             : %s\n' "$db"
  printf 'Current Status       : %s\n' "$status"
  printf 'Last Successful Step : %s\n' "${last_step:-0}"
  printf 'Resume From Step     : %s\n' "$next_step"

  [[ "$workflow" == "subscription_migration" ]] || {
    printf 'Unsupported checkpoint workflow: %s\n' "$workflow"
    return 1
  }

  RUN_ID="$run_id"
  checkpoint_set STATUS RUNNING "$state_file"
  subscription_run_workflow_steps "$db" "$next_step"
}


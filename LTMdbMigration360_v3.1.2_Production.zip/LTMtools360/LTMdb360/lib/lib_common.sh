#!/usr/bin/env bash
# LTMdbMigration360 module: lib_common.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# timestamp
# -----------------------------------------------------------------------------
timestamp() {
  date '+%Y-%m-%d %H:%M:%S'
}

# -----------------------------------------------------------------------------
# log
# -----------------------------------------------------------------------------
log() {
  local level="$1"
  shift
  printf '%s %-5s: %s\n' "$(timestamp)" "$level" "$*"
}

# -----------------------------------------------------------------------------
# info
# -----------------------------------------------------------------------------
info() { log "INFO" "$*"; }

# -----------------------------------------------------------------------------
# ok
# -----------------------------------------------------------------------------
ok()   { log "OK" "$*"; }

# -----------------------------------------------------------------------------
# warn
# -----------------------------------------------------------------------------
warn() { log "WARN" "$*"; }

# -----------------------------------------------------------------------------
# error
# -----------------------------------------------------------------------------
error(){ log "ERROR" "$*" >&2; }

# -----------------------------------------------------------------------------
# die
# -----------------------------------------------------------------------------
die()  { error "$*"; exit 1; }

# -----------------------------------------------------------------------------
# normalize_name
# -----------------------------------------------------------------------------
normalize_name() {
  local value="$1"
  printf '%s' "$value" | tr '[:lower:]' '[:upper:]' | xargs
}

# -----------------------------------------------------------------------------
# validate_oracle_name
# -----------------------------------------------------------------------------
validate_oracle_name() {
  local value="$1"
  local label="$2"

  [[ "$value" =~ ^[A-Z][A-Z0-9_$#]{0,29}$ ]] ||
    die "Invalid ${label}: ${value}. Use 1-30 Oracle identifier characters."
}

# -----------------------------------------------------------------------------
# initialize_logging
# -----------------------------------------------------------------------------
initialize_logging() {
  mkdir -p "$LOG_DIR" || die "Unable to create log directory: $LOG_DIR"
  touch "$MASTER_LOG" "$SUMMARY_LOG" ||
    die "Unable to create log files under: $LOG_DIR"

  exec > >(tee -a "$MASTER_LOG") 2>&1
}

# -----------------------------------------------------------------------------
# validate_environment
# -----------------------------------------------------------------------------
validate_environment() {
  [[ -x "$SUDO_BIN" ]] || die "$SUDO_BIN is unavailable or not executable."
  [[ -x "$DBAASCLI_BIN" ]] || die "$DBAASCLI_BIN is unavailable or not executable."

  info "Running as user: $CURRENT_USER"
  info "Oracle user switching: disabled"
  info "DBaaSCLI execution: $SUDO_BIN $DBAASCLI_BIN"
  info "Validating sudo authorization..."

  "$SUDO_BIN" -v || die "Sudo authorization failed."
  ok "Sudo authorization is available."
}

# -----------------------------------------------------------------------------
# execute_or_display
# -----------------------------------------------------------------------------
execute_or_display() {
  if [[ "$TEST_MODE" == "true" ]]; then
    printf 'DRY RUN:'
    printf ' %q' "$@"
    printf '\n'
    return 0
  fi

  "$@"
}

# -----------------------------------------------------------------------------
# execute_with_password_stdin
# -----------------------------------------------------------------------------
execute_with_password_stdin() {
  local password="$1"
  shift

  if [[ "$TEST_MODE" == "true" ]]; then
    printf 'DRY RUN:'
    printf ' %q' "$@"
    printf ' <password and confirmation supplied through stdin>\n'
    return 0
  fi

  # DBaaSCLI remote_clone prompts twice:
  #   1. Enter REMOTE_DB_SYS_PASSWORD
  #   2. Enter REMOTE_DB_SYS_PASSWORD (reconfirmation)
  # Supply the same password twice without echoing it to logs.
  {
    printf '%s\n' "$password"
    printf '%s\n' "$password"
  } | "$@"
}

# -----------------------------------------------------------------------------
# print_banner
# -----------------------------------------------------------------------------
print_banner() {
  cat <<BANNER

================================================================================
             LTMdbMigration360 Enterprise Database Migration and Lifecycle Utility
================================================================================
Script       : $SCRIPT_NAME
Invoked As   : $INVOKED_NAME
Version      : $SCRIPT_VERSION
Platform     : Oracle Database@Azure / OCI / Exadata
Current user : $CURRENT_USER
Action       : $ACTION
Execution    : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
DBaaSCLI     : $SUDO_BIN $DBAASCLI_BIN
User switch  : Disabled
Master Log   : $MASTER_LOG
Summary Log  : $SUMMARY_LOG
================================================================================
BANNER
}

# -----------------------------------------------------------------------------
# prompt_required
# -----------------------------------------------------------------------------
prompt_required() {
  local variable_name="$1"
  local prompt_text="$2"
  local current_value="${!variable_name:-}"

  if [[ -z "$current_value" ]]; then
    read -r -p "$prompt_text" current_value
    printf -v "$variable_name" '%s' "$current_value"
  fi

  [[ -n "${!variable_name:-}" ]] || die "A required value was not provided."
}

# -----------------------------------------------------------------------------
# confirm_action
# -----------------------------------------------------------------------------
confirm_action() {
  local prompt_text="$1"
  local answer=""

  if [[ "$TEST_MODE" == "true" ]]; then
    info "DRY RUN: $prompt_text"
    return 0
  fi

  if [[ "$ASSUME_YES" == "true" ]]; then
    info "Auto-confirmed with -y: $prompt_text"
    return 0
  fi

  read -r -p "${prompt_text} [y/N]: " answer

  case "$answer" in
    y|Y|yes|YES|Yes)
      return 0
      ;;
    n|N|no|NO|No|"")
      die "Operation cancelled."
      ;;
    *)
      die "Invalid response '$answer'. Enter y or n."
      ;;
  esac
}

# -----------------------------------------------------------------------------
# warn_if_obsolete_script_name
# -----------------------------------------------------------------------------
warn_if_obsolete_script_name() {
  if [[ "$INVOKED_NAME" != "$SCRIPT_NAME" ]]; then
    warn "Obsolete script filename detected: $INVOKED_NAME"
    warn "Use only the supported production filename: $SCRIPT_NAME"
  fi
}

# -----------------------------------------------------------------------------
# validate_cli_option_map
# -----------------------------------------------------------------------------
validate_cli_option_map() {
  local option_string=":YzeLlidoxRk:r:fMSqEXCQ:V:W:Z:c:p:m:u:s:a:P:t:T:w:Nb:I:g:O:J:K:U:F:AGBDyjvHh"
  [[ "$option_string" == *z* ]] || die "Internal CLI error: -z create-PDB option is missing."
}

# -----------------------------------------------------------------------------
# escape_sql_double_quoted_value
# -----------------------------------------------------------------------------
escape_sql_double_quoted_value() {
  printf '%s' "$1" | sed 's/"/""/g'
}

# -----------------------------------------------------------------------------
# create_one_pdb
# -----------------------------------------------------------------------------


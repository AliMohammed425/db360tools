#!/usr/bin/env bash
# LTMdbMigration360 module: lib_remediation.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# action_fix_pdb_violations
# -----------------------------------------------------------------------------
action_fix_pdb_violations() {
  local exact_pdb=""
  local oracle_home=""

  require_cdb
  require_single_pdb
  validate_cdb_exists

  exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "PDB $PDB_LIST was not found in CDB $CDB_NAME."

  resolve_local_oracle_environment
  oracle_home="$ORACLE_HOME_RESOLVED"

  validate_post_clone_algorithm

  cat <<PLAN

Complete Post-Clone PDB Remediation Plan
----------------------------------------
Target CDB             : $CDB_NAME
Target PDB             : $exact_pdb
Oracle SID             : $TARGET_ORACLE_SID
Oracle Home            : $oracle_home
Datapatch Passes       : $POST_CLONE_FIX_PASSES
Compile UTLRP          : $POST_CLONE_FIX_UTLRP
Encrypt Tablespaces    : $POST_CLONE_FIX_ENCRYPT
Encryption Algorithm   : $POST_CLONE_FIX_ALGORITHM
Include SYSTEM/SYSAUX  : $POST_CLONE_FIX_INCLUDE_SYSTEM
Bounce PDB             : $POST_CLONE_FIX_BOUNCE
Require Clean SQL Patch: $POST_CLONE_FIX_REQUIRE_CLEAN_PATCH
Require All Encrypted  : $POST_CLONE_FIX_REQUIRE_ENCRYPTED
Fail on Invalids       : $POST_CLONE_FIX_FAIL_ON_INVALIDS
Execution              : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  warn "This workflow applies SQL patches and encrypts permanent PDB tablespaces."
  warn "The RAC option warning can remain because RAC is a CDB-level option."
  confirm_action "Run complete remediation for PDB $exact_pdb?"

  # 1. Open and inventory the current state.
  post_clone_open_pdb "$exact_pdb"
  post_clone_review_violations "$exact_pdb"
  validate_invalid_objects "$exact_pdb" "BEFORE REMEDIATION"

  # 2. Reconcile RU/OJVM SQL patch state.
  post_clone_run_datapatch "$exact_pdb" "$oracle_home"

  # 3. Recompile objects after SQL patch changes.
  if [[ "$POST_CLONE_FIX_UTLRP" == "true" ]]; then
    compile_utlrp_pdb "$exact_pdb" "$oracle_home"
  fi

  # 4. Encrypt SYSTEM, SYSAUX, USERS, and every unencrypted permanent TS.
  if [[ "$POST_CLONE_FIX_ENCRYPT" == "true" ]]; then
    validate_target_keystore
    post_clone_encrypt_tablespaces "$exact_pdb"
  fi

  # 5. Bounce to remove restricted mode and refresh violation state.
  if [[ "$POST_CLONE_FIX_BOUNCE" == "true" ]]; then
    datapatch_bounce_pdb "$exact_pdb"
  fi

  # 6. Run a second UTLRP after bounce when enabled.
  if [[ "$POST_CLONE_FIX_UTLRP" == "true" ]]; then
    compile_utlrp_pdb "$exact_pdb" "$oracle_home"
  fi

  # 7. Validate everything and fail if mandatory conditions remain.
  validate_invalid_objects "$exact_pdb" "AFTER REMEDIATION"
  datapatch_verify_sql_inventory "$exact_pdb"
  datapatch_verify_block_sizes "$exact_pdb"
  post_clone_validate_all "$exact_pdb"
  post_clone_report_rac_warning "$exact_pdb"
  post_clone_assert_clean_state "$exact_pdb"

  ok "Complete post-clone remediation finished successfully for PDB $exact_pdb."
}

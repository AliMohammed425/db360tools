#!/usr/bin/env bash
# LTMdbMigration360 module: lib_oracle.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# run_dbaascli
# -----------------------------------------------------------------------------
run_dbaascli() {
  "$SUDO_BIN" "$DBAASCLI_BIN" "$@"
}

# -----------------------------------------------------------------------------
# resolve_local_oracle_environment
# -----------------------------------------------------------------------------
resolve_local_oracle_environment() {
  local requested_db="$CDB_NAME"
  local candidate_db="$CDB_NAME"
  local status_output=""
  local config_output=""
  local pmon_sid=""
  local oratab_sid=""
  local db_unique_name=""

  # 1. Try the DBaaSCLI/Clusterware database name directly.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    status_output="$(
      "$SUDO_BIN" -u oracle /bin/bash -c \
        "srvctl status database -d '$candidate_db' 2>/dev/null" || true
    )"

    TARGET_ORACLE_SID="$(
      printf '%s\n' "$status_output" |
        awk '/^Instance[[:space:]]+/ {print $2; exit}'
    )"
  fi

  # 2. Resolve DB_UNIQUE_NAME from DBaaSCLI JSON and retry srvctl.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    db_unique_name="$(
      run_dbaascli system getDatabases 2>/dev/null |
        awk -v requested="$requested_db" '
          function clean(v) {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
            gsub(/^"|"[,]?$/, "", v)
            return v
          }

          /"dbName"[[:space:]]*:/ {
            line=$0
            sub(/^.*"dbName"[[:space:]]*:[[:space:]]*/, "", line)
            current_db=clean(line)
          }

          /"dbUniqueName"[[:space:]]*:/ {
            line=$0
            sub(/^.*"dbUniqueName"[[:space:]]*:[[:space:]]*/, "", line)
            unique_name=clean(line)

            if (toupper(current_db) == toupper(requested)) {
              print unique_name
              exit
            }
          }
        '
    )"

    if [[ -n "$db_unique_name" ]]; then
      candidate_db="$db_unique_name"
      info "Resolved target DB_UNIQUE_NAME: $candidate_db"

      status_output="$(
        "$SUDO_BIN" -u oracle /bin/bash -c \
          "srvctl status database -d '$candidate_db' 2>/dev/null" || true
      )"

      TARGET_ORACLE_SID="$(
        printf '%s\n' "$status_output" |
          awk '/^Instance[[:space:]]+/ {print $2; exit}'
      )"
    fi
  fi

  # 3. Try running PMON processes.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    pmon_sid="$(
      ps -ef |
        awk -v db="$requested_db" '
          /ora_pmon_/ && $0 !~ /awk/ {
            sid=$NF
            sub(/^ora_pmon_/, "", sid)

            if (toupper(sid) ~ "^" toupper(db)) {
              print sid
              exit
            }
          }
        '
    )"

    [[ -n "$pmon_sid" ]] && TARGET_ORACLE_SID="$pmon_sid"
  fi

  # 4. Try /etc/oratab using CDB name, DB_UNIQUE_NAME, or SID prefix.
  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    oratab_sid="$(
      awk -F: -v db="$requested_db" -v uniq="$db_unique_name" '
        $1 !~ /^#/ && NF >= 2 {
          sid=$1

          if (toupper(sid) == toupper(db) ||
              (uniq != "" && toupper(sid) == toupper(uniq)) ||
              toupper(sid) ~ "^" toupper(db)) {
            print sid
            exit
          }
        }
      ' /etc/oratab 2>/dev/null
    )"

    [[ -n "$oratab_sid" ]] && TARGET_ORACLE_SID="$oratab_sid"
  fi

  ORACLE_HOME_RESOLVED="${TARGET_ORACLE_HOME:-}"

  # Resolve ORACLE_HOME from srvctl.
  if [[ -z "$ORACLE_HOME_RESOLVED" && -n "$candidate_db" ]]; then
    config_output="$(
      "$SUDO_BIN" -u oracle /bin/bash -c \
        "srvctl config database -d '$candidate_db' 2>/dev/null" || true
    )"

    ORACLE_HOME_RESOLVED="$(
      printf '%s\n' "$config_output" |
        awk -F':[[:space:]]*' '
          tolower($1) ~ /^oracle home$/ {
            print $2
            exit
          }
        '
    )"
  fi

  # Fall back to /etc/oratab.
  if [[ -z "$ORACLE_HOME_RESOLVED" && -n "$TARGET_ORACLE_SID" ]]; then
    ORACLE_HOME_RESOLVED="$(
      awk -F: -v sid="$TARGET_ORACLE_SID" '
        $1 !~ /^#/ && toupper($1) == toupper(sid) {
          print $2
          exit
        }
      ' /etc/oratab 2>/dev/null
    )"
  fi

  # Derive ORACLE_HOME from the running PMON process.
  if [[ -z "$ORACLE_HOME_RESOLVED" && -n "$TARGET_ORACLE_SID" ]]; then
    local pmon_pid=""
    local oracle_exe=""

    pmon_pid="$(
      ps -eo pid=,args= |
        awk -v sid="$TARGET_ORACLE_SID" '
          index($0, "ora_pmon_" sid) {
            print $1
            exit
          }
        '
    )"

    if [[ -n "$pmon_pid" ]]; then
      oracle_exe="$(
        "$SUDO_BIN" readlink -f "/proc/${pmon_pid}/exe" 2>/dev/null || true
      )"

      if [[ "$oracle_exe" == */bin/oracle ]]; then
        ORACLE_HOME_RESOLVED="${oracle_exe%/bin/oracle}"
      fi
    fi
  fi

  # Search common Oracle database-home paths as a final automatic fallback.
  if [[ -z "$ORACLE_HOME_RESOLVED" ]]; then
    ORACLE_HOME_RESOLVED="$(
      for sqlplus_bin in \
        /u01/app/oracle/product/*/dbhome_*/bin/sqlplus \
        /u02/app/oracle/product/*/dbhome_*/bin/sqlplus \
        /opt/oracle/product/*/dbhome_*/bin/sqlplus
      do
        [[ -x "$sqlplus_bin" ]] || continue
        dirname "$(dirname "$sqlplus_bin")"
        break
      done
    )"
  fi

  if [[ -z "$TARGET_ORACLE_SID" ]]; then
    error "Unable to determine target Oracle SID automatically."
    error "Checked srvctl database name: $requested_db"
    [[ -n "$db_unique_name" ]] &&
      error "Checked srvctl DB_UNIQUE_NAME: $db_unique_name"
    error "Checked PMON processes and /etc/oratab."
    die "Supply -O ORACLE_SID."
  fi

  [[ -n "${ORACLE_HOME_RESOLVED:-}" &&
     -x "$ORACLE_HOME_RESOLVED/bin/sqlplus" ]] ||
    die "Unable to determine a valid ORACLE_HOME for SID $TARGET_ORACLE_SID. Supply -J ORACLE_HOME."

  info "Oracle SID  : $TARGET_ORACLE_SID"
  info "Oracle Home : $ORACLE_HOME_RESOLVED"
}

# -----------------------------------------------------------------------------
# run_local_sql
# -----------------------------------------------------------------------------
run_local_sql() {
  local sql_text="$1"

  resolve_local_oracle_environment

  if [[ "$TEST_MODE" == "true" ]]; then
    printf '%s\n' "DRY RUN SQL:"
    printf '%s\n' "$sql_text"
    return 0
  fi

  printf '%s\n' "$sql_text" |
    "$SUDO_BIN" -u oracle env \
      ORACLE_SID="$TARGET_ORACLE_SID" \
      ORACLE_HOME="$ORACLE_HOME_RESOLVED" \
      PATH="$ORACLE_HOME_RESOLVED/bin:/usr/bin:/bin" \
      "$ORACLE_HOME_RESOLVED/bin/sqlplus" -s "/ as sysdba"
}

# -----------------------------------------------------------------------------
# run_remote_source_sql
# -----------------------------------------------------------------------------
run_remote_source_sql() {
  local sql_text="$1"
  local service="${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}"
  local connect_descriptor
  local sqlplus_bin

  require_source_db
  require_source_scan
  validate_source_port

  [[ -n "$SOURCE_SYS_PASSWORD" ]] ||
    read -r -s -p "Enter source SYS password: " SOURCE_SYS_PASSWORD
  printf '\n'

  [[ -n "$service" ]] || die "Source service is required; use -g."

  # Use the locally installed Oracle client from the resolved target
  # ORACLE_HOME. Do not depend on sqlplus being present in the opc PATH.
  resolve_local_oracle_environment
  sqlplus_bin="$ORACLE_HOME_RESOLVED/bin/sqlplus"

  [[ -x "$sqlplus_bin" ]] ||
    die "SQL*Plus executable was not found: $sqlplus_bin"

  connect_descriptor="//${SOURCE_DB_SCAN%%,*}:${SOURCE_DB_PORT}/${service}"

  if [[ "$TEST_MODE" == "true" ]]; then
    printf '%s\n' "DRY RUN REMOTE SQL:"
    printf '%s\n' "SQLPLUS: $sqlplus_bin"
    printf '%s\n' "CONNECT SYS/<redacted>@${connect_descriptor} AS SYSDBA"
    printf '%s\n' "$sql_text"
    return 0
  fi

  {
    printf 'whenever sqlerror exit sql.sqlcode\n'
    printf 'set echo off feedback on heading on pages 1000 lines 300\n'
    printf 'connect sys/"%s"@%s as sysdba\n' \
      "$SOURCE_SYS_PASSWORD" "$connect_descriptor"
    printf '%s\n' "$sql_text"
    printf 'exit\n'
  } |
    "$SUDO_BIN" -u oracle env \
      ORACLE_HOME="$ORACLE_HOME_RESOLVED" \
      PATH="$ORACLE_HOME_RESOLVED/bin:/usr/bin:/bin" \
      TNS_ADMIN="${TNS_ADMIN:-$ORACLE_HOME_RESOLVED/network/admin}" \
      "$sqlplus_bin" -s /nolog
}

# -----------------------------------------------------------------------------
# require_cdb
# -----------------------------------------------------------------------------
require_cdb() {
  prompt_required CDB_NAME "Enter existing CDB name: "

  # Preserve the exact CDB case because DBaaSCLI maps --dbname to a
  # case-sensitive cloud registry filename, for example bny.ini.
  CDB_NAME="$(printf '%s' "$CDB_NAME" | xargs)"

  [[ "$CDB_NAME" =~ ^[A-Za-z][A-Za-z0-9_$#.-]{0,127}$ ]] ||
    die "Invalid CDB name: $CDB_NAME"
}

# -----------------------------------------------------------------------------
# require_single_pdb
# -----------------------------------------------------------------------------
require_single_pdb() {
  prompt_required PDB_LIST "Enter PDB name: "

  [[ "$PDB_LIST" != *,* ]] ||
    die "Only one PDB may be supplied for action: $ACTION"

  # Accept upper, lower, or mixed-case user input. The exact registered PDB
  # name is resolved from DBaaSCLI inventory before the operation is executed.
  PDB_LIST="$(printf '%s' "$PDB_LIST" | xargs)"

  [[ "$PDB_LIST" =~ ^[A-Za-z][A-Za-z0-9_$#]{0,29}$ ]] ||
    die "Invalid PDB name: $PDB_LIST. Use 1-30 Oracle identifier characters."

  [[ "${PDB_LIST^^}" != 'PDB\$SEED' ]] ||
    die "This action is not allowed for PDB\$SEED."
}

# -----------------------------------------------------------------------------
# resolve_exact_inventory_name
# -----------------------------------------------------------------------------
resolve_exact_inventory_name() {
  local requested_name="$1"
  local inventory="$2"
  local exact_name=""

  exact_name="$(
    printf '%s\n' "$inventory" |
      awk -v requested="$requested_name" '
        {
          for (i = 1; i <= NF; i++) {
            token=$i

            # Remove common table/JSON delimiters while preserving valid
            # database-name characters such as _, $, #, hyphen, and period.
            gsub(/^[[:space:]"'\''([{<,:;=]+/, "", token)
            gsub(/[[:space:]"'\''\])}>,:;=]+$/, "", token)

            if (toupper(token) == toupper(requested)) {
              print token
              exit
            }
          }
        }
      '
  )"

  [[ -n "$exact_name" ]] || return 1
  printf '%s\n' "$exact_name"
}

# -----------------------------------------------------------------------------
# validate_cdb_exists
# -----------------------------------------------------------------------------
validate_cdb_exists() {
  local requested_cdb="$CDB_NAME"
  local output=""
  local exact_cdb=""

  info "Validating CDB: $requested_cdb"

  # DBaaSCLI 26.x returns JSON from system getDatabases. Older versions may
  # require database list, which returns text lines such as DB Name=bny.
  if ! output="$(run_dbaascli system getDatabases 2>&1)"; then
    warn "system getDatabases failed; retrying with database list."
    if ! output="$(run_dbaascli database list 2>&1)"; then
      printf '%s\n' "$output"
      die "Unable to retrieve the DBaaSCLI database inventory."
    fi
  fi

  # Supported inventory formats:
  #   JSON   : "dbName" : "bny",
  #   Legacy : 2.DB Name=bny
  #
  # Compare case-insensitively, but retain the exact registered spelling.
  exact_cdb="$(
    printf '%s\n' "$output" |
      awk -v requested="$requested_cdb" '
        function trim(value) {
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
          return value
        }

        {
          line=$0
          candidate=""

          if (line ~ /"dbName"[[:space:]]*:/) {
            sub(/^.*"dbName"[[:space:]]*:[[:space:]]*"/, "", line)
            sub(/".*$/, "", line)
            candidate=trim(line)
          }
          else if (line ~ /DB Name[[:space:]]*=/) {
            sub(/^.*DB Name[[:space:]]*=[[:space:]]*/, "", line)
            sub(/[[:space:]]+$/, "", line)
            candidate=trim(line)
          }

          if (candidate != "" &&
              toupper(candidate) == toupper(requested)) {
            print candidate
            exit
          }
        }
      '
  )"

  if [[ -z "$exact_cdb" ]]; then
    printf '%s\n' "$output"
    die "CDB $requested_cdb was not found in DBaaSCLI database inventory."
  fi

  CDB_NAME="$exact_cdb"

  info "Requested CDB name: $requested_cdb"
  info "Resolved CDB name : $CDB_NAME"

  if [[ "$requested_cdb" != "$CDB_NAME" ]]; then
    warn "CDB names $requested_cdb and $CDB_NAME refer to the same registered database."
    warn "Using exact DBaaSCLI registry name: $CDB_NAME"
  fi

  ok "CDB $CDB_NAME exists."
}

# -----------------------------------------------------------------------------
# get_pdb_inventory
# -----------------------------------------------------------------------------
get_pdb_inventory() {
  run_dbaascli database getPDBs --dbName "$CDB_NAME"
}

# -----------------------------------------------------------------------------
# resolve_exact_pdb_name
# -----------------------------------------------------------------------------
resolve_exact_pdb_name() {
  local requested_name="$1"
  local inventory="$2"

  resolve_exact_inventory_name "$requested_name" "$inventory"
}

# -----------------------------------------------------------------------------
# pdb_exists
# -----------------------------------------------------------------------------
pdb_exists() {
  local pdb_name="$1"
  local inventory="$2"

  resolve_exact_pdb_name "$pdb_name" "$inventory" >/dev/null 2>&1
}

# -----------------------------------------------------------------------------
# resolve_existing_pdb
# -----------------------------------------------------------------------------
resolve_existing_pdb() {
  local requested_name="$1"
  local inventory="$2"
  local exact_name=""

  exact_name="$(resolve_exact_pdb_name "$requested_name" "$inventory")" ||
    return 1

  printf '%s\n' "$exact_name"
}

# -----------------------------------------------------------------------------
# require_source_db
# -----------------------------------------------------------------------------
require_source_db() {
  prompt_required SOURCE_DB_UNIQUE_NAME "Enter source DB_UNIQUE_NAME: "
  SOURCE_DB_UNIQUE_NAME="$(printf '%s' "$SOURCE_DB_UNIQUE_NAME" | xargs)"
  [[ "$SOURCE_DB_UNIQUE_NAME" =~ ^[A-Za-z][A-Za-z0-9_$#.-]{0,127}$ ]] ||
    die "Invalid source DB_UNIQUE_NAME: $SOURCE_DB_UNIQUE_NAME"
}

# -----------------------------------------------------------------------------
# require_source_scan
# -----------------------------------------------------------------------------
require_source_scan() {
  prompt_required SOURCE_DB_SCAN \
    "Enter source SCAN/hostname or comma-separated IP addresses: "
  SOURCE_DB_SCAN="$(printf '%s' "$SOURCE_DB_SCAN" | tr -d '[:space:]')"
  [[ -n "$SOURCE_DB_SCAN" ]] || die "Source SCAN/hostname is required."
}

# -----------------------------------------------------------------------------
# validate_source_port
# -----------------------------------------------------------------------------
validate_source_port() {
  [[ "$SOURCE_DB_PORT" =~ ^[0-9]+$ ]] ||
    die "Invalid source listener port: $SOURCE_DB_PORT"
  (( SOURCE_DB_PORT >= 1 && SOURCE_DB_PORT <= 65535 )) ||
    die "Source listener port must be between 1 and 65535."
}

# -----------------------------------------------------------------------------
# source_network_precheck
# -----------------------------------------------------------------------------
source_network_precheck() {
  local endpoint
  local failures=0
  local -a endpoints=()

  IFS=',' read -r -a endpoints <<< "$SOURCE_DB_SCAN"

  printf '\nSource Network Precheck\n'
  printf '%s\n' '-----------------------'

  for endpoint in "${endpoints[@]}"; do
    endpoint="$(printf '%s' "$endpoint" | xargs)"
    [[ -n "$endpoint" ]] || continue

    if getent ahosts "$endpoint" >/dev/null 2>&1; then
      printf '  %-35s DNS/Host resolution: PASS\n' "$endpoint"
    else
      printf '  %-35s DNS/Host resolution: FAIL\n' "$endpoint"
      ((failures+=1))
      continue
    fi

    if command -v timeout >/dev/null 2>&1 &&
       timeout 3 bash -c "exec 3<>/dev/tcp/${endpoint}/${SOURCE_DB_PORT}" \
         >/dev/null 2>&1; then
      printf '  %-35s TCP/%s: PASS\n' "$endpoint" "$SOURCE_DB_PORT"
    else
      printf '  %-35s TCP/%s: WARN (not verified)\n' \
        "$endpoint" "$SOURCE_DB_PORT"
    fi
  done

  (( failures == 0 )) ||
    warn "One or more source endpoints did not resolve. DBaaSCLI may fail."
}

# -----------------------------------------------------------------------------
# resolve_existing_pdb_sql
# -----------------------------------------------------------------------------
resolve_existing_pdb_sql() {
  local requested_pdb="$1"
  local sql
  local output
  local exact_pdb

  sql="whenever sqlerror exit sql.sqlcode
set heading off feedback off pages 0 verify off echo off
alter session set container=CDB\$ROOT;
select name
from v\$pdbs
where upper(name)=upper('${requested_pdb}');
exit"

  output="$(run_local_sql "$sql" 2>/dev/null || true)"

  exact_pdb="$(
    printf '%s\n' "$output" |
      awk '
        NF == 1 &&
        $1 !~ /^(Session|Elapsed:|Connected|Disconnected)$/ {
          print $1
          exit
        }
      '
  )"

  [[ -n "$exact_pdb" ]] || return 1
  printf '%s\n' "$exact_pdb"
}

# -----------------------------------------------------------------------------
# wait_for_pdb_state
# -----------------------------------------------------------------------------
wait_for_pdb_state() {
  local pdb_name="$1"
  local expected="$2"   # present|absent
  local timeout_seconds="${3:-900}"
  local interval_seconds="${4:-15}"
  local elapsed=0
  local inventory

  while (( elapsed < timeout_seconds )); do
    inventory="$(get_pdb_inventory 2>/dev/null || true)"

    if [[ "$expected" == "present" ]] && pdb_exists "$pdb_name" "$inventory"; then
      return 0
    fi

    if [[ "$expected" == "absent" ]] && ! pdb_exists "$pdb_name" "$inventory"; then
      return 0
    fi

    sleep "$interval_seconds"
    elapsed=$((elapsed + interval_seconds))
    info "Waiting for PDB registry update: $pdb_name ($elapsed/${timeout_seconds}s)"
  done

  return 1
}

# -----------------------------------------------------------------------------
# escape_sql_double_quoted_value
# -----------------------------------------------------------------------------


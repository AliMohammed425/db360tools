#!/usr/bin/env bash
# LTMdbMigration360 module: lib_pdb_lifecycle.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# action_list_cdbs
# -----------------------------------------------------------------------------
action_list_cdbs() {
  local output=""

  info "Listing all CDBs and PDBs..."

  if ! output="$(run_dbaascli system getDatabases 2>&1)"; then
    warn "system getDatabases failed; retrying with database list."
    run_dbaascli database list
    return
  fi

  if [[ "$JSON_OUTPUT" == "true" ]]; then
    printf '%s\n' "$output"
    return
  fi

  printf '%s\n' "$output" |
    awk '
      function indent_count(line,    copy) {
        copy=line
        sub(/[^ ].*$/, "", copy)
        return length(copy)
      }

      function print_cdb(    i, list) {
        if (current_cdb == "") {
          return
        }

        list=""
        for (i = 1; i <= pdb_count; i++) {
          list = list (i == 1 ? "" : ",") pdb_names[i]
        }

        printf "CDB: %s\n", current_cdb
        printf "PDBS: %s\n\n", (list == "" ? "NONE" : list)

        delete pdb_names
        delete seen_pdb
        pdb_count=0
      }

      {
        line=$0

        if (line ~ /"dbName"[[:space:]]*:/) {
          value=line
          sub(/^.*"dbName"[[:space:]]*:[[:space:]]*"/, "", value)
          sub(/".*$/, "", value)

          if (current_cdb != "" && value != current_cdb) {
            print_cdb()
          }

          current_cdb=value
          in_pdbs=0
          pdbs_indent=-1
          next
        }

        if (current_cdb != "" &&
            line ~ /"pdbs"[[:space:]]*:[[:space:]]*\{/) {
          in_pdbs=1
          pdbs_indent=indent_count(line)
          next
        }

        if (in_pdbs == 1) {
          current_indent=indent_count(line)

          if (line ~ /^[[:space:]]*\}[,]?[[:space:]]*$/ &&
              current_indent <= pdbs_indent) {
            in_pdbs=0
            next
          }

          if (line ~ /"pdbName"[[:space:]]*:/) {
            value=line
            sub(/^.*"pdbName"[[:space:]]*:[[:space:]]*"/, "", value)
            sub(/".*$/, "", value)

            if (!(value in seen_pdb)) {
              pdb_count++
              pdb_names[pdb_count]=value
              seen_pdb[value]=1
            }
          }
        }
      }

      END {
        print_cdb()
      }
    '
}

# -----------------------------------------------------------------------------
# action_list_pdbs
# -----------------------------------------------------------------------------
action_list_pdbs() {
  local inventory
  local sql

  require_cdb
  validate_cdb_exists

  # Preserve raw DBaaSCLI output for automation consumers.
  if [[ "$JSON_OUTPUT" == "true" ]]; then
    inventory="$(get_pdb_inventory)" ||
      die "Unable to retrieve PDB inventory for CDB $CDB_NAME."
    printf '%s\n' "$inventory"
    return
  fi

  # Query Oracle directly so mounted refreshable PDBs are also displayed.
  sql="whenever sqlerror exit sql.sqlcode
set lines 220 pages 1000 trimspool on tab off
set feedback off verify off echo off

column cdb_name      format a20
column db_unique     format a30
column pdb_name      format a30
column mode_code     format a4  heading 'MODE'
column open_mode     format a12 heading 'OPEN MODE'
column refresh_mode  format a12 heading 'REFRESH'
column status        format a12
column restricted    format a10 heading 'RESTRICTED'
column encrypted     format a10 heading 'ENCRYPTED'

prompt
prompt ================================================================================
prompt Oracle PDB Inventory
prompt ================================================================================

select name cdb_name,
       db_unique_name db_unique
from v\$database;

prompt
select p.pdb_name,
       case v.open_mode
         when 'READ WRITE' then 'R/W'
         when 'READ ONLY'  then 'R/O'
         when 'MOUNTED'    then 'M'
         else substr(v.open_mode,1,4)
       end mode_code,
       v.open_mode,
       nvl(p.refresh_mode,'NONE') refresh_mode,
       p.status,
       v.restricted,
       case
         when exists (
           select 1
             from v\$encrypted_tablespaces e
            where e.con_id = v.con_id
         ) then 'ENABLED'
         else 'DISABLED'
       end encrypted
from dba_pdbs p
join v\$pdbs v
  on v.con_id = p.pdb_id
order by v.con_id;

prompt
prompt Legend: R/W=READ WRITE  R/O=READ ONLY  M=MOUNTED
prompt Encryption: ENABLED=one or more encrypted tablespaces; DISABLED=none detected
prompt
exit"

  run_local_sql "$sql" ||
    die "Unable to retrieve SQL PDB inventory for CDB $CDB_NAME."
}

# -----------------------------------------------------------------------------
# action_pdb_info
# -----------------------------------------------------------------------------
action_pdb_info() {
  local inventory
  local requested_pdb
  local exact_pdb

  require_cdb
  require_single_pdb
  requested_pdb="$PDB_LIST"
  validate_cdb_exists

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  exact_pdb="$(resolve_existing_pdb "$requested_pdb" "$inventory")" ||
    die "PDB $requested_pdb was not found in CDB $CDB_NAME."

  PDB_LIST="$exact_pdb"
  info "Requested PDB name: $requested_pdb"
  info "Resolved PDB name : $PDB_LIST"
  info "PDB information: CDB=$CDB_NAME PDB=$PDB_LIST"

  if [[ "$JSON_OUTPUT" == "true" ]]; then
    printf '{\n'
    printf '  "cdb": "%s",\n' "$CDB_NAME"
    printf '  "pdb": "%s",\n' "$PDB_LIST"
    printf '  "inventory_line": "'
    printf '%s\n' "$inventory" |
      awk -v pdb="$PDB_LIST" '
        {
          if (index(toupper($0), toupper(pdb))) {
            print
            exit
          }
        }
      ' |
      sed 's/\\/\\\\/g; s/"/\\"/g' |
      tr -d '\n'
    printf '"\n}\n'
  else
    printf '%s\n' "$inventory" |
      awk -v pdb="$PDB_LIST" '
        NR == 1 || index(toupper($0), toupper(pdb))
      '
  fi
}

# -----------------------------------------------------------------------------
# action_open_pdb
# -----------------------------------------------------------------------------
action_open_pdb() {
  local inventory
  local requested_pdb
  local exact_pdb

  require_cdb
  require_single_pdb
  requested_pdb="$PDB_LIST"
  validate_cdb_exists

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  exact_pdb="$(resolve_existing_pdb "$requested_pdb" "$inventory")" ||
    die "PDB $requested_pdb was not found in CDB $CDB_NAME."

  PDB_LIST="$exact_pdb"
  info "Requested PDB name: $requested_pdb"
  info "Resolved PDB name : $PDB_LIST"
  info "Opening PDB $PDB_LIST in CDB $CDB_NAME..."

  execute_or_display "$SUDO_BIN" "$DBAASCLI_BIN" pdb open \
    --pdbname "$PDB_LIST" \
    --dbName "$CDB_NAME"
}

# -----------------------------------------------------------------------------
# action_close_pdb
# -----------------------------------------------------------------------------
action_close_pdb() {
  local inventory
  local requested_pdb
  local exact_pdb

  require_cdb
  require_single_pdb
  requested_pdb="$PDB_LIST"
  validate_cdb_exists

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  exact_pdb="$(resolve_existing_pdb "$requested_pdb" "$inventory")" ||
    die "PDB $requested_pdb was not found in CDB $CDB_NAME."

  PDB_LIST="$exact_pdb"
  info "Requested PDB name: $requested_pdb"
  info "Resolved PDB name : $PDB_LIST"
  info "Closing PDB $PDB_LIST in CDB $CDB_NAME..."

  execute_or_display "$SUDO_BIN" "$DBAASCLI_BIN" pdb close \
    --pdbname "$PDB_LIST" \
    --dbName "$CDB_NAME"
}

# -----------------------------------------------------------------------------
# action_drop_pdb
# -----------------------------------------------------------------------------
action_drop_pdb() {
  local inventory
  local requested_pdb
  local exact_pdb

  require_cdb
  require_single_pdb
  requested_pdb="$PDB_LIST"
  validate_cdb_exists

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  exact_pdb="$(resolve_existing_pdb "$requested_pdb" "$inventory")" ||
    die "PDB $requested_pdb was not found in CDB $CDB_NAME."

  PDB_LIST="$exact_pdb"
  info "Requested PDB name: $requested_pdb"
  info "Resolved PDB name : $PDB_LIST"

  confirm_action "Drop PDB $PDB_LIST from CDB $CDB_NAME?"

  info "Dropping PDB $PDB_LIST from CDB $CDB_NAME..."
  execute_or_display "$SUDO_BIN" "$DBAASCLI_BIN" pdb delete \
    --pdbname "$PDB_LIST" \
    --dbName "$CDB_NAME"
}

# -----------------------------------------------------------------------------
# action_rename_pdb
# -----------------------------------------------------------------------------
action_rename_pdb() {
  local inventory
  local exact_source_pdb

  require_cdb
  require_single_pdb

  if [[ -z "$RENAME_PDB_TO" ]]; then
    prompt_required RENAME_PDB_TO "Enter new PDB name: "
  fi

  RENAME_PDB_TO="$(normalize_name "$RENAME_PDB_TO")"
  validate_oracle_name "$RENAME_PDB_TO" "new PDB name"

  [[ "$RENAME_PDB_TO" != 'PDB\$SEED' ]] ||
    die "PDB\$SEED cannot be used as the new name."

  validate_cdb_exists

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  exact_source_pdb="$(resolve_exact_pdb_name "$PDB_LIST" "$inventory")" ||
    {
      printf '%s\n' "$inventory"
      die "Source PDB $PDB_LIST was not found in CDB $CDB_NAME."
    }

  if pdb_exists "$RENAME_PDB_TO" "$inventory"; then
    die "Target PDB name $RENAME_PDB_TO already exists in CDB $CDB_NAME."
  fi

  info "Requested PDB name: $PDB_LIST"
  info "Resolved PDB name : $exact_source_pdb"
  info "DBaaSCLI CDB argument: --dbname $CDB_NAME"
  info "Renaming PDB $exact_source_pdb to $RENAME_PDB_TO in CDB $CDB_NAME..."

  execute_or_display "$SUDO_BIN" "$DBAASCLI_BIN" pdb rename \
    --pdbname "$exact_source_pdb" \
    --newname "$RENAME_PDB_TO" \
    --dbname "$CDB_NAME"
}

# -----------------------------------------------------------------------------
# parse_pdb_list
# -----------------------------------------------------------------------------
parse_pdb_list() {
  local raw="$1"
  local item
  local -a values=()

  IFS=',' read -r -a values <<< "$raw"

  for item in "${values[@]}"; do
    item="$(normalize_name "$item")"
    [[ -n "$item" ]] || continue
    validate_oracle_name "$item" "PDB name"
    [[ "$item" != 'PDB\$SEED' ]] || die "PDB\$SEED cannot be created."
    printf '%s\n' "$item"
  done
}

# -----------------------------------------------------------------------------
# action_create_pdb
# -----------------------------------------------------------------------------
action_create_pdb() {
  local inventory
  local pdb_name
  local failures=0
  local -a requested_pdbs=()

  require_cdb
  validate_cdb_exists

  # Prompt only when -p was not supplied.
  prompt_required PDB_LIST "Enter new PDB name(s), comma-separated: "

  mapfile -t requested_pdbs < <(parse_pdb_list "$PDB_LIST")
  (( ${#requested_pdbs[@]} > 0 )) ||
    die "No valid PDB names were provided."

  inventory="$(get_pdb_inventory)" ||
    die "Unable to retrieve PDB inventory for CDB $CDB_NAME."

  cat <<PLAN

Creation Plan
-------------
CDB          : $CDB_NAME
PDBs         : ${requested_pdbs[*]}
Maximum Size : ${MAX_SIZE:-Default}
Maximum CPU  : ${MAX_CPU:-Default}
Execution    : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Proceed with PDB creation?"

  for pdb_name in "${requested_pdbs[@]}"; do
    create_one_pdb "$pdb_name" "$inventory" || ((failures+=1))
  done

  write_summary

  if (( failures > 0 )); then
    die "$failures PDB creation operation(s) failed."
  fi

  ok "PDB creation workflow completed."
}

# -----------------------------------------------------------------------------
# create_one_pdb
# -----------------------------------------------------------------------------
create_one_pdb() {
  local pdb_name="$1"
  local inventory="$2"
  local -a cmd

  if pdb_exists "$pdb_name" "$inventory"; then
    warn "PDB $pdb_name already exists in CDB $CDB_NAME. Skipping."
    SKIPPED_PDBS+=("$pdb_name")
    return 0
  fi

  cmd=(
    "$SUDO_BIN"
    "$DBAASCLI_BIN"
    pdb
    create
    --pdbname "$pdb_name"
    --dbName "$CDB_NAME"
  )

  [[ -n "$MAX_SIZE" ]] && cmd+=(--maxsize "$MAX_SIZE")
  [[ -n "$MAX_CPU" ]] && cmd+=(--maxcpu "$MAX_CPU")

  info "Creating PDB $pdb_name in CDB $CDB_NAME..."

  if execute_or_display "${cmd[@]}"; then
    ok "PDB $pdb_name created successfully."
    CREATED_PDBS+=("$pdb_name")
    return 0
  fi

  error "PDB $pdb_name creation failed."
  FAILED_PDBS+=("$pdb_name")
  return 1
}

# -----------------------------------------------------------------------------
# write_summary
# -----------------------------------------------------------------------------


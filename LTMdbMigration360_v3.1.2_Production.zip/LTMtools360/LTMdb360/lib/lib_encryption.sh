#!/usr/bin/env bash
# LTMdbMigration360 module: lib_encryption.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# require_target_keystore_password
# -----------------------------------------------------------------------------
require_target_keystore_password() {
  if [[ -z "$TARGET_KEYSTORE_PASSWORD" ]]; then
    read -r -s -p "Enter target CDB keystore password: " TARGET_KEYSTORE_PASSWORD
    printf '\n'
  fi

  [[ -n "$TARGET_KEYSTORE_PASSWORD" ]] ||
    die "Target CDB keystore password is required for encrypted PDB cloning."
}

# -----------------------------------------------------------------------------
# validate_target_keystore
# -----------------------------------------------------------------------------
validate_target_keystore() {
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
col status for a20
col wallet_type for a20
col keystore_mode for a20
alter session set container=CDB\$ROOT;
select status,
       wallet_type,
       keystore_mode
from v\$encryption_wallet;
exit"

  info "Validating target CDB keystore status..."
  run_local_sql "$sql" ||
    die "Unable to validate target CDB keystore status."
}

# -----------------------------------------------------------------------------
# validate_encryption_algorithm
# -----------------------------------------------------------------------------
validate_encryption_algorithm() {
  ENCRYPTION_ALGORITHM="$(printf '%s' "$ENCRYPTION_ALGORITHM" | tr '[:lower:]' '[:upper:]')"
  case "$ENCRYPTION_ALGORITHM" in
    AES128|AES192|AES256) ;;
    *) die "Invalid encryption algorithm: $ENCRYPTION_ALGORITHM. Use AES128, AES192, or AES256." ;;
  esac
}

# -----------------------------------------------------------------------------
# action_encryption_status
# -----------------------------------------------------------------------------
action_encryption_status() {
  local sql

  require_cdb
  validate_cdb_exists

  sql="whenever sqlerror exit sql.sqlcode
set lines 240 pages 1000 trimspool on
column pdb_name format a30
column open_mode format a12
column encrypted format a10
column encrypted_ts format 999 heading 'ENC_TS'
column wallet_status format a16
column wallet_type format a16
alter session set container=CDB\$ROOT;

select p.name pdb_name,
       p.open_mode,
       case when count(e.ts#) > 0 then 'ENABLED' else 'DISABLED' end encrypted,
       count(e.ts#) encrypted_ts
from v\$pdbs p
left join v\$encrypted_tablespaces e
  on e.con_id = p.con_id
group by p.name, p.open_mode, p.con_id
order by p.con_id;

select con_id,
       status wallet_status,
       wallet_type
from v\$encryption_wallet
order by con_id;

exit"

  run_local_sql "$sql" ||
    die "Unable to retrieve encryption status for CDB $CDB_NAME."
}

# -----------------------------------------------------------------------------
# action_encrypt_tablespaces
# -----------------------------------------------------------------------------
action_encrypt_tablespaces() {
  local exact_pdb
  local exclude_clause=""
  local sql
  local wallet_sql

  require_cdb
  require_single_pdb
  validate_cdb_exists
  validate_encryption_algorithm

  exact_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "PDB $PDB_LIST was not found in CDB $CDB_NAME."

  if [[ "$ENCRYPT_INCLUDE_SYSTEM" != "true" ]]; then
    exclude_clause="and tablespace_name not in ('SYSTEM','SYSAUX')"
  fi

  wallet_sql="whenever sqlerror exit sql.sqlcode
set lines 220 pages 1000
alter session set container=CDB\$ROOT;

select con_id,
       status,
       wallet_type,
       keystore_mode
from v\$encryption_wallet
order by con_id;

exit"

  info "Validating TDE keystore before tablespace encryption..."
  run_local_sql "$wallet_sql" ||
    die "Unable to validate TDE keystore status."

  sql="whenever sqlerror exit sql.sqlcode
set serveroutput on lines 300 pages 1000
alter session set container=${exact_pdb};

declare
  l_sql varchar2(4000);
begin
  for r in (
    select tablespace_name
      from dba_tablespaces
     where contents = 'PERMANENT'
       and encrypted = 'NO'
       ${exclude_clause}
     order by case tablespace_name
                when 'SYSTEM' then 1
                when 'SYSAUX' then 2
                else 3
              end,
              tablespace_name
  ) loop
    l_sql :=
      'alter tablespace ' ||
      dbms_assert.enquote_name(r.tablespace_name, false) ||
      ' encryption online using ''${ENCRYPTION_ALGORITHM}'' encrypt';

    dbms_output.put_line(l_sql);
    execute immediate l_sql;
  end loop;
end;
/

select tablespace_name,
       contents,
       encrypted,
       block_size
from dba_tablespaces
where contents='PERMANENT'
order by case tablespace_name
           when 'SYSTEM' then 1
           when 'SYSAUX' then 2
           else 3
         end,
         tablespace_name;

exit"

  cat <<PLAN

PDB Tablespace Encryption Plan
------------------------------
CDB               : $CDB_NAME
PDB               : $exact_pdb
Algorithm         : $ENCRYPTION_ALGORITHM
Eligible TS       : All unencrypted permanent PDB tablespaces
Include SYSTEM    : $ENCRYPT_INCLUDE_SYSTEM
Include SYSAUX    : $ENCRYPT_INCLUDE_SYSTEM
Always Excluded   : TEMP and UNDO
Execution         : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Encrypt all eligible permanent tablespaces in $exact_pdb using $ENCRYPTION_ALGORITHM?"
  run_local_sql "$sql" ||
    die "Tablespace encryption failed for PDB $exact_pdb."

  ok "Permanent tablespace encryption completed in $exact_pdb using $ENCRYPTION_ALGORITHM."
}

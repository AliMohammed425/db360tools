#!/usr/bin/env bash
# LTMdbMigration360 module: lib_network_link.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# validate_dblink_name
# -----------------------------------------------------------------------------
validate_dblink_name() {
  local value="$1"
  [[ "$value" =~ ^[A-Za-z][A-Za-z0-9_.$#@-]{0,127}$ ]] ||
    die "Invalid database link name: $value"
}

# -----------------------------------------------------------------------------
# generate_default_dblink_name
# -----------------------------------------------------------------------------
generate_default_dblink_name() {
  local base="${SOURCE_DB_UNIQUE_NAME:-SOURCE}"
  base="$(printf '%s' "$base" | tr '[:lower:]' '[:upper:]')"
  base="$(printf '%s' "$base" | sed 's/[^A-Z0-9_$#]/_/g')"
  printf '%s_LINK\n' "${base:0:120}"
}

# -----------------------------------------------------------------------------
# database_link_exists
# -----------------------------------------------------------------------------
database_link_exists() {
  local dblink="$1"
  local sql
  local output

  sql="whenever sqlerror exit sql.sqlcode
set heading off feedback off pages 0 verify off echo off
alter session set container=CDB\$ROOT;
select count(*)
from dba_db_links
where upper(regexp_replace(db_link, '\\..*$', '')) = upper('${dblink}');
exit"

  output="$(run_local_sql "$sql" 2>/dev/null || true)"
  printf '%s\n' "$output" |
    awk '/^[[:space:]]*[0-9]+[[:space:]]*$/ {print $1; exit}'
}

# -----------------------------------------------------------------------------
# prepare_source_clone_user
# -----------------------------------------------------------------------------
prepare_source_clone_user() {
  local clone_user
  local escaped_password
  local dba_grant_sql=""
  local profile_sql=""
  local profile_create_sql=""
  local sql

  clone_user="$(printf '%s' "$SOURCE_DB_USER" | tr '[:lower:]' '[:upper:]')"

  if [[ "$clone_user" == "SYS" || "$clone_user" == "SYSTEM" ]]; then
    warn "$clone_user cannot be used as a normal database-link user."
    warn "Replacing database-link user with C##REMOTE_CLONE_USER."
    clone_user="C##REMOTE_CLONE_USER"
    SOURCE_DB_USER="$clone_user"
  fi

  [[ "$clone_user" == C##* ]] ||
    die "Source clone user must be a common user beginning with C##."

  if [[ -z "$SOURCE_SYS_PASSWORD" ]]; then
    read -r -s -p "Enter source SYS password: " SOURCE_SYS_PASSWORD
    printf '\n'
  fi

  [[ -n "$SOURCE_SYS_PASSWORD" ]] ||
    die "Source SYS password is required."

  if [[ "$AUTO_CREATE_CLONE_USER" != "true" ]]; then
    info "Automatic source clone-user creation is disabled."
    return 0
  fi

  escaped_password="$(printf '%s' "$SOURCE_SYS_PASSWORD" | sed 's/"/""/g')"

  if [[ "$GRANT_DBA_TO_CLONE_USER" == "true" ]]; then
    dba_grant_sql="grant dba to ${clone_user} container=all;"
  fi

  if [[ -n "$CLONE_USER_PROFILE" ]]; then
    profile_create_sql="declare
  l_count number;
begin
  select count(*)
    into l_count
    from dba_profiles
   where profile = upper('${CLONE_USER_PROFILE}');

  if l_count = 0 then
    execute immediate
      'create profile ${CLONE_USER_PROFILE} limit
         failed_login_attempts unlimited
         password_life_time unlimited
         password_reuse_time unlimited
         password_reuse_max unlimited
         password_lock_time unlimited
         password_grace_time unlimited';
  end if;
end;
/"

    profile_sql="alter user ${clone_user}
  profile ${CLONE_USER_PROFILE}
  container=all;"
  fi

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

${profile_create_sql}

declare
  l_count number;
begin
  select count(*)
    into l_count
    from cdb_users
   where username = upper('${clone_user}')
     and con_id = 1;

  if l_count = 0 then
    execute immediate
      'create user ${clone_user}
         identified by \"${escaped_password}\"
         container=all';
  else
    execute immediate
      'alter user ${clone_user}
         identified by \"${escaped_password}\"
         account unlock
         container=all';
  end if;
end;
/

grant create session,
      create pluggable database
to ${clone_user}
container=all;

${dba_grant_sql}

${profile_sql}

select username,
       account_status,
       common,
       profile
from cdb_users
where username = upper('${clone_user}')
  and con_id = 1;

select profile,
       resource_name,
       limit
from dba_profiles
where profile = upper('${CLONE_USER_PROFILE}')
  and resource_type = 'PASSWORD'
order by resource_name;

exit"

  info "Preparing source clone user ${clone_user}..."
  info "Clone user profile: ${CLONE_USER_PROFILE:-DEFAULT}"
  info "Grant DBA       : $GRANT_DBA_TO_CLONE_USER"

  run_remote_source_sql "$sql" ||
    die "Unable to create or update source clone user ${clone_user}."

  SOURCE_DB_USER="$clone_user"
  ok "Source clone user is ready: ${clone_user}"
}

# -----------------------------------------------------------------------------
# create_database_link
# -----------------------------------------------------------------------------
create_database_link() {
  local dblink="$1"
  local service="${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}"
  local scan_host="${SOURCE_DB_SCAN%%,*}"
  local escaped_password
  local sql

  require_source_db
  require_source_scan

  if [[ "$SOURCE_DB_PORT_SUPPLIED" != "true" ]]; then
    read -r -p "Enter source listener port [1521]: " SOURCE_DB_PORT
    SOURCE_DB_PORT="${SOURCE_DB_PORT:-1521}"
  fi
  validate_source_port

  if [[ -z "$SOURCE_DB_SERVICE" ]]; then
    read -r -p "Enter source service name [${SOURCE_DB_UNIQUE_NAME}]: " SOURCE_DB_SERVICE
    SOURCE_DB_SERVICE="${SOURCE_DB_SERVICE:-$SOURCE_DB_UNIQUE_NAME}"
  fi
  service="$SOURCE_DB_SERVICE"

  [[ -n "$SOURCE_DB_USER" ]] || SOURCE_DB_USER="C##REMOTE_CLONE_USER"

  prepare_source_clone_user

  [[ -n "$service" ]] || die "Source service is required."

  escaped_password="$(printf '%s' "$SOURCE_SYS_PASSWORD" | sed 's/"/""/g')"

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;
create database link ${dblink}
  connect to ${SOURCE_DB_USER}
  identified by \"${escaped_password}\"
  using '(DESCRIPTION=
    (ADDRESS=(PROTOCOL=TCP)
      (HOST=${scan_host})
      (PORT=${SOURCE_DB_PORT}))
    (CONNECT_DATA=
      (SERVER=DEDICATED)
      (SERVICE_NAME=${service})))';
exit"

  info "Creating database link $dblink..."
  run_local_sql "$sql" || die "Unable to create database link $dblink."
  AUTO_DBLINK_CREATED="true"
  ok "Database link created: $dblink"
}

# -----------------------------------------------------------------------------
# validate_database_link
# -----------------------------------------------------------------------------
validate_database_link() {
  local dblink="$1"
  local sql

  sql="whenever sqlerror exit sql.sqlcode
set lines 300 pages 1000
alter session set container=CDB\$ROOT;
alter session set global_names=false;
select name remote_database from v\$database@${dblink};
select name, open_mode from v\$pdbs@${dblink} order by con_id;
exit"

  info "Validating database link $dblink..."
  run_local_sql "$sql" || die "Database link validation failed: $dblink"
  ok "Database link validation succeeded: $dblink"
  info "Database link user: $SOURCE_DB_USER"
}

# -----------------------------------------------------------------------------
# ensure_database_link
# -----------------------------------------------------------------------------
ensure_database_link() {
  local count

  require_source_db

  if [[ -z "$REFRESH_DBLINK" ]]; then
    REFRESH_DBLINK="$(generate_default_dblink_name)"
    info "Generated database link name: $REFRESH_DBLINK"
  fi

  validate_dblink_name "$REFRESH_DBLINK"

  count="$(database_link_exists "$REFRESH_DBLINK")"
  count="${count:-0}"

  if [[ "$count" =~ ^[0-9]+$ ]] && (( count > 0 )); then
    info "Reusing existing database link: $REFRESH_DBLINK"
  else
    create_database_link "$REFRESH_DBLINK"
  fi

  validate_database_link "$REFRESH_DBLINK"
}

# -----------------------------------------------------------------------------
# drop_database_link_if_requested
# -----------------------------------------------------------------------------
drop_database_link_if_requested() {
  local sql

  [[ "$DROP_AUTO_DBLINK" == "true" ]] || return 0

  if [[ "$AUTO_DBLINK_CREATED" != "true" ]]; then
    warn "Database link was not created by this run; it will not be dropped."
    return 0
  fi

  sql="whenever sqlerror exit sql.sqlcode
alter session set container=CDB\$ROOT;
drop database link ${REFRESH_DBLINK};
exit"

  info "Dropping auto-created database link $REFRESH_DBLINK..."
  run_local_sql "$sql" || die "Unable to drop database link $REFRESH_DBLINK."
  ok "Database link dropped: $REFRESH_DBLINK"
}

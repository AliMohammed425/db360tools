#!/usr/bin/env bash
# LTMdbMigration360 module: lib_dispatch.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.


action_resume_workflow() {
  local run_id="${RESUME_RUN_ID:-}"
  [[ -n "$run_id" ]] || run_id="$(checkpoint_latest_run)"
  [[ -n "$run_id" ]] || die "No checkpoint is available."

  local state_file workflow db last_step next_step
  state_file="$(checkpoint_state_file "$run_id")"
  workflow="$(checkpoint_get WORKFLOW "$state_file")"
  db="$(checkpoint_get DATABASE "$state_file")"
  last_step="$(checkpoint_get LAST_SUCCESSFUL_STEP "$state_file")"
  next_step=$(( ${last_step:-0} + 1 ))

  [[ "$workflow" == "subscription_migration" ]] ||
    die "Unsupported workflow in checkpoint: $workflow"

  RUN_ID="$run_id"
  subscription_run_workflow_steps "$db" "$next_step"
}

action_generate_migration_report() {
  generate_migration_report "${REPORT_RUN_ID:-}"
}

action_parallel_health() {
  local -a databases=()
  mapfile -t databases < <(migration_ini_databases "$DEFAULT_MIGRATION_INI")
  [[ ${#databases[@]} -gt 0 ]] || die "No active databases found."
  parallel_execute "database_health" parallel_health_worker "${databases[@]}"
}

# -----------------------------------------------------------------------------
# dispatch_action
# -----------------------------------------------------------------------------
dispatch_action() {
  case "$ACTION" in
    create_cdb)          action_create_local_cdb ;;
    create)              action_create_pdb ;;
    encryption_status)   action_encryption_status ;;
    encrypt_tablespaces) action_encrypt_tablespaces ;;
    datapatch)            action_datapatch ;;
    pdb_datapatch)        action_pdb_datapatch ;;
    compile_utlrp)         action_compile_utlrp ;;
    fix_pdb_violations)   action_fix_pdb_violations ;;
    locate_datapatch)      action_locate_datapatch ;;
    resume_workflow)       action_resume_workflow ;;
    generate_migration_report) action_generate_migration_report ;;
    parallel_health)       action_parallel_health ;;
    create_tablespace)     action_create_tablespace ;;
    tablespace_report)     action_tablespace_report ;;
    local_clone)  action_local_clone_pdb ;;
    remote_clone) action_remote_clone_pdb ;;
    refreshable_create) action_refreshable_create ;;
    refreshable_refresh) action_refreshable_refresh ;;
    refreshable_switchover) action_refreshable_switchover ;;
    refreshable_status) action_refreshable_status ;;
    snapshot_test_enable) action_snapshot_test_enable ;;
    snapshot_test_disable) action_snapshot_test_disable ;;
    refreshable_convert_rw) action_refreshable_convert_rw ;;
    list_cdbs) action_list_cdbs ;;
    list_pdbs) action_list_pdbs ;;
    info)      action_pdb_info ;;
    open)      action_open_pdb ;;
    close)     action_close_pdb ;;
    drop)      action_drop_pdb ;;
    rename)    action_rename_pdb ;;
    *)         die "Unsupported action: $ACTION" ;;
  esac
}

# -----------------------------------------------------------------------------
# main
# -----------------------------------------------------------------------------
main() {
  # No arguments or --menu starts the user-friendly interactive interface.
  if [[ $# -eq 0 || "${1:-}" == "--menu" ]]; then
    interactive_menu
    return 0
  fi

  # Any supplied action/options use non-interactive CLI mode.
  validate_cli_option_map
  parse_arguments "$@"

  initialize_logging
  warn_if_obsolete_script_name
  validate_environment
  print_banner
  dispatch_action
}

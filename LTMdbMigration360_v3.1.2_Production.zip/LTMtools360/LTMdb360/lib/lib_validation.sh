#!/usr/bin/env bash
# LTMdbMigration360 module: lib_validation.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# write_summary
# -----------------------------------------------------------------------------
write_summary() {
  {
    printf 'Script Version : %s\n' "$SCRIPT_VERSION"
    printf 'Action         : %s\n' "$ACTION"
    printf 'CDB            : %s\n' "${CDB_NAME:-N/A}"
    printf 'Created        : %s\n' "${CREATED_PDBS[*]:-None}"
    printf 'Skipped        : %s\n' "${SKIPPED_PDBS[*]:-None}"
    printf 'Failed         : %s\n' "${FAILED_PDBS[*]:-None}"
    printf 'Master Log     : %s\n' "$MASTER_LOG"
  } | tee "$SUMMARY_LOG"
}

# -----------------------------------------------------------------------------
# oracle_home_is_valid
# -----------------------------------------------------------------------------


#!/usr/bin/env bash
# LTMdbMigration360 tablespace lifecycle and reporting module.

validate_tablespace_integer() {
  local value="$1" label="$2"
  [[ "$value" =~ ^[1-9][0-9]*$ ]] || die "$label must be a positive integer in MB."
}

validate_tablespace_type() {
  TABLESPACE_TYPE="$(printf '%s' "$TABLESPACE_TYPE" | tr '[:lower:]' '[:upper:]')"
  case "$TABLESPACE_TYPE" in PERMANENT|TEMPORARY) ;; *) die "Use PERMANENT or TEMPORARY." ;; esac
}

resolve_tablespace_container() {
  local requested="${1:-}"
  if [[ -z "$requested" || "${requested^^}" == 'CDB$ROOT' || "${requested^^}" == 'ROOT' ]]; then
    printf 'CDB$ROOT'
  else
    resolve_existing_pdb_sql "$requested" || die "PDB $requested was not found in CDB $CDB_NAME."
  fi
}

action_create_tablespace() {
  local container ts auto_clause max_clause file_clause encrypt_clause bigfile sql
  require_cdb
  validate_cdb_exists
  resolve_local_oracle_environment
  [[ -n "$TABLESPACE_NAME" ]] || die "Tablespace name is required. Use --tablespace-name."
  ts="$(normalize_name "$TABLESPACE_NAME")"
  validate_oracle_name "$ts" "tablespace name"
  validate_tablespace_type
  validate_tablespace_integer "$TABLESPACE_SIZE_MB" "Initial size"
  validate_tablespace_integer "$TABLESPACE_NEXT_MB" "Autoextend NEXT"
  container="$(resolve_tablespace_container "${PDB_LIST:-}")"
  max_clause="${TABLESPACE_MAXSIZE_MB^^}"
  [[ "$max_clause" == UNLIMITED ]] || validate_tablespace_integer "$max_clause" "MAXSIZE"
  if [[ "$TABLESPACE_AUTOEXTEND" == true ]]; then
    auto_clause="AUTOEXTEND ON NEXT ${TABLESPACE_NEXT_MB}M MAXSIZE ${max_clause}"
  else
    auto_clause="AUTOEXTEND OFF"
  fi
  if [[ -n "$TABLESPACE_FILE_DEST" ]]; then
    file_clause="'${TABLESPACE_FILE_DEST%/}/${ts,,}01.dbf' SIZE ${TABLESPACE_SIZE_MB}M ${auto_clause}"
  else
    file_clause="SIZE ${TABLESPACE_SIZE_MB}M ${auto_clause}"
  fi
  if [[ "$TABLESPACE_TYPE" == TEMPORARY ]]; then
    sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=${container};
create temporary tablespace ${ts} tempfile ${file_clause} extent management local uniform size 1M;
select tablespace_name, contents, status, block_size, bigfile, encrypted from dba_tablespaces where tablespace_name='${ts}';
exit"
  else
    bigfile=""; [[ "$TABLESPACE_BIGFILE" == true ]] && bigfile="bigfile "
    encrypt_clause=""
    if [[ "$TABLESPACE_ENCRYPT" == true ]]; then
      ENCRYPTION_ALGORITHM="$TABLESPACE_ALGORITHM"
      validate_encryption_algorithm
      validate_target_keystore
      encrypt_clause="ENCRYPTION ONLINE USING '${TABLESPACE_ALGORITHM}' ENCRYPT"
    fi
    sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=${container};
create ${bigfile}tablespace ${ts} datafile ${file_clause} ${encrypt_clause} extent management local segment space management auto;
select tablespace_name, contents, status, block_size, bigfile, encrypted from dba_tablespaces where tablespace_name='${ts}';
exit"
  fi
  cat <<PLAN

Create Tablespace Plan
----------------------
CDB              : $CDB_NAME
Container        : $container
Tablespace       : $ts
Type             : $TABLESPACE_TYPE
Size MB          : $TABLESPACE_SIZE_MB
Autoextend       : $TABLESPACE_AUTOEXTEND
Next MB          : $TABLESPACE_NEXT_MB
Max Size         : $TABLESPACE_MAXSIZE_MB
Bigfile          : $TABLESPACE_BIGFILE
Encrypted        : $TABLESPACE_ENCRYPT
Algorithm        : $TABLESPACE_ALGORITHM
File Destination : ${TABLESPACE_FILE_DEST:-DB_CREATE_FILE_DEST/OMF}
Execution        : $([[ "$TEST_MODE" == true ]] && echo DRY-RUN || echo LIVE)
PLAN
  confirm_action "Create tablespace $ts in $container?"
  run_local_sql "$sql" || die "Unable to create tablespace $ts."
  ok "Tablespace $ts created successfully in $container."
}

action_tablespace_report() {
  local filter='ALL' sql report rc
  require_cdb
  validate_cdb_exists
  resolve_local_oracle_environment
  [[ -n "${PDB_LIST:-}" ]] && filter="$(resolve_tablespace_container "$PDB_LIST")"
  sql="whenever sqlerror exit sql.sqlcode
set lines 350 pages 1000 trimspool on
col container_name for a20
col tablespace_name for a30
col file_name for a100
col contents for a12
col status for a10
col encrypted for a10
col bigfile for a8
alter session set container=CDB\\$ROOT;
prompt === TABLESPACE PROPERTIES ===
select c.name container_name,t.tablespace_name,t.contents,t.status,t.block_size,t.bigfile,t.encrypted,t.extent_management,t.allocation_type,t.segment_space_management from cdb_tablespaces t join v\\$containers c on c.con_id=t.con_id where ('${filter}'='ALL' or c.name='${filter}') order by c.name,t.tablespace_name;
prompt === DATAFILES ===
select c.name container_name,d.tablespace_name,d.file_id,d.file_name,round(d.bytes/1024/1024,2) total_mb,d.autoextensible,round(d.maxbytes/1024/1024,2) max_mb,d.status from cdb_data_files d join v\\$containers c on c.con_id=d.con_id where ('${filter}'='ALL' or c.name='${filter}') order by c.name,d.tablespace_name,d.file_id;
prompt === TEMPFILES ===
select c.name container_name,t.tablespace_name,t.file_id,t.file_name,round(t.bytes/1024/1024,2) total_mb,t.autoextensible,round(t.maxbytes/1024/1024,2) max_mb,t.status from cdb_temp_files t join v\\$containers c on c.con_id=t.con_id where ('${filter}'='ALL' or c.name='${filter}') order by c.name,t.tablespace_name,t.file_id;
prompt === CAPACITY ===
with d as (select con_id,tablespace_name,sum(bytes) bytes from cdb_data_files group by con_id,tablespace_name),f as (select con_id,tablespace_name,sum(bytes) bytes from cdb_free_space group by con_id,tablespace_name) select c.name container_name,d.tablespace_name,round(d.bytes/1024/1024,2) total_mb,round((d.bytes-nvl(f.bytes,0))/1024/1024,2) used_mb,round(nvl(f.bytes,0)/1024/1024,2) free_mb,round((d.bytes-nvl(f.bytes,0))*100/d.bytes,2) used_pct from d join v\\$containers c on c.con_id=d.con_id left join f on f.con_id=d.con_id and f.tablespace_name=d.tablespace_name where ('${filter}'='ALL' or c.name='${filter}') order by c.name,d.tablespace_name;
exit"
  mkdir -p "$PROJECT_REPORT_DIR"
  report="$PROJECT_REPORT_DIR/tablespace_inventory_${CDB_NAME}_${filter//\\$/_}_$(date +%Y%m%d_%H%M%S).log"
  info "Generating tablespace inventory report: $report"
  if [[ "$TEST_MODE" == true ]]; then printf '%s\n' "$sql"; return 0; fi
  set +e
  run_local_sql "$sql" | tee "$report"; rc=${PIPESTATUS[0]}
  set -e
  (( rc == 0 )) || die "Tablespace inventory report failed."
  ok "Tablespace inventory report created: $report"
}

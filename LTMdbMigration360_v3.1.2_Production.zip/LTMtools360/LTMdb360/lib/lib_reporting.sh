#!/usr/bin/env bash
# LTMdbMigration360 v3.1 HTML/JSON/CSV reporting module.

html_escape() {
  sed \
    -e 's/&/\&amp;/g' \
    -e 's/</\&lt;/g' \
    -e 's/>/\&gt;/g' \
    -e 's/"/\&quot;/g'
}

report_find_state() {
  local run_id="${1:-}"
  if [[ -z "$run_id" ]]; then
    run_id="$(checkpoint_latest_run)"
  fi
  [[ -n "$run_id" ]] || die "No workflow checkpoint is available."
  local state_file
  state_file="$(checkpoint_state_file "$run_id")"
  [[ -r "$state_file" ]] || die "Checkpoint file not found: $state_file"
  printf '%s' "$state_file"
}

json_escape() {
  sed \
    -e 's/\/\\/g' \
    -e 's/"/\"/g' \
    -e 's/	/\t/g' \
    -e 's//\r/g' \
    -e 's/$/\n/' |
    tr -d '
' |
    sed 's/\n$//'
}

generate_json_report() {
  local state_file="$1"
  local output="$2"
  local key=""
  local value=""
  local first="true"

  {
    printf '{
'
    while IFS='=' read -r key value; do
      [[ -n "$key" ]] || continue
      if [[ "$first" == "true" ]]; then
        first="false"
      else
        printf ',
'
      fi
      printf '  "%s": "%s"' \
        "$(printf '%s' "$key" | json_escape)" \
        "$(printf '%s' "$value" | json_escape)"
    done < "$state_file"
    printf '
}
'
  } > "$output"
}

generate_csv_report() {
  local state_file="$1"
  local output="$2"
  {
    printf 'key,value\n'
    while IFS='=' read -r key value; do
      printf '"%s","%s"\n' \
        "${key//\"/\"\"}" "${value//\"/\"\"}"
    done < "$state_file"
  } > "$output"
}

generate_html_report() {
  local state_file="$1"
  local output="$2"
  local run_id status workflow database started completed updated step

  run_id="$(checkpoint_get RUN_ID "$state_file")"
  status="$(checkpoint_get STATUS "$state_file")"
  workflow="$(checkpoint_get WORKFLOW "$state_file")"
  database="$(checkpoint_get DATABASE "$state_file")"
  started="$(checkpoint_get STARTED_AT "$state_file")"
  completed="$(checkpoint_get COMPLETED_AT "$state_file" || true)"
  updated="$(checkpoint_get UPDATED_AT "$state_file" || true)"
  step="$(checkpoint_get LAST_SUCCESSFUL_STEP "$state_file" || true)"

  cat > "$output" <<EOF
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>LTMdbMigration360 Migration Report</title>
<style>
body{font-family:Arial,sans-serif;margin:32px;color:#222}
h1{border-bottom:2px solid #444;padding-bottom:8px}
table{border-collapse:collapse;width:100%;max-width:900px}
th,td{border:1px solid #bbb;padding:8px;text-align:left}
th{background:#eee;width:260px}
pre{background:#f5f5f5;padding:16px;overflow:auto}
.success{font-weight:bold}.failed{font-weight:bold}
</style>
</head>
<body>
<h1>LTMdbMigration360 Migration Summary</h1>
<table>
<tr><th>Run ID</th><td>$(printf '%s' "$run_id" | html_escape)</td></tr>
<tr><th>Workflow</th><td>$(printf '%s' "$workflow" | html_escape)</td></tr>
<tr><th>Database</th><td>$(printf '%s' "$database" | html_escape)</td></tr>
<tr><th>Status</th><td>$(printf '%s' "$status" | html_escape)</td></tr>
<tr><th>Last Successful Step</th><td>$(printf '%s' "$step" | html_escape)</td></tr>
<tr><th>Started</th><td>$(printf '%s' "$started" | html_escape)</td></tr>
<tr><th>Updated</th><td>$(printf '%s' "$updated" | html_escape)</td></tr>
<tr><th>Completed</th><td>$(printf '%s' "$completed" | html_escape)</td></tr>
</table>
<h2>Checkpoint Data</h2>
<pre>$(html_escape < "$state_file")</pre>
</body>
</html>
EOF
}

generate_optional_pdf() {
  local html="$1"
  local pdf="$2"
  local rc=0

  if [[ "${LTM_ENABLE_PDF:-false}" != "true" ]]; then
    info "PDF generation is disabled. Set LTM_ENABLE_PDF=true to enable it."
    return 0
  fi

  if command -v wkhtmltopdf >/dev/null 2>&1; then
    set +e
    wkhtmltopdf --quiet "$html" "$pdf"
    rc=$?
    set -e
    if (( rc == 0 )) && [[ -s "$pdf" ]]; then
      return 0
    fi
    warn "wkhtmltopdf failed; HTML/JSON/CSV reports remain available."
    rm -f "$pdf"
    return 0
  fi

  if command -v chromium >/dev/null 2>&1; then
    set +e
    chromium --headless --no-sandbox --disable-gpu \
      --print-to-pdf="$pdf" "file://$html" >/dev/null 2>&1
    rc=$?
    set -e
    if (( rc == 0 )) && [[ -s "$pdf" ]]; then
      return 0
    fi
    warn "Chromium PDF conversion failed; HTML/JSON/CSV reports remain available."
    rm -f "$pdf"
    return 0
  fi

  warn "No PDF converter found; HTML/JSON/CSV reports were generated."
  return 0
}

generate_migration_report() {
  local requested_run_id="${1:-}"
  local state_file run_id output_dir html json_file csv_file pdf

  state_file="$(report_find_state "$requested_run_id")"
  run_id="$(checkpoint_get RUN_ID "$state_file")"
  output_dir="$PROJECT_REPORT_DIR/$(date +%Y%m%d)/$run_id"
  mkdir -p "$output_dir"

  html="$output_dir/migration_summary.html"
  json_file="$output_dir/migration_summary.json"
  csv_file="$output_dir/migration_summary.csv"
  pdf="$output_dir/migration_summary.pdf"

  generate_html_report "$state_file" "$html"
  generate_json_report "$state_file" "$json_file"
  generate_csv_report "$state_file" "$csv_file"
  generate_optional_pdf "$html" "$pdf"

  ok "Migration reports generated under: $output_dir"
  printf 'HTML : %s\nJSON : %s\nCSV  : %s\n' "$html" "$json_file" "$csv_file"
  if [[ -s "$pdf" ]]; then
    printf 'PDF  : %s\n' "$pdf"
  fi
  return 0
}

subscription_generate_migration_report() {
  local run_id=""
  menu_header
  printf 'Generate Migration Summary Report\n\n'
  checkpoint_list
  printf '\n'
  menu_read run_id "Run ID (blank uses latest)" ""
  generate_migration_report "$run_id"
}

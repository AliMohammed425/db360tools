#!/usr/bin/env bash
# LTMdbMigration360 v3.1 checkpoint and resume module.

checkpoint_state_file() {
  local run_id="${1:-$RUN_ID}"
  printf '%s/%s.state' "$PROJECT_STATE_DIR" "$run_id"
}

checkpoint_init() {
  local workflow="$1"
  local database="${2:-ALL}"
  local state_file

  mkdir -p "$PROJECT_STATE_DIR" "$RUN_LOG_DIR" "$RUN_REPORT_DIR"
  WORKFLOW_NAME="$workflow"
  state_file="$(checkpoint_state_file)"

  cat > "$state_file" <<EOF
RUN_ID=$RUN_ID
WORKFLOW=$workflow
DATABASE=$database
STATUS=RUNNING
CURRENT_STEP=0
LAST_SUCCESSFUL_STEP=0
STARTED_AT=$(date '+%Y-%m-%d %H:%M:%S')
UPDATED_AT=$(date '+%Y-%m-%d %H:%M:%S')
EOF

  info "Checkpoint initialized: $state_file"
}

checkpoint_set() {
  local key="$1"
  local value="$2"
  local state_file="${3:-$(checkpoint_state_file)}"
  local tmp_file="${state_file}.tmp"

  [[ -f "$state_file" ]] || die "Checkpoint file not found: $state_file"

  awk -F= -v key="$key" -v value="$value" '
    BEGIN { found=0 }
    $1 == key { print key "=" value; found=1; next }
    { print }
    END { if (!found) print key "=" value }
  ' "$state_file" > "$tmp_file"

  mv "$tmp_file" "$state_file"
}

checkpoint_get() {
  local key="$1"
  local state_file="${2:-$(checkpoint_state_file)}"
  [[ -r "$state_file" ]] || return 1
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$state_file"
}

checkpoint_step_start() {
  local step="$1"
  local description="$2"
  checkpoint_set CURRENT_STEP "$step"
  checkpoint_set CURRENT_DESCRIPTION "$description"
  checkpoint_set STATUS RUNNING
  checkpoint_set UPDATED_AT "$(date '+%Y-%m-%d %H:%M:%S')"
  info "Workflow step $step started: $description"
}

checkpoint_step_success() {
  local step="$1"
  local description="$2"
  checkpoint_set LAST_SUCCESSFUL_STEP "$step"
  checkpoint_set CURRENT_STEP "$step"
  checkpoint_set CURRENT_DESCRIPTION "$description"
  checkpoint_set STATUS RUNNING
  checkpoint_set UPDATED_AT "$(date '+%Y-%m-%d %H:%M:%S')"
  ok "Workflow step $step completed: $description"
}

checkpoint_step_failed() {
  local step="$1"
  local description="$2"
  checkpoint_set CURRENT_STEP "$step"
  checkpoint_set CURRENT_DESCRIPTION "$description"
  checkpoint_set STATUS FAILED
  checkpoint_set FAILED_AT "$(date '+%Y-%m-%d %H:%M:%S')"
  error "Workflow step $step failed: $description"
}

checkpoint_complete() {
  checkpoint_set STATUS SUCCESS
  checkpoint_set COMPLETED_AT "$(date '+%Y-%m-%d %H:%M:%S')"
  ok "Workflow checkpoint marked SUCCESS: $(checkpoint_state_file)"
}

checkpoint_latest_run() {
  find "$PROJECT_STATE_DIR" -maxdepth 1 -type f -name '*.state' \
    -printf '%T@ %f\n' 2>/dev/null |
    sort -nr |
    awk 'NR==1 {sub(/\.state$/, "", $2); print $2}'
}

checkpoint_list() {
  mkdir -p "$PROJECT_STATE_DIR"
  printf '%-24s %-18s %-15s %-8s %-8s %s\n' \
    "RUN_ID" "WORKFLOW" "DATABASE" "STATUS" "STEP" "UPDATED"
  printf '%s\n' '------------------------------------------------------------------------------------------'

  local f
  for f in "$PROJECT_STATE_DIR"/*.state; do
    [[ -f "$f" ]] || continue
    printf '%-24s %-18s %-15s %-8s %-8s %s\n' \
      "$(checkpoint_get RUN_ID "$f")" \
      "$(checkpoint_get WORKFLOW "$f")" \
      "$(checkpoint_get DATABASE "$f")" \
      "$(checkpoint_get STATUS "$f")" \
      "$(checkpoint_get LAST_SUCCESSFUL_STEP "$f")" \
      "$(checkpoint_get UPDATED_AT "$f")"
  done
}

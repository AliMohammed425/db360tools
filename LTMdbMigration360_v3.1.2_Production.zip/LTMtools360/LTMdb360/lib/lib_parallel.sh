#!/usr/bin/env bash
# LTMdbMigration360 v3.1 parallel execution module.

validate_parallel_workers() {
  [[ "$PARALLEL_WORKERS" =~ ^[1-9][0-9]*$ ]] ||
    die "Parallel worker count must be a positive integer."
  (( PARALLEL_WORKERS <= 32 )) ||
    die "Parallel worker count cannot exceed 32."
}

migration_ini_databases() {
  local ini_file="${1:-$DEFAULT_MIGRATION_INI}"

  [[ -r "$ini_file" ]] || die "Migration INI is not readable: $ini_file"

  awk -F'|' '
    BEGIN { IGNORECASE=1 }
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
    NR==1 && tolower($1) ~ /dbname/ { next }
    {
      skip=$22
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", skip)
      if (toupper(skip) != "Y" && toupper(skip) != "YES" && $1 != "") {
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1)
        print $1
      }
    }
  ' "$ini_file"
}

parallel_execute() {
  local job_name="$1"
  local worker_function="$2"
  shift 2
  local -a items=("$@")
  local result_dir="$RUN_LOG_DIR/parallel_${job_name}"
  local item=""
  local running=0
  local failed=0
  local completed=0
  local pid=""

  validate_parallel_workers
  mkdir -p "$result_dir"

  info "Parallel job        : $job_name"
  info "Parallel workers    : $PARALLEL_WORKERS"
  info "Items               : ${#items[@]}"
  info "Result directory    : $result_dir"

  for item in "${items[@]}"; do
    while (( running >= PARALLEL_WORKERS )); do
      if wait -n; then
        ((completed++))
      else
        ((failed++))
      fi
      ((running--))
    done

    (
      "$worker_function" "$item"
    ) >"$result_dir/${item}.log" 2>&1 &
    ((running++))
  done

  while (( running > 0 )); do
    if wait -n; then
      ((completed++))
    else
      ((failed++))
    fi
    ((running--))
  done

  printf 'JOB=%s\nTOTAL=%s\nCOMPLETED=%s\nFAILED=%s\n' \
    "$job_name" "${#items[@]}" "$completed" "$failed" \
    > "$result_dir/summary.env"

  (( failed == 0 )) ||
    die "Parallel job $job_name completed with $failed failure(s)."

  ok "Parallel job $job_name completed successfully."
}

parallel_health_worker() {
  local db="$1"
  local script_path
  script_path="$(subscription_script_path "ltm_db_health.sh")"
  subscription_require_script "$script_path"
  "$script_path" -d "$db"
}

subscription_parallel_health_all() {
  local ini_file="$DEFAULT_MIGRATION_INI"
  local workers="$PARALLEL_WORKERS"
  local -a databases=()

  menu_header
  printf 'Parallel Database Health Check\n\n'
  menu_read ini_file "Migration INI file" "$DEFAULT_MIGRATION_INI"
  menu_read workers "Maximum workers" "$PARALLEL_WORKERS"
  PARALLEL_WORKERS="$workers"

  mapfile -t databases < <(migration_ini_databases "$ini_file")
  [[ ${#databases[@]} -gt 0 ]] || {
    printf 'No active databases found in %s\n' "$ini_file"
    return 1
  }

  parallel_execute "database_health" parallel_health_worker "${databases[@]}"
}

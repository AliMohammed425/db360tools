#!/usr/bin/env bash
# LTMdbMigration360 module: lib_snapshot.sh
# Sourced by bin/ltm_db_migration.sh; do not execute directly.

# -----------------------------------------------------------------------------
# action_snapshot_test_enable
# -----------------------------------------------------------------------------
action_snapshot_test_enable() {
  local refresh_pdb
  local test_pdb
  local snapshot_sql
  local full_clone_sql
  local snapshot_output=""
  local snapshot_rc=0
  local escaped_keystore_password=""
  local create_file_dest_clause=""
  local actual_clone_type=""

  require_cdb
  require_single_pdb
  validate_cdb_exists

  case "$SNAPSHOT_TEST_MODE" in
    AUTO|SNAPSHOT|FULL) ;;
    *)
      die "Invalid snapshot mode: $SNAPSHOT_TEST_MODE. Use auto, snapshot, or full."
      ;;
  esac

  [[ -n "$TARGET_PDB_NAME" ]] ||
    die "Writable test PDB name is required with -t."

  refresh_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "Refreshable PDB $PDB_LIST was not found in CDB $CDB_NAME using v\$pdbs."

  test_pdb="$(normalize_name "$TARGET_PDB_NAME")"
  validate_oracle_name "$test_pdb" "test PDB name"

  if resolve_existing_pdb_sql "$test_pdb" >/dev/null 2>&1; then
    die "Test PDB $test_pdb already exists in CDB $CDB_NAME."
  fi

  if [[ -z "$TARGET_KEYSTORE_PASSWORD" ]]; then
    read -r -s -p "Enter target CDB keystore password: " TARGET_KEYSTORE_PASSWORD
    printf '\n'
  fi

  [[ -n "$TARGET_KEYSTORE_PASSWORD" ]] ||
    die "Target CDB keystore password is required. Supply -K PASSWORD."

  escaped_keystore_password="${TARGET_KEYSTORE_PASSWORD//\"/\"\"}"

  if [[ -n "$SNAPSHOT_CREATE_FILE_DEST" ]]; then
    create_file_dest_clause="create_file_dest='${SNAPSHOT_CREATE_FILE_DEST}'"
  fi

  create_file_dest_clause="${create_file_dest_clause:+${create_file_dest_clause} }"

  snapshot_sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

declare
  l_open_mode v\$pdbs.open_mode%type;
begin
  select open_mode
    into l_open_mode
    from v\$pdbs
   where name='${refresh_pdb}';

  if l_open_mode = 'MOUNTED' then
    execute immediate
      'alter pluggable database ${refresh_pdb} open read only instances=all';
  elsif l_open_mode <> 'READ ONLY' then
    raise_application_error(
      -20001,
      'Refreshable PDB ${refresh_pdb} must be MOUNTED or READ ONLY. Current mode=' ||
      l_open_mode
    );
  end if;
end;
/

create pluggable database ${test_pdb} from ${refresh_pdb} ${create_file_dest_clause} snapshot copy keystore identified by \"${escaped_keystore_password}\";

alter pluggable database ${test_pdb}
  open read write instances=all;

alter pluggable database ${test_pdb}
  save state instances=all;

exit"

  full_clone_sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

declare
  l_open_mode v\$pdbs.open_mode%type;
begin
  select open_mode
    into l_open_mode
    from v\$pdbs
   where name='${refresh_pdb}';

  if l_open_mode = 'MOUNTED' then
    execute immediate
      'alter pluggable database ${refresh_pdb} open read only instances=all';
  end if;
end;
/

create pluggable database ${test_pdb} from ${refresh_pdb} keystore identified by \"${escaped_keystore_password}\";

alter pluggable database ${test_pdb}
  open read write instances=all;

alter pluggable database ${test_pdb}
  save state instances=all;

exit"

  cat <<PLAN

Writable Test PDB Plan
----------------------
Target CDB       : $CDB_NAME
Source PDB       : $refresh_pdb
Test PDB         : $test_pdb
Requested Mode   : $SNAPSHOT_TEST_MODE
Snapshot Dest    : ${SNAPSHOT_CREATE_FILE_DEST:-DATABASE DEFAULT}
Keystore Password: SUPPLIED VIA -K
Execution        : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Create writable test PDB $test_pdb?"

  if [[ "$SNAPSHOT_TEST_MODE" == "FULL" ]]; then
    info "Creating full writable PDB clone..."
    run_local_sql "$full_clone_sql" ||
      die "Unable to create full writable test PDB $test_pdb."
    actual_clone_type="FULL COPY"

  else
    info "Attempting sparse snapshot-copy PDB..."

    set +e
    snapshot_output="$(run_local_sql "$snapshot_sql" 2>&1)"
    snapshot_rc=$?
    set -e

    printf '%s\n' "$snapshot_output"

    if (( snapshot_rc == 0 )); then
      actual_clone_type="SNAPSHOT COPY"
    elif printf '%s\n' "$snapshot_output" |
           grep -Eq 'ORA-17527|not a sparse disk group'; then

      if [[ "$SNAPSHOT_TEST_MODE" == "SNAPSHOT" ]]; then
        die "Snapshot mode was forced, but destination ${SNAPSHOT_CREATE_FILE_DEST:-DATABASE DEFAULT} is not a sparse disk group."
      fi

      warn "Snapshot copy is not supported on the selected ASM disk group."
      warn "Falling back to a full writable PDB clone."

      # Remove any incomplete metadata entry before retrying.
      run_local_sql "whenever sqlerror continue
alter session set container=CDB\$ROOT;
alter pluggable database ${test_pdb} close immediate instances=all;
drop pluggable database ${test_pdb} including datafiles;
exit" >/dev/null 2>&1 || true

      run_local_sql "$full_clone_sql" ||
        die "Snapshot copy failed and full clone fallback also failed for $test_pdb."

      actual_clone_type="FULL COPY FALLBACK"
    else
      die "Unable to create writable test PDB $test_pdb. Snapshot creation failed for a reason other than sparse-storage support."
    fi
  fi

  ok "Writable test PDB created: $test_pdb"
  info "Clone Type: $actual_clone_type"
  info "Open Mode : READ WRITE"
  warn "Run --snapshot-test-disable -c $CDB_NAME -p $refresh_pdb -t $test_pdb before the next refresh."
}

# -----------------------------------------------------------------------------
# action_snapshot_test_disable
# -----------------------------------------------------------------------------
action_snapshot_test_disable() {
  local refresh_pdb
  local test_pdb
  local sql

  require_cdb
  require_single_pdb
  validate_cdb_exists

  [[ -n "$TARGET_PDB_NAME" ]] ||
    die "Snapshot test PDB name is required with -t."

  refresh_pdb="$(resolve_existing_pdb_sql "$PDB_LIST")" ||
    die "Refreshable PDB $PDB_LIST was not found in CDB $CDB_NAME using v\$pdbs."

  test_pdb="$(resolve_existing_pdb_sql "$TARGET_PDB_NAME")" ||
    die "Snapshot test PDB $TARGET_PDB_NAME was not found in CDB $CDB_NAME."

  [[ "$refresh_pdb" != "$test_pdb" ]] ||
    die "Refreshable PDB and snapshot test PDB cannot be the same."

  sql="whenever sqlerror exit sql.sqlcode
set echo on timing on
alter session set container=CDB\$ROOT;

alter pluggable database ${test_pdb}
  close immediate instances=all;

drop pluggable database ${test_pdb}
  including datafiles;

declare
  l_open_mode v\$pdbs.open_mode%type;
begin
  select open_mode
    into l_open_mode
    from v\$pdbs
   where name='${refresh_pdb}';

  if l_open_mode <> 'MOUNTED' then
    execute immediate
      'alter pluggable database ${refresh_pdb} close immediate instances=all';
  end if;
end;
/

alter pluggable database ${refresh_pdb} refresh;

select p.pdb_name,
       p.status,
       p.refresh_mode,
       v.open_mode
from dba_pdbs p
join v\$pdbs v
  on v.name=p.pdb_name
where p.pdb_name='${refresh_pdb}';

exit"

  cat <<PLAN

Disable Snapshot Test and Refresh Plan
--------------------------------------
Target CDB       : $CDB_NAME
Refreshable PDB  : $refresh_pdb
Snapshot Test PDB: $test_pdb
Action 1         : CLOSE and DROP snapshot test PDB
Action 2         : MOUNT refreshable PDB
Action 3         : REFRESH refreshable PDB
Execution        : $([[ "$TEST_MODE" == "true" ]] && echo "DRY RUN" || echo "LIVE")
PLAN

  confirm_action "Drop snapshot test PDB $test_pdb and refresh $refresh_pdb?"
  run_local_sql "$sql" ||
    die "Unable to disable snapshot testing and refresh $refresh_pdb."

  ok "Snapshot test PDB dropped: $test_pdb"
  ok "Refresh completed: $refresh_pdb"
}

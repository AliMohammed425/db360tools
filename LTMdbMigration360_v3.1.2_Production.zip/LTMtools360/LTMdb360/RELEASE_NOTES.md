# LTMdbMigration360 v3.1.2 Release Notes

Released: 2026-08-05

## Added

- Create permanent or temporary tablespaces in CDB root or a selected PDB.
- Report encryption, block size, status, BIGFILE, datafiles, tempfiles, autoextend, capacity, free space, and utilization.

# LTMdbMigration360 v3.1.1 Release Notes

Released: 2026-08-05

## Fixed

- Fixed `ORACLE_HOME_RESOLVED: unbound variable` during local CDB creation.
- CDB creation now uses the validated local `oracle_home` value in the
  DBaaSCLI `--oracleHome` argument.
- Synchronizes `TARGET_ORACLE_HOME` and `ORACLE_HOME_RESOLVED` after resolving
  the creation Oracle Home.
- Initializes resolved Oracle environment variables for safe `set -u` behavior.
- Added a CDB Oracle Home regression test.

## Previous v3.1 features


Released: 2026-08-04

## New in v3.1

- Parallel database health execution with configurable worker limits.
- Persistent workflow checkpoints under `state/`.
- Resume interrupted Subscription-to-Subscription migrations.
- Structured reports in HTML, JSON, and CSV.
- Optional PDF conversion when `LTM_ENABLE_PDF=true` and `wkhtmltopdf` or Chromium is installed.
- Run-specific log and report directories.
- Developer and release utilities moved to `tools/`.
- Unit-test framework under `tests/`.

#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_ROOT="${1:-/home/opc/LTMtools360/LTMdb360}"
OWNER="${2:-opc}"
GROUP="${3:-oinstall}"
STAMP="$(date +%Y%m%d_%H%M%S)"

echo "Installing LTMdbMigration360 Enterprise v2.0.0"
echo "Source : $SOURCE_ROOT"
echo "Target : $TARGET_ROOT"

if [[ -d "$TARGET_ROOT" ]]; then
  cp -a "$TARGET_ROOT" "${TARGET_ROOT}.backup_${STAMP}"
  echo "Backup : ${TARGET_ROOT}.backup_${STAMP}"
fi

mkdir -p "$(dirname "$TARGET_ROOT")"
rm -rf "$TARGET_ROOT"
cp -a "$SOURCE_ROOT" "$TARGET_ROOT"

find "$TARGET_ROOT/bin" -type f -name '*.sh' -exec chmod 700 {} +
find "$TARGET_ROOT/lib" -type f -name '*.sh' -exec chmod 600 {} +
find "$TARGET_ROOT/tools" -type f -name '*.sh' -exec chmod 700 {} +
find "$TARGET_ROOT/tests" -type f -name '*.sh' -exec chmod 700 {} +
find "$TARGET_ROOT/config" -type f -exec chmod 600 {} +

if id "$OWNER" >/dev/null 2>&1; then
  chown -R "$OWNER:$GROUP" "$TARGET_ROOT"
fi

echo
"$TARGET_ROOT/bin/ltm_db_migration.sh" -v
bash -n "$TARGET_ROOT/bin/ltm_db_migration.sh"

echo
echo "Installation completed."
echo "Run: $TARGET_ROOT/bin/ltm_db_migration.sh"

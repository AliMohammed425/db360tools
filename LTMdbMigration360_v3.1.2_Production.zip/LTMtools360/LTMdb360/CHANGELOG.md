# Changelog

## 3.1.2 — 2026-08-05

- Added permanent and temporary tablespace creation.
- Added complete tablespace inventory reporting.
- Added Create / Manage options 9 and 10.
- Added CLI and regression tests.


## 3.1.1 — 2026-08-05

- Fixed unbound `ORACLE_HOME_RESOLVED` in `lib_cdb_create.sh`.
- Changed DBaaSCLI CDB creation to use the validated local Oracle Home.
- Added safe global Oracle environment initialization.
- Added `test_cdb_oracle_home.sh`.


## 3.1.0 — 2026-08-04

- Added parallel execution engine.
- Added persistent checkpoints and workflow resume.
- Added HTML, JSON, CSV, and optional PDF reports.
- Added tools and test directories.
- Moved module validation to `tools/`.
- Preserved all v2.1 migration, clone, Data Guard, encryption, and patching functions.


## 2.1.0 — 2026-08-04

- Refactored the monolithic migration script into 18 focused library modules.
- Reduced the primary entry point to configuration, module loading, and dispatch.
- Added module reference and developer maintenance documentation.
- Added duplicate-function, syntax, version, and help validation.
- Preserved all CLI actions, menus, Data Guard workflows, Datapatch,
  encryption, remediation, and Subscription-to-Subscription functionality.


## 2.0.0 — 2026-08-04

- Consolidated all production migration and lifecycle scripts.
- Preserved the full Subscription-to-Subscription migration menu.
- Included CDB/PDB management, clone, refresh, cutover, encryption, Datapatch,
  UTLRP, health validation, post-clone remediation, Data Guard, reporting,
  installation, and compatibility wrapper functions.
- Added Oracle-user-aware Datapatch discovery.
- Included SYSTEM and SYSAUX in permanent PDB tablespace encryption by default.
- Standardized installation path as `/home/opc/LTMtools360/LTMdb360`.

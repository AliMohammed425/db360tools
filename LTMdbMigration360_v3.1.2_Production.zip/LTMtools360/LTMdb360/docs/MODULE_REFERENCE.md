# LTMdbMigration360 Module Reference

The production entry point is `bin/ltm_db_migration.sh`. It loads the following functional modules.

## `lib_args.sh`

- `parse_long_options()`
- `parse_arguments()`
- `set_action()`

## `lib_cdb_create.sh`

- `oracle_home_is_valid()`
- `resolve_creation_oracle_home()`
- `detect_cdb_creation_engine()`
- `run_create_command()`
- `run_dbaascli_create_with_passwords()`
- `detect_cluster_nodes()`
- `resolve_rac_mode()`
- `resolve_dbca_template()`
- `extract_resume_session_id()`
- `action_create_local_cdb()`

## `lib_clone.sh`

- `action_local_clone_pdb()`
- `action_remote_clone_pdb()`
- `validate_post_clone_algorithm()`
- `post_clone_open_pdb()`
- `post_clone_review_violations()`
- `post_clone_run_datapatch()`
- `post_clone_encrypt_tablespaces()`
- `post_clone_validate_all()`
- `post_clone_assert_clean_state()`
- `post_clone_report_rac_warning()`

## `lib_common.sh`

- `timestamp()`
- `log()`
- `info()`
- `ok()`
- `warn()`
- `error()`
- `die()`
- `normalize_name()`
- `validate_oracle_name()`
- `initialize_logging()`
- `validate_environment()`
- `execute_or_display()`
- `execute_with_password_stdin()`
- `print_banner()`
- `prompt_required()`
- `confirm_action()`
- `warn_if_obsolete_script_name()`
- `validate_cli_option_map()`
- `escape_sql_double_quoted_value()`

## `lib_datapatch.sh`

- `validate_invalid_objects()`
- `compile_utlrp_pdb()`
- `datapatch_review_violations()`
- `resolve_datapatch_command()`
- `datapatch_run_passes()`
- `datapatch_bounce_pdb()`
- `datapatch_verify_sql_inventory()`
- `datapatch_verify_block_sizes()`
- `action_datapatch()`
- `action_pdb_datapatch()`
- `action_compile_utlrp()`
- `action_locate_datapatch()`

## `lib_dispatch.sh`

- `dispatch_action()`
- `main()`

## `lib_encryption.sh`

- `require_target_keystore_password()`
- `validate_target_keystore()`
- `validate_encryption_algorithm()`
- `action_encryption_status()`
- `action_encrypt_tablespaces()`

## `lib_help.sh`

- `usage()`
- `show_detailed_help()`

## `lib_menus.sh`

- `menu_pause()`
- `menu_header()`
- `menu_read()`
- `menu_secret()`
- `menu_confirm_run()`
- `menu_create_cdb()`
- `menu_create_pdb()`
- `menu_list_cdbs()`
- `menu_list_pdbs()`
- `menu_pdb_info()`
- `menu_open_pdb()`
- `menu_close_pdb()`
- `menu_drop_pdb()`
- `menu_rename_pdb()`
- `menu_local_clone()`
- `menu_remote_clone()`
- `menu_refreshable_create()`
- `menu_manual_refresh()`
- `menu_refresh_status()`
- `menu_final_cutover()`
- `menu_snapshot_enable()`
- `menu_snapshot_disable()`
- `menu_encryption_status()`
- `menu_encrypt_tablespaces()`
- `menu_subscription_migration()`
- `menu_create_manage()`
- `menu_clone_refresh()`
- `menu_snapshot()`
- `menu_datapatch()`
- `menu_pdb_datapatch()`
- `menu_compile_utlrp()`
- `menu_fix_pdb_violations()`
- `menu_encryption()`
- `interactive_menu()`

## `lib_network_link.sh`

- `validate_dblink_name()`
- `generate_default_dblink_name()`
- `database_link_exists()`
- `prepare_source_clone_user()`
- `create_database_link()`
- `validate_database_link()`
- `ensure_database_link()`
- `drop_database_link_if_requested()`

## `lib_oracle.sh`

- `run_dbaascli()`
- `resolve_local_oracle_environment()`
- `run_local_sql()`
- `run_remote_source_sql()`
- `require_cdb()`
- `require_single_pdb()`
- `resolve_exact_inventory_name()`
- `validate_cdb_exists()`
- `get_pdb_inventory()`
- `resolve_exact_pdb_name()`
- `pdb_exists()`
- `resolve_existing_pdb()`
- `require_source_db()`
- `require_source_scan()`
- `validate_source_port()`
- `source_network_precheck()`
- `resolve_existing_pdb_sql()`
- `wait_for_pdb_state()`

## `lib_pdb_lifecycle.sh`

- `action_list_cdbs()`
- `action_list_pdbs()`
- `action_pdb_info()`
- `action_open_pdb()`
- `action_close_pdb()`
- `action_drop_pdb()`
- `action_rename_pdb()`
- `parse_pdb_list()`
- `action_create_pdb()`
- `create_one_pdb()`

## `lib_refresh.sh`

- `validate_refresh_interval()`
- `action_refreshable_create()`
- `action_refreshable_refresh()`
- `action_refreshable_status()`
- `action_refreshable_switchover()`
- `action_refreshable_convert_rw()`

## `lib_remediation.sh`

- `action_fix_pdb_violations()`

## `lib_snapshot.sh`

- `action_snapshot_test_enable()`
- `action_snapshot_test_disable()`

## `lib_subscription.sh`

- `subscription_script_path()`
- `subscription_require_script()`
- `subscription_run()`
- `subscription_prompt_database()`
- `subscription_validate_config()`
- `subscription_precheck_primary()`
- `subscription_precheck_standby()`
- `subscription_create_primary()`
- `subscription_create_standby()`
- `subscription_prepare_standby_test()`
- `subscription_prepare_standby_live()`
- `subscription_build_standby_test()`
- `subscription_build_standby_live()`
- `subscription_dg_status_primary_all()`
- `subscription_dg_status_standby()`
- `subscription_switchover_test()`
- `subscription_switchover_live()`
- `subscription_health_all()`
- `subscription_health_database()`
- `subscription_move_registration_tar()`
- `subscription_full_workflow()`

## `lib_validation.sh`

- `write_summary()`

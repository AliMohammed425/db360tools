# v3.1 Enterprise Features

## Parallel execution

`lib_parallel.sh` provides a bounded worker pool using Bash background jobs and
`wait -n`. The default is four workers and the maximum is 32.

## Checkpoint and resume

Every guided subscription migration writes a state file under `state/`.
Completed steps are recorded after successful execution. Resume starts at the
first incomplete step.

## Reporting

Reports are generated under:

```text
reports/YYYYMMDD/RUN_ID/
```

Formats:

- HTML
- JSON
- CSV
- PDF when a supported converter is installed

## Structured run data

Workflow state is independent from console logs, allowing reports and resume
operations to survive shell termination or host reconnects.


## Optional PDF reports

PDF conversion is disabled by default so report generation cannot fail because
of a browser or converter issue. Enable it explicitly:

```bash
export LTM_ENABLE_PDF=true
./bin/ltm_db_migration.sh --generate-migration-report --run-id RUN_ID
```

# Tablespace Management

Supports permanent and temporary tablespace creation in CDB root or a selected PDB, plus full inventory reporting.

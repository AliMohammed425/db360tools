# LTMdbMigration360 Developer Guide

## Architecture

```text
bin/ltm_db_migration.sh
    |
    +-- lib/lib_common.sh
    +-- lib/lib_help.sh
    +-- lib/lib_args.sh
    +-- lib/lib_oracle.sh
    +-- lib/lib_network_link.sh
    +-- lib/lib_cdb_create.sh
    +-- lib/lib_pdb_lifecycle.sh
    +-- lib/lib_clone.sh
    +-- lib/lib_refresh.sh
    +-- lib/lib_snapshot.sh
    +-- lib/lib_encryption.sh
    +-- lib/lib_datapatch.sh
    +-- lib/lib_remediation.sh
    +-- lib/lib_validation.sh
    +-- lib/lib_operations.sh
    +-- lib/lib_subscription.sh
    +-- lib/lib_menus.sh
    +-- lib/lib_dispatch.sh
```

## Maintenance rules

1. Put reusable logging and execution helpers in `lib_common.sh`.
2. Put argument parsing only in `lib_args.sh`.
3. Add new CLI actions to the appropriate functional module.
4. Register every action in `dispatch_action()` inside `lib_dispatch.sh`.
5. Add interactive prompts only in `lib_menus.sh`.
6. Do not define the same function in multiple modules.
7. Run `bin/validate_modules.sh` before release.


## v3.1 modules

- `lib_checkpoint.sh`: persistent workflow state
- `lib_parallel.sh`: bounded parallel worker execution
- `lib_reporting.sh`: HTML/JSON/CSV and optional PDF output

Developer utilities are located under `tools/`.

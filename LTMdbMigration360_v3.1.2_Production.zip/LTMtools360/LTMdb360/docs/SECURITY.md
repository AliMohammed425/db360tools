# Security Guidance

1. Do not store production passwords in source control.
2. Set `ltm_migration.ini` permissions to `600`.
3. Restrict shell scripts to `700`.
4. Use `opc` with approved passwordless sudo only for required DBaaSCLI and Oracle operations.
5. Archive logs securely because command output may contain database names, topology, services, and hostnames.
6. Rotate SYS, TDE, and clone-user passwords according to organizational policy.
7. Test all live workflows with dry-run/precheck modes before production execution.

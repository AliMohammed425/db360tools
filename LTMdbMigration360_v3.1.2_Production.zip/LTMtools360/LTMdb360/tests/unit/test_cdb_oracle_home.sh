#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
MODULE="$ROOT/lib/lib_cdb_create.sh"
MAIN="$ROOT/bin/ltm_db_migration.sh"

grep -q 'ORACLE_HOME_RESOLVED=""' "$MAIN"
grep -q 'TARGET_ORACLE_SID=""' "$MAIN"

grep -q 'ORACLE_HOME_RESOLVED="$oracle_home"' "$MODULE"
grep -q -- '--oracleHome "$oracle_home"' "$MODULE"

if grep -q -- '--oracleHome "$ORACLE_HOME_RESOLVED"' "$MODULE"; then
  echo "ERROR: CDB creation still references the unsafe global Oracle Home." >&2
  exit 1
fi

echo "CDB Oracle Home regression test passed."

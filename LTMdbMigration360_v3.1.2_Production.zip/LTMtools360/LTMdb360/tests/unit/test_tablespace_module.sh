#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
grep -q 'action_create_tablespace()' "$ROOT/lib/lib_tablespace.sh"
grep -q 'action_tablespace_report()' "$ROOT/lib/lib_tablespace.sh"
grep -q 'create temporary tablespace' "$ROOT/lib/lib_tablespace.sh"
grep -q 'cdb_tablespaces' "$ROOT/lib/lib_tablespace.sh"
grep -q '9) Create Tablespace / Temporary Tablespace' "$ROOT/lib/lib_menus.sh"
grep -q '10) Tablespace Inventory Report' "$ROOT/lib/lib_menus.sh"
grep -q -- '--create-tablespace' "$ROOT/lib/lib_args.sh"
grep -q -- '--tablespace-report' "$ROOT/lib/lib_args.sh"
echo 'Tablespace module regression test passed.'

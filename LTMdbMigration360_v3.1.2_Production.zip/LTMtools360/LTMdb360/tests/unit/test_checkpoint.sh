#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
PROJECT_STATE_DIR="$TMP/state"
PROJECT_LOG_DIR="$TMP/logs"
PROJECT_REPORT_DIR="$TMP/reports"
RUN_ID="test_run"
RUN_LOG_DIR="$TMP/logs/test_run"
RUN_REPORT_DIR="$TMP/reports/test_run"
info(){ :; }; ok(){ :; }; error(){ :; }; die(){ echo "$*" >&2; exit 1; }
source "$ROOT/lib/lib_checkpoint.sh"
checkpoint_init test db1
checkpoint_step_success 1 step1
[[ "$(checkpoint_get LAST_SUCCESSFUL_STEP)" == "1" ]]
checkpoint_complete
[[ "$(checkpoint_get STATUS)" == "SUCCESS" ]]

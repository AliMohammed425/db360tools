#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

PROJECT_STATE_DIR="$TMP/state"
PROJECT_LOG_DIR="$TMP/logs"
PROJECT_REPORT_DIR="$TMP/reports"
RUN_ID="report_run"
RUN_LOG_DIR="$TMP/logs/report_run"
RUN_REPORT_DIR="$TMP/reports/report_run"

warn(){ :; }
ok(){ :; }
info(){ :; }
error(){ :; }
die(){ echo "$*" >&2; exit 1; }

source "$ROOT/lib/lib_checkpoint.sh"
source "$ROOT/lib/lib_reporting.sh"

checkpoint_init report db1
checkpoint_complete
generate_migration_report report_run

REPORT_DIR="$TMP/reports/$(date +%Y%m%d)/report_run"
test -s "$REPORT_DIR/migration_summary.html"
test -s "$REPORT_DIR/migration_summary.json"
test -s "$REPORT_DIR/migration_summary.csv"

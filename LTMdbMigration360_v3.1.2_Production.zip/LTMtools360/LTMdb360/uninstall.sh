#!/usr/bin/env bash
set -Eeuo pipefail
TARGET_ROOT="${1:-/home/opc/LTMtools360/LTMdb360}"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [[ ! -d "$TARGET_ROOT" ]]; then
  echo "Not installed: $TARGET_ROOT"
  exit 0
fi

mv "$TARGET_ROOT" "${TARGET_ROOT}.removed_${STAMP}"
echo "Moved installation to ${TARGET_ROOT}.removed_${STAMP}"

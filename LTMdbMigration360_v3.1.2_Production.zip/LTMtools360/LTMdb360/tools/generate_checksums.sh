#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/SHA256SUMS"
rm -f "$OUT"
find "$ROOT" -type f ! -path "$OUT" -print0 |
  sort -z |
  while IFS= read -r -d '' file; do
    sha256sum "$file" | sed "s#  $ROOT/#  #"
  done > "$OUT"
echo "Generated $OUT"

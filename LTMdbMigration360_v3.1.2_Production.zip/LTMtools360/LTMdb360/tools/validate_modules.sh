#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$ROOT/bin/ltm_db_migration.sh"

echo "Validating primary entry point..."
bash -n "$MAIN"

echo "Validating library modules..."
for module in "$ROOT"/lib/*.sh; do
  echo "  $(basename "$module")"
  bash -n "$module"
done

echo "Checking duplicate function definitions..."
duplicates="$(
  grep -hE '^[A-Za-z_][A-Za-z0-9_]*\(\)[[:space:]]*\{' "$ROOT"/lib/*.sh |
    sed -E 's/\(\)[[:space:]]*\{.*//' |
    sort | uniq -d
)"
[[ -z "$duplicates" ]] || {
  echo "Duplicate functions:"
  echo "$duplicates"
  exit 1
}

"$MAIN" -v
"$MAIN" -h >/dev/null
echo "Module validation completed successfully."

#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

"$ROOT/tools/validate_modules.sh"
"$ROOT/tools/generate_checksums.sh"

test -r "$ROOT/VERSION"
test -r "$ROOT/README.md"
test -s "$ROOT/SHA256SUMS"
test -x "$ROOT/install.sh"
test -x "$ROOT/uninstall.sh"
test -d "$ROOT/state"
test -d "$ROOT/tests"
test -d "$ROOT/tools"
test -r "$ROOT/lib/lib_checkpoint.sh"
test -r "$ROOT/lib/lib_parallel.sh"
test -r "$ROOT/lib/lib_reporting.sh"

echo "Release validation completed successfully."

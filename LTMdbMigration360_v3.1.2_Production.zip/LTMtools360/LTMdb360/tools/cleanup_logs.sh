#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DAYS="${1:-30}"
find "$ROOT/logs" "$ROOT/reports" -type f -mtime +"$DAYS" -print -delete

#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
failed=0
for test_file in "$ROOT"/tests/unit/test_*.sh; do
  [[ -f "$test_file" ]] || continue
  echo "RUN $(basename "$test_file")"
  bash "$test_file" || failed=$((failed+1))
done
(( failed == 0 )) || exit 1
echo "Unit tests completed successfully."

# Changelog

## 11.1.0 Production — 2026-08-03

- Standardized product name: OracleMigration360
- Standardized executable: `odaa_db_migration.sh`
- Added interactive and non-interactive modes
- Added Subscription-to-Subscription migration menu
- Added CDB/PDB, clone, refreshable PDB, snapshot test, encryption, Data Guard, and health workflows
- Added installer and uninstaller
- Added production permissions and configuration templates
- Added release validation and checksums

# ODAA DB Migration PDB Utility v11.0

## Quick Start

### 1. Help
```bash
./odaa_db_migration_v11.sh -h
```

### 2. Detailed Help
```bash
./odaa_db_migration_v11.sh -H
```

### 3. List all CDBs
```bash
./odaa_db_migration_v11.sh -L
```

### 4. List PDBs in a CDB
```bash
./odaa_db_migration_v11.sh -l -c sny
```

### 5. Create Local RAC CDB
```bash
./odaa_db_migration_v11.sh --rac -Y -J /u02/app/oracle/product/19.0.0.0/dbhome_1 -c BNYCDB -Q BNYCDB_OCI -V BNYCDB -W +DATAC2 -Z +RECOC2 -w 'CHANGE_ME_SYS_PASSWORD' -K 'CHANGE_ME_SYS_PASSWORD' -y
```

### 6. Create New Local PDB
```bash
./odaa_db_migration_v11.sh -c sny -k SNYPDB5
```

### 7. Local Clone
```bash
./odaa_db_migration_v11.sh -c sny -k SNYPDB6 -p SNYPDB5
```

### 8. Remote Clone
```bash
./odaa_db_migration_v11.sh -R -c sny -p BNYPDB3 -t BNYPDB3_NEW -s bny_exa -a dbhost-ttqtv-scan.ociodaadelegat.ocicsuodaavnet.oraclevcn.com -w 'CHANGE_ME_SYS_PASSWORD'
```

### 9. Create Refreshable PDB

Example 1

```bash
./odaa_db_migration_v11.sh -f -c sny -p BNYPDB3 -t BNYPDB6 -s bny_exa -a dbhost-ttqtv-scan.ociodaadelegat.ocicsuodaavnet.oraclevcn.com -P 1521 -g bny_exa.ociodaadelegat.ocicsuodaavnet.oraclevcn.com -I 60 -w 'CHANGE_ME_SYS_PASSWORD' -K 'CHANGE_ME_SYS_PASSWORD'
```

Example 2

```bash
./odaa_db_migration_v11.sh -f -c sny -p BNYPDB1 -t LNYPDB1 -s BNYCDB_NONRAC -a odaa-jump-host01.internal.cloudapp.net -P 1521 -g BNYCDB_NONRAC -I 60 -w 'CHANGE_ME_SECURE_PASSWORD' -K 'CHANGE_ME_SECURE_PASSWORD'
```

### 10. Final Refresh / Cutover
```bash
./odaa_db_migration_v11.sh -C -c sny -p BNYPDB3
```

Performs the final refresh, disables refresh mode permanently, and opens the PDB READ WRITE.

### 11. Drop PDB
```bash
./odaa_db_migration_v11.sh -d -c sny -p BNYPDB3
```

### 12. Writable Snapshot Test PDB

Prerequisite: Snapshot Copy requires an ASM Sparse Disk Group.

```bash
./odaa_db_migration_v11.sh -c sny -p BNYPDB6 -t BNYPDB7 --snapshot-test-enable -K 'CHANGE_ME_SYS_PASSWORD'
```

Disable snapshot test before the next refresh:

```bash
./odaa_db_migration_v11.sh --snapshot-test-disable -c sny -p BNYPDB6 -t BNYPDB7
```

## Interactive Mode

```bash
./odaa_db_migration_v11.sh
```

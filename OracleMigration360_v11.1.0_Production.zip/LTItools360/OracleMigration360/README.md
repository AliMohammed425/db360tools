# OracleMigration360

Production Oracle Database migration and lifecycle automation for Oracle Database@Azure, OCI, Exadata, RAC, and single-instance environments.

## Primary command

```bash
/home/opc/LTItools360/OracleMigration360/bin/odaa_db_migration.sh
```

Running without arguments starts interactive mode. Passing options runs non-interactive CLI mode.

## Install

```bash
unzip OracleMigration360_v11.1.0_Production.zip
cd LTItools360/OracleMigration360
sudo ./bin/install.sh /home/opc/LTItools360/OracleMigration360 opc oinstall
```

## Validate

```bash
bash -n bin/odaa_db_migration.sh
bin/odaa_db_migration.sh -v
bin/odaa_db_migration.sh -h
bin/odaa_db_migration.sh -H
```

## Security

- `bin/*.sh`: `700`
- `config/*`: `600`
- `json/*`: `600`
- Never commit or distribute real SYS, TDE, wallet, or clone-user passwords.
- Use restricted service accounts and least-privilege sudo rules.

## Core features

- Interactive and non-interactive modes
- CDB creation with DBaaSCLI or DBCA
- PDB lifecycle management
- Local and remote PDB cloning
- Refreshable PDB creation and cutover
- Writable test PDB creation
- TDE and encryption status
- Subscription-to-Subscription migration
- Data Guard preparation, build, status, and switchover
- Health checks and reports


## Production executables

```text
bin/odaa_db_migration.sh
bin/odaa_db_create_precheck.sh
bin/odaa_db_create.sh
bin/odaa_db_prepare_stby.sh
bin/odaa_db_build_stby.sh
bin/odaa_dg_switchover.sh
bin/odaa_db_status_health.sh
bin/odaa_move_latest_db_tar.sh
```

Only `odaa_db_migration.sh` is intended as the primary user entry point. The remaining scripts are companion workflow executables invoked by the Subscription-to-Subscription menu.

#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
create_local_cdb(){
  local cdb="" db_unique="" sid="" data_dest="+DATA" fra_dest="+RECO" oh="" pwd=""
  prompt_value cdb "CDB name"
  prompt_value db_unique "DB_UNIQUE_NAME" "$cdb"
  prompt_value sid "Oracle SID" "$cdb"
  prompt_value data_dest "Data destination" "+DATA"
  prompt_value fra_dest "FRA destination" "+RECO"
  prompt_value oh "Oracle Home"
  prompt_secret pwd "SYS/SYSTEM password"
  run_engine -Y -c "$cdb" -Q "$db_unique" -V "$sid" -W "$data_dest" -Z "$fra_dest" -J "$oh" -w "$pwd"
}

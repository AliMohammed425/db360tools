#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
generate_inventory_report(){
  local cdb="" stamp report; prompt_value cdb "CDB name"; stamp="$(date +%Y%m%d_%H%M%S)"
  report="${ODAA_REPORT}/pdb_inventory_${cdb}_${stamp}.txt"
  run_engine -l -c "$cdb" | tee "$report"; ok "Report created: $report"
}

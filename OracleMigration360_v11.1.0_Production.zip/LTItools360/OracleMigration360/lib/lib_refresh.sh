#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
create_refreshable_pdb(){
  local cdb="" src="" tgt="" sdb="" scan="" port="1521" svc="" interval="0" pwd="" key=""
  prompt_value cdb "Target CDB"; prompt_value src "Source PDB"; prompt_value tgt "Refreshable target PDB"
  prompt_value sdb "Source DB_UNIQUE_NAME"; prompt_value scan "Source SCAN/host"; prompt_value port "Listener port" "1521"
  prompt_value svc "Source service" "$sdb"; prompt_value interval "Refresh interval minutes (0=manual)" "0"
  prompt_secret pwd "Source SYS password"; prompt_secret key "Target keystore password"
  run_engine -f -c "$cdb" -p "$src" -t "$tgt" -s "$sdb" -a "$scan" -P "$port" -g "$svc" -I "$interval" -w "$pwd" -K "$key"
}
manual_refresh_pdb(){ local cdb="" pdb=""; prompt_value cdb "CDB name"; prompt_value pdb "Refreshable PDB"; run_engine -M -c "$cdb" -p "$pdb"; }
refresh_status(){ local cdb="" pdb=""; prompt_value cdb "CDB name"; prompt_value pdb "Refreshable PDB"; run_engine -q -c "$cdb" -p "$pdb"; }

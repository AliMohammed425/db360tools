#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
local_clone_pdb(){ local cdb="" src="" tgt=""; prompt_value cdb "CDB name"; prompt_value src "Source PDB"; prompt_value tgt "Target PDB"; run_engine -k "$tgt" -c "$cdb" -p "$src"; }
remote_clone_pdb(){
  local cdb="" src="" tgt="" sdb="" scan="" port="1521" svc="" pwd=""
  prompt_value cdb "Target CDB"; prompt_value src "Source PDB"; prompt_value tgt "Target PDB" "$src"
  prompt_value sdb "Source DB_UNIQUE_NAME"; prompt_value scan "Source SCAN/host"; prompt_value port "Listener port" "1521"
  prompt_value svc "Source service" "$sdb"; prompt_secret pwd "Source SYS password"
  run_engine -R -c "$cdb" -p "$src" -t "$tgt" -s "$sdb" -a "$scan" -P "$port" -g "$svc" -w "$pwd"
}

#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
encryption_status(){ local cdb=""; prompt_value cdb "CDB name"; run_engine -L -c "$cdb"; }
enable_pdb_encryption(){ local cdb="" pdb=""; prompt_value cdb "CDB name"; prompt_value pdb "PDB name"; run_engine -e -c "$cdb" -p "$pdb"; }

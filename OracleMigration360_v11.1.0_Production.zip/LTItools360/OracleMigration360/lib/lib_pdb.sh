#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
list_pdbs(){ local cdb=""; prompt_value cdb "CDB name"; run_engine -l -c "$cdb"; }
create_pdb(){ local cdb="" pdb=""; prompt_value cdb "CDB name"; prompt_value pdb "New PDB name"; run_engine -z -c "$cdb" -p "$pdb"; }
drop_pdb(){ local cdb="" pdb=""; prompt_value cdb "CDB name"; prompt_value pdb "PDB name"; run_engine -d -c "$cdb" -p "$pdb"; }
rename_pdb(){ local cdb="" old="" new=""; prompt_value cdb "CDB name"; prompt_value old "Current PDB"; prompt_value new "New PDB"; run_engine -r "$new" -c "$cdb" -p "$old"; }
